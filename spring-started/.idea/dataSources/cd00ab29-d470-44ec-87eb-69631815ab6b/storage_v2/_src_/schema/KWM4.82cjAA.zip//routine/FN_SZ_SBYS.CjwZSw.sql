create function fn_sz_sbys(p_sbys varchar2,p_jzrq varchar2,p_fhrq varchar2)
/*
p_sbys==>社保局返回月数
p_jzrq==>教育局政策截止日期
p_fhrq==>社保局返回截止日期
*/
return varchar2 is 
v_sbys varchar2(32);
v_jznf int;
v_fhnf int;
v_jzrq int;
v_fhrq int;
v_sbys2 int;
begin
  v_sbys := p_sbys;
  if(length(p_jzrq)=8 and length(p_fhrq)=6) then 
     v_jznf:=to_number(substr(p_jzrq,0,4));
     v_fhnf:=to_number(substr(p_fhrq,0,4));
     v_jzrq:=to_number(substr(p_jzrq,5,2));
     v_fhrq:=to_number(substr(p_fhrq,5,2));
     if(v_jznf=v_fhnf and v_fhrq > v_jzrq) then 
        v_sbys2:=to_number(v_sbys)-(v_fhrq-v_jzrq);
        if(v_sbys2<0) then 
           v_sbys:='0';
        else 
           v_sbys:=to_char(v_sbys2);
        end if;
     end if;
  end if;
  return v_sbys;
  EXCEPTION
     WHEN OTHERS THEN
     v_sbys := p_sbys;
  return v_sbys;
end fn_sz_sbys;
/

