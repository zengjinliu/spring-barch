create PROCEDURE PRO_SMBD_TJ IS
  --机构游标
  cursor c_organdapplist is select a.org_Id,a.app_id,a.APP_MC from v_jc_visitset a
  where PRO_ID='420fea1769084ceb9173814d30e60193'and
        exists(select 1 from jc_org_relat b where b.org_id='b018d8494c314055bc3ea9df9ab0e3de' and b.org_id_child=a.ORG_ID)
        and exists(select 1 from smbd_bmsz c where c.orgid=a.ORG_ID)and index_path='login.jsp';
  organdapp c_organdapplist%rowtype;
  --部门游标
  cursor c_bmlist(quorgid String) is select * from smbd_bmsz a where a.orgid=quorgid order by a.xh;
  bm c_bmlist%rowtype;
  v_exist int;
  v_bmtj varchar2(1000);
  v_quorgid varchar2(32);
  v_bmmc varchar2(32); -- 部门名称
  v_bmid varchar2(32);
  v_bmdm varchar2(32);
  v_appid varchar2(32);
  v_xyss number;
  v_sdss number;
  v_yss  number;
  v_dss  number;
  v_ycl  number;
  v_dcl  number;
  v_wsh  number;
  v_shtg number;
  v_shbtg number;
  v_xyshsql varchar2(1000);
  v_sdsssql varchar2(1000);
  v_ysssql varchar2(1000);
  v_dsssql varchar2(1000);
  v_yclsql varchar2(1000);
  v_dclsql varchar2(1000);
  v_wshsql varchar2(1000);
  v_shtgsql varchar2(1000);
  v_shbtgsql varchar2(1000);

BEGIN
    open c_organdapplist;
    loop fetch c_organdapplist into organdapp;
    exit when c_organdapplist%notfound;
      v_quorgid := organdapp.ORG_ID;
      v_appid := organdapp.APP_ID;

      open c_bmlist(v_quorgid);
      loop fetch c_bmlist into bm;
      exit when c_bmlist%notfound;
        if(bm.tj is not null)then
          v_bmtj:=''' and '||bm.tj;
          else 
          v_bmtj:='''';
        end if;
        v_bmmc := bm.BMMC;
        v_bmid := bm.BMID;
        v_bmdm := bm.BMDM;
        --需要送审
        v_xyshsql := 'select count(*) cnt from v_smbd_bmshjg jo where jo.SHZT = ''2'' and jo.APP_ID='''||v_appid||'' || v_bmtj;
        execute immediate v_xyshsql into v_xyss;
        --手动送审
        v_sdsssql := 'select count(*) cnt from SMBD_SJ  where APP_ID='''||v_appid|| ''' and BMID = '''||v_bmid||'''';
        execute immediate v_sdsssql into v_sdss;
        -- 已送审
        v_ysssql := 'select count(*) cnt from SMBD_SJ  where SSZT = ''Y''  and APP_ID='''||v_appid|| ''' and BMID = '''||v_bmid||'''' ;
        execute immediate v_ysssql into v_yss;
        -- 待送审
        v_dsssql := 'select count(*) cnt from SMBD_SJ  where SSZT = ''N''  and APP_ID='''||v_appid|| ''' and BMID = '''||v_bmid||'''' ;
        execute immediate v_dsssql into v_dss;
         -- 已处理
        v_yclsql := 'select count(*) cnt from SMBD_SJ  where JGCLZT = ''Y''  and APP_ID='''||v_appid|| ''' and BMID = '''||v_bmid||'''' ;
        execute immediate v_yclsql into v_ycl;
        -- 待待处理
        v_dclsql := 'select count(*) cnt from SMBD_SJ  where JGCLZT = ''N''  and APP_ID='''||v_appid|| ''' and BMID = '''||v_bmid||'''' ;
        execute immediate v_dclsql into v_dcl;
        --未审核
        v_wshsql := 'select count(*)  from v_smbd_bmshjg JO left join smbd_shjg e on e.xsid=jo.xsid and e.bmdm= '''||v_bmdm||''' WHERE JO.SHZT = ''2''  and nvl(e.SHJG,''0'') =''0'' AND APP_ID='''||v_appid||'' || v_bmtj;
        execute immediate v_wshsql into v_wsh;
         --审核通过
        v_shtgsql := 'select count(*)  from v_smbd_bmshjg JO left join smbd_shjg e on e.xsid=jo.xsid and e.bmdm= '''||v_bmdm||''' WHERE JO.SHZT = ''2'' and nvl(e.SHJG,''0'') =''1'' AND APP_ID='''||v_appid||'' || v_bmtj;
        execute immediate v_shtgsql into v_shtg;
         --审核不通过
        v_shbtgsql := 'select count(*)  from v_smbd_bmshjg JO left join smbd_shjg e on e.xsid=jo.xsid and e.bmdm= '''||v_bmdm||''' WHERE JO.SHZT = ''2'' and nvl(e.SHJG,''0'') =''2'' AND APP_ID='''||v_appid||'' || v_bmtj;
        execute immediate v_shbtgsql into v_shbtg;

        select count(*) into v_exist from SMBD_TJ WHERE APP_ID=v_appid and BMID = v_bmid;
        if ( v_exist > 0) then -- 存在则更新
          update SMBD_TJ set XYSS = v_xyss,SDSS=v_sdss,YSS = v_yss,DSS = v_dss,YCL = v_ycl,DCL = v_dcl,WSH=v_wsh,SHTG=v_shtg,SHBTG=v_shbtg
          where APP_ID=v_appid and BMID = v_bmid;
        else
          insert into SMBD_TJ values (fn_uuid(),v_appid,v_bmid,v_bmmc,v_xyss,v_sdss,v_yss,v_dss,v_ycl,v_dcl,v_wsh,v_shtg,v_shbtg,v_quorgid);
        end if ;
        commit ;
      end loop;
      close c_bmlist;
    end loop
    close ;
end ;
/

