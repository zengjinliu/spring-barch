create view V_JC_ROLE_WRITE as
select "ROLE_ID","OP_ID","PRO_ID" from jc_role_write
/

