create view V_ZS_ZJCJ_ZJXX as
select zjxxid,
yw_pkid,
zjid,
zjmc,
f_id,
status,
xzr,
xzsj
from zjcj_zjxx a
/

