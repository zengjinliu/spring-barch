create function FN_CLOB_TO_STR(input_ clob) return varchar2 is v_str varchar2(4000);
begin
  v_str:=to_char(input_);
return v_str;
end FN_CLOB_TO_STR;
/

