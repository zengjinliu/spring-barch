create view V_JC_ROLE_READ as
select "ROLE_ID","PRO_ID" from jc_role_read
/

