create view V_JC_ORG_BJ_BYXXNJ as
select a.org_id,a.org_mc,a.org_dm,a.org_orderid,f.jhs,f.xx_org_id,f.nj_org_id,
c.orgid njorg_id,g.org_mc njorg_mc,g.org_dm njorg_dm,g.org_orderid njorg_orderid,
e.ORG_ID xxorg_id,e.ORG_DM xxorg_dm,e.ORG_MC xxorg_mc,e.ORG_ORDERID xxorg_orderid
from jc_org a
left join jc_org_bj f on f.orgid=a.org_id
left join jc_org_relat b on a.org_id=b.org_id_child
left join jc_org_nj c on b.org_id=c.orgid
inner join jc_org g on g.org_id=c.orgid and g.org_state='1'
left join jc_org_relat d on c.orgid=d.org_id_child
left join jc_org e on d.org_id=e.ORG_ID and e.org_state='1'
where a.org_state='1' and a.org_dj=(select nvl(z.con_value,'105') from jc_const z where z.con_key='JC_BJDJDM')
/

