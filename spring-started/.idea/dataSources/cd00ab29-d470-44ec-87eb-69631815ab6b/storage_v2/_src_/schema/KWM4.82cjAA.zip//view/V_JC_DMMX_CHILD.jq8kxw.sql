create view V_JC_DMMX_CHILD as
select a.dmmx_id,a.dm_code,a.dmmx_code,a.dmmx_mc,a.p_dm_id,a.dmmx_state,a.dmmx_orderid,
b.dmmx_id fdmmx_id,b.dm_code fdm_code,b.dmmx_code fdmmx_code,b.dmmx_mc fdmmx_mc,b.dmmx_state fdmmx_state,
b.dmmx_orderid fdmmx_orderid
from  JC_DMMX a
	left join JC_DMMX b on a.p_dm_id=b.dmmx_id and b.dmmx_state='1'
where a.dmmx_state='1'
/

