create view V_JCJK_FW_LOCKXX as
select a.FWBM,a.FWDZ,
p.dmmx_mc as SDZT,
o.dmmx_mc SDXD,to_char(d.LOCKTIME,'yyyy') SDNF,to_char(d.unlocktime,'yyyy') as JSNF,
d.xxid SDXXBM,c.ORG_MC SDXXMC,
a.ORGID ORG_ID
from xqf_fw a
inner join zs_xqf_hf b on b.fwid=a.fwid
left join zs_xqf_lock d on d.xxid=b.xxid and d.fwid=a.fwid and d.status<>'2'
left join jc_org c on c.org_id=d.xxid
left join zs_xxxx e on e.org_id=c.org_id
left join jc_dmmx p on p.dm_code='DM_LOCK' and d.status=p.dmmx_code and p.dmmx_state='1'
left join jc_dmmx o on o.dm_code='DM_JYJD' and e.XD=o.dmmx_code and o.dmmx_state='1'
where c.org_state='1'
/

