create view V_JC_DXXZ as
select t."JGID",t."GH",t."XM",t."YWXM",t."XMPY",t."CYM",t."XBM",e1.dmmx_mc "XBMC",t."CSRQ",t."CSDM",
t."JG",t."MZM",t."GJDQM",t."SFZJLXM",e2.dmmx_mc "SFZJLXMC",t."SFZJH",t."HYZKM",t."GATQWM",t."ZZMMM",t."JKZKM",
t."XYZJM",t."XXM",t."ZP",t."SFZJYXQ",t."SFDSZN",t."YZBM",t."TXDZ",t."DH",t."YDDH",t."CZDH",
t."DZXX",t."WLDZ",t."JSTXH",t."STATE",t."CSD",t."GZDW",T.ORG_ID,T.USER_ID,T.Rjxk
from jc_jg t
LEFT JOIN jc_dmmx E1 ON t.xbm = E1.DMMX_CODE and e1.dm_code = 'DM_XB'
LEFT JOIN jc_dmmx E2 ON t.Sfzjlxm = E2.DMMX_CODE and e2.dm_code = 'DM_SFZJLX'
where t.state='1'
/

