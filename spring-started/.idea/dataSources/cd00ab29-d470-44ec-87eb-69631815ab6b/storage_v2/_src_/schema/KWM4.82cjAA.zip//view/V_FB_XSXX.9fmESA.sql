create view V_FB_XSXX as
select t.xsid,t.BH,t.XM,t.XMBZ,t.XBM,t.CJ,t.HJ,t.SJHM,t.APP_ID,t.ORG_ID,decode(t.XBM,'1','男','2','女') XBMC,decode(t.HJ,'1','户籍','2','非户籍') HJMC, count(t.xsid) SFFB from(
select * from FB_XSXX T1
union all 
select * from FB_XSXX T1 where  EXISTS (SELECT 1 FROM  FB_XSXX_BJ b   WHERE  b.xsid=t1.xsid )
) t  group by t.xsid,t.BH,t.XM,t.XMBZ,t.XBM,t.CJ,t.HJ,t.SJHM,t.APP_ID,t.ORG_ID
/

