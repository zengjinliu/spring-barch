create procedure PRO_TC_XSCJ(
xx_id in varchar2,--学校ID
pc_id in varchar2--批次ID
)
is
  cursor xsids is  select tx.xsid  from tc_xs tx where tx.org_id=xx_id;
  --游标：根据学校找学生

  cursor jfxms is  select distinct d.jfid from jc_batch a 
  inner join tc_batch_csxm b on b.pcid=a.bid 
  inner join tc_csxm c on c.csid=b.csid 
  inner join tc_csxm_jfxm d on d.csid=c.csid
  where a.bid=pc_id;--游标：该批次关联的计分项目
  
  xsid xsids%rowtype ;--单个学生实体
  xs_id  varchar2(32);--单个学生
  jfxm jfxms%rowtype ;--单个计分项目
  total integer  default 0;--单个计分项目关联的测试项目数量
  jf_id varchar2(100);--单个计分项目ID
  cs_id varchar2(100);--单个计分项目关联的测试项目ID
  csxm_mc varchar2(100);--单个计分项目关联的测试项目名称

  cs_id1 varchar2(100);--BMI中的身高或体重ID
  cs_id2 varchar2(100);--BMI中的身高或体重ID
  csxm_mc1 varchar2(100);--BMI中的身高或体重名称
  csxm_mc2 varchar2(100);--BMI中的身高或体重名称
  result1 number default 0;--BMI中的身高或体重结果
  result2 number default 0;--BMI中的身高或体重结果

  is_hmxs integer  default 0;--是否属于缓免学生
  is_exisit_csjg integer  default 0;--检查测试结果是否存在
  is_exisit_jfjg integer  default 0;--检查计分结果是否存在
  bz_id varchar2(100);--标准ID
  nj_dm varchar2(100);--年级代码
  xb_dm varchar2(100);--性别代码
  v_orgid varchar2(100);--orgid
  v_appid varchar2(100);--appid
  cs_result number(8,2) default 0;--测试成绩
  cssj date;--测试时间
  v_bzf number  default 0;--标准分
  v_fjf number  default 0;--附加分
  v_djid varchar2(100);--等级ID
  v_djmc varchar2(100);--等级名称

begin
    loop
    fetch xsids into xsid;
    exit when jfxms%notfound;
      xs_id := xsid.xsid;
       
      --缓免学生直接过滤掉
      select count(*) into is_hmxs from TC_HMXS th where th.xsid=xs_id;
      if(is_hmxs = 0)  
      then 
      open jfxms;
      loop
        fetch jfxms into jfxm;
        exit when jfxms%notfound;
        
          select count(c.csid) into total 
          from tc_jfxm a 
          inner join tc_csxm_jfxm b on b.jfid=a.jfid 
          inner join tc_csxm c on c.csid=b.csid 
          where b.jfid=jfxm.jfid;
          
          if(total = 2) --BMI
          then
            --根据计分项目ID找出对应的测试项目ID和名称
            select a.jfid,wm_concat(b.csid) csid,wm_concat(c.csxmmc) csxmmc
            into jf_id,cs_id,csxm_mc
            from tc_jfxm a 
            inner join tc_csxm_jfxm b on b.jfid=a.jfid 
            inner join tc_csxm c on c.csid=b.csid
            where b.jfid=jfxm.jfid
            group by a.jfid,a.jfxmmc;
            EXIT WHEN jf_id IS NULL or cs_id IS NULL or csxm_mc IS NULL; 
            
            if (instr(csxm_mc,'身高') > 0 or instr(csxm_mc,'体重') > 0) 
            then  
               --截取测试项目ID                   
               SELECT REGEXP_SUBSTR(cs_id,'[^,]+',1,1),REGEXP_SUBSTR(cs_id,'[^,]+',1,2) into cs_id1,cs_id2 from dual;    
               --截取测试项目名称
               SELECT REGEXP_SUBSTR(csxm_mc,'[^,]+',1,1),REGEXP_SUBSTR(csxm_mc,'[^,]+',1,2) into csxm_mc1,csxm_mc2 from dual;  
               --根据测试项目ID查成绩1              
               select count(t1.result) into result1 from TC_CS_RESULT t1 where t1.XSID=xs_id and t1.PCID=pc_id and t1.CSID=cs_id1;
               if(result1 > 0)        
               then               
                 select t1.result into result1 from TC_CS_RESULT t1 where t1.XSID=xs_id and t1.PCID=pc_id and t1.CSID=cs_id1;
               else
                 --测试结果不存在的时候，清除计分结果
                 delete from TC_JF_RESULT t3 where t3.XSID=xs_id and t3.PCID=pc_id and t3.JFID=jfxm.jfid;     
               end if;
               --根据测试项目ID查成绩2   
               select count(t2.result) into result2 from TC_CS_RESULT t2 where t2.XSID=xs_id and t2.PCID=pc_id and t2.CSID=cs_id2; 
               if(result2 > 0)        
               then 
                 select t2.result,t2.orgid,t2.appid into result2,v_orgid,v_appid from TC_CS_RESULT t2 where t2.XSID=xs_id and t2.PCID=pc_id and t2.CSID=cs_id2;
               else
                 --测试结果不存在的时候，清除计分结果
                 delete from TC_JF_RESULT t4 where t4.XSID=xs_id and t4.PCID=pc_id and t4.JFID=jfxm.jfid;   
               end if;
               
               if(result1 > 0 and result2 > 0)
               then
                 --计算BMI的值
                 if(csxm_mc1='身高')
                 then
                    cs_result :=  round(result2/power(result1/100,2),1);
                 else
                    cs_result :=  round(result1/power(result2/100,2),1);
                 end if;  
                 
                 --根据学生ID查询年级代码和性别代码
                 select m.XBM,m.njdm into  xb_dm,nj_dm from TC_XS m where m.XSID=xs_id;
                 EXIT WHEN xb_dm IS NULL or nj_dm IS NULL;
                 --根据批次ID找出标准ID
                 select n.mbid into bz_id from Jc_Batch n where n.bid=pc_id;
                 EXIT WHEN bz_id IS NULL;  
              
                 --根据标准ID、计分ID、性别代码、年级代码找出标准分,等级名称
                 select s.fs,s.djmc into v_bzf,v_djmc from Tc_Zbfz s where s.bzid=bz_id and s.jfid=jf_id and s.xbdm=xb_dm and s.njdm=nj_dm
                 and s.high>cs_result and cs_result>=s.low and rownum = 1;
                 EXIT WHEN v_bzf IS NULL;  
                 
                 --等级名称为空，继续找
                 --if(v_djmc IS NULL)
                 --then
                   --根据标准ID、标准分找出对应的等级
                   --select  q.gmxid,q.gmxmc into v_djid,v_djmc from jc_pgbz o 
                   --inner join jc_pgbz_grade p on p.gid = o.gid
                   --inner join jc_pgbz_grade_mx q on q.gid=p.gid
                   --where o.bzid=bz_id and q.max>v_bzf and v_bzf>=q.min and rownum = 1;                 
                   --EXIT WHEN v_djid IS NULL or v_djmc IS NULL; 
                 --end if;  
                 
                 --先根据学生ID、批次ID和计分ID删除存在的数据，然后再新增
                 select count(jfid) into is_exisit_jfjg from TC_JF_RESULT  where XSID=xs_id and PCID=pc_id  and JFID=jf_id;
                 if(is_exisit_jfjg>0)
                 then
                   delete from TC_JF_RESULT where XSID=xs_id and PCID=pc_id  and JFID=jf_id;   
                 end if;      
                 insert into TC_JF_RESULT(RID,PCID,XSID,JFID,RESULT,BZF,FJF,DJID,DJMC,CSSJ,ORGID,APPID) 
                 values(FN_UUID(),pc_id,xs_id,jf_id,cs_result,v_bzf,0,v_djid,v_djmc,sysdate,v_orgid,v_appid); 
                         
               end if;                   
            end if;
            
          else --除了BMI，其他的计分项目
            
            --根据计分项目ID找出对应的测试项目ID和名称
            select a.jfid,c.csid,c.csxmmc into jf_id,cs_id,csxm_mc 
            from tc_jfxm a 
            inner join tc_csxm_jfxm b on b.jfid=a.jfid 
            inner join tc_csxm c on c.csid=b.csid 
            where b.jfid=jfxm.jfid;
            EXIT WHEN jf_id IS NULL or cs_id IS NULL or csxm_mc IS NULL; 
            
            --检查测试结果是否存在
            select count(*) into is_exisit_csjg from TC_CS_RESULT e where e.XSID=xs_id and e.PCID=pc_id and e.CSID=cs_id;
            if(is_exisit_csjg > 0)        
            then 
              --根据学生ID、批次ID和测试项目ID找出成绩                
              select f.result,f.cssj,f.orgid,f.appid into cs_result,cssj,v_orgid,v_appid from TC_CS_RESULT f where f.XSID=xs_id and f.PCID=pc_id and f.CSID=cs_id;
              EXIT WHEN cs_result IS NULL;  
                      
              if(csxm_mc='坐位体前屈' or csxm_mc='50米跑')
              then 
                cs_result :=round(cs_result,1);--保留一位小数
              else 
                cs_result :=round(cs_result); --整数
              end if;
              
              --根据学生ID查询年级代码和性别代码
              select g.XBM,g.njdm into  xb_dm,nj_dm from TC_XS g where g.XSID=xs_id;
              EXIT WHEN xb_dm IS NULL or nj_dm IS NULL;
              --根据批次ID找出标准ID
              select h.mbid into bz_id from Jc_Batch h where h.bid=pc_id;
              EXIT WHEN bz_id IS NULL;  
              
              --根据标准ID、计分ID、性别代码、年级代码找出标准分,等级名称
              select k.fs,k.djmc into v_bzf,v_djmc from Tc_Zbfz k where k.bzid=bz_id and k.jfid=jf_id and k.xbdm=xb_dm and k.njdm=nj_dm
              and k.high>cs_result and cs_result>=k.low;
              EXIT WHEN v_bzf IS NULL;
              
              --判断是否有附加分
              if(v_bzf>100)  
              then
                  v_fjf := v_bzf-100;--附加分
                  v_bzf := 100;--标准分
              else
                  v_fjf := 0;
              end if;
              
              --等级名称为空，继续找
              --if(v_djmc IS NULL)
              --then 
                --根据标准ID、标准分找出对应的等级
               --select  z.gmxid,z.gmxmc into v_djid,v_djmc from jc_pgbz x 
                --inner join jc_pgbz_grade y on y.gid = x.gid1
                --inner join jc_pgbz_grade_mx z on z.gid=y.gid
                --where x.bzid=bz_id and z.max>v_bzf and v_bzf>=z.min;  
                --EXIT WHEN v_djid IS NULL or v_djmc IS NULL;      
              --end if;  
               
              --先根据学生ID、批次ID和计分ID删除存在的数据，然后再新增
             select count(jfid) into is_exisit_jfjg from TC_JF_RESULT where XSID=xs_id and PCID=pc_id  and JFID=jf_id;
             if(is_exisit_jfjg>0)
             then                  
              delete from TC_JF_RESULT where XSID=xs_id and PCID=pc_id  and JFID=jf_id;   
             end if;      
             insert into TC_JF_RESULT(RID,PCID,XSID,JFID,RESULT,BZF,FJF,DJID,DJMC,CSSJ,ORGID,APPID) 
             values(FN_UUID(),pc_id,xs_id,jf_id,cs_result,v_bzf,v_fjf,v_djid,v_djmc,cssj,v_orgid,v_appid);
             
            else
             --测试结果不存在的时候，清除计分结果
             delete from TC_JF_RESULT t5 where t5.XSID=xs_id and t5.PCID=pc_id and t5.JFID=jfxm.jfid;     
            end if;
            
          end if; 
        commit;        
      end loop;
    end if;
    close jfxms;
  end loop;
  close xsids;
  EXCEPTION
  when others then rollback;
end PRO_TC_XSCJ;
/

