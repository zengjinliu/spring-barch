create function fn_year(v_date date) return int is v_year int;
begin
   v_year := extract(year from v_date);
return v_year;
end fn_year;
/

