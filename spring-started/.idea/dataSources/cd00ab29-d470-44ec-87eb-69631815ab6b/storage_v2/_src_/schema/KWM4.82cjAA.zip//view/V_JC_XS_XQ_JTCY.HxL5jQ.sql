create view V_JC_XS_XQ_JTCY as
    select
a.xm,
a.xbm,
a.mzm,
a.SFDSZN,
a.HKXZM,
a.SFGE,
a.SFCJYE,
a.SFLSETM,
a.SFSQZNM,
b.bjmc,
b.njdm,
b.bjid,
DECODE(A.XBM,'1','男','2','女','') XB,
a.csrq,
a.sfzjh,
a.cyxm1,
a.gxmc1,
a.sfzjlxmc1,
a.sfzjh1,
DECODE(A.SFJHRM1,'0','否','1','是','') SFJHR1,
a.HKSZD1,
a.XZZ1,
a.LXDH1,
a.mzmc1,
a.gzdw1,
a.zw1,
a.JK_UUID,
a.org_id,
a.xxid,
a.xszt,
s.ssjd
from jc_xs a
left join jc_class b on a.BJID = b.BJID
left join jc_xx S on a.xxid = S.ORG_ID
union all
select
c.xm,
c.xbm,
c.mzm,
c.SFDSZN,
c.HKXZM,
c.SFGE,
c.SFCJYE,
c.SFLSETM,
c.SFSQZNM,
d.bjmc,
d.njdm,
d.bjid,
DECODE(c.XBM,'1','男','2','女','') XB,
c.csrq,
c.sfzjh,
c.cyxm2,
c.gxmc2,
c.sfzjlxmc2,
c.sfzjh2,
DECODE(c.SFJHRM2,'0','否','1','是','') SFJHR1,
c.HKSZD2,
c.XZZ2,
c.LXDH2,
c.mzmc2,
c.gzdw2,
c.zw2,
c.JK_UUID,
c.org_id,
c.xxid,
c.xszt,
s.ssjd
from jc_xs c
left join jc_class d on c.BJID = d.BJID
left join jc_xx S on c.xxid = S.ORG_ID
/

