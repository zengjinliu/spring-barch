create view V_JC_XS_CJ as
select t."XSID",t."XM",t."YWXM",t."XMPY",t."CYM",t."XBM",t."CSRQ",t."CSDM",t."CSD",t."JG",t."MZM",E1.DMMX_MC AS MZ,t."GJDQM",t."SFZJLXM",t."SFZJH",t."HYZKM",t."GATQWM",t."ZZMMM",t."JKZKM",t."XYZJM",t."XXM",t."ZP",t."SFZJYXQ",t."SFDSZN",t."HKSZDM",t."HKSZD",t."HKSZD_ADDR",t."HKXZM",t."XZZ",t."TXDZ",t."JTZZ",t."DH",t."YDDH",t."FB_STATE",t.Xx_State,T.XXORG_ID AS ORG_ID,T.xjnjdm from jc_xs_cj t LEFT JOIN JC_DMMX E1 ON T.MZM = E1.DMMX_CODE AND E1.DM_CODE = 'DM_MZ'
/

