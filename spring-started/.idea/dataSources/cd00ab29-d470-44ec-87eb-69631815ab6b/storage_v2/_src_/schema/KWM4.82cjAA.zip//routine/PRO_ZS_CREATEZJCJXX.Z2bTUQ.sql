create Procedure pro_zs_createzjcjxx
is
  v_maxdate date;--最大时间
  v_nowdate date;--当前时间
begin
   --获取当前时间
   v_nowdate:=sysdate;

   --取出存在的最大的时间
   select max(gxsj) into v_maxdate from zjcj_zjxxs;

   --如果最大时间为空 将最大时间减去一年
   if v_maxdate is null then
     v_maxdate := add_months(sysdate, -12);
   end if;

    --没新增过的新增
    insert into zjcj_zjxxs(xsid,zjxxs,gxsj,sfcj)
    select
    a.xsid,
    (select wm_concat(e.zjmc) from zjcj_zjxx d
    left join zjcj_zj e on e.zjid=d.zjid
    where d.yw_pkid=a.xsid and d.status='1'
    ),
    v_nowdate,
    '1'
    from
    zs_xsxx a
    where
    exists (select 1 from zjcj_zjxx c where c.yw_pkid=a.xsid and c.status='1')
    and not exists (select 1 from zjcj_zjxxs b where b.xsid=a.xsid);

    --新增过的又更新过的进行修改
    update zjcj_zjxxs a
    set
    a.zjxxs=(select wm_concat(e.zjmc) from zjcj_zjxx d left join zjcj_zj e on e.zjid=d.zjid where d.yw_pkid=a.xsid and d.status='1'),
    a.gxsj=v_nowdate
    where
    exists (select 1 from zjcj_zjxx c where c.yw_pkid=a.xsid and c.status='1' and c.xzsj>v_maxdate);
    --修改学生表的sfcj字段
    /*update zs_xsxx b
    set
    b.SFZJCJ='1'
    where
    exists (select 1 from zjcj_zjxx c where c.yw_pkid=b.xsid and c.status='1' and c.xzsj>v_maxdate);*/
    update zs_xsxx a set a.sfzjcj='1'
    where a.xsid in (
    select b.xsid from zs_xsxx b left join zjcj_zjxxs c on b.xsid=c.xsid where (b.sfzjcj is null or b.sfzjcj = '0') and c.sfcj = '1'
    );
   /*
   insert into zjcj_zjxxs
   select yw_pkid,wm_concat(zjmc),v_nowdate,'1' from zjcj_zjxx s
   where s.status='1' and not exists (select 1 from zjcj_zjxxs zz  where s.yw_pkid=zz.xsid) and xzsj<v_maxdate group by yw_pkid;

   update zjcj_zjxxs zs
   set (zjxxs,gxsj)=(select wm_concat(zjmc),v_nowdate from zjcj_zjxx s where s.status='1' and zs.xsid=s.yw_pkid and xzsj<v_maxdate group by yw_pkid)
   where exists (select 1 from zjcj_zjxx zx where zs.xsid=zx.yw_pkid) ;
   */
   commit;
 end;
/

