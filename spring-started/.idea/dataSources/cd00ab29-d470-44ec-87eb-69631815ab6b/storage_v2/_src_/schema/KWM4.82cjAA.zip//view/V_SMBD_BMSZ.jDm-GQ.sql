create view V_SMBD_BMSZ as
select a.bmid,a.bmmc,a.bmdm,a.bz,a.status,a.xzr,a.xzsj,
a.cols,a.tj,colmcs,a.ORGID,a.SSBMDM,a.ORGID ORG_ID,b.ORG_MC,a.INSERT_SQL,a.DELETE_SQL,SSBMDZ,SSJGSJ,RINSERT_SQL,RDELETE_SQL,XH,ISZJGPD,RINSERTSBYS_SQL
,ISHCBM,HCBMJG_SQL,RUPDATESBYS_SQL,BDYHZDSZ
from smbd_bmsz a
left join jc_org b on a.orgid=b.org_id and b.org_state='1'
where a.status='1'
/

