create view V_SMBD_ZH_ZLSHXX as
select a.XSID,a.XM,a.SFZJLXM,a.SFZJH,a.ZZZH,a.XBM,a.CSRQ,a.MZM,a.CSDM,
nvl(a.CSD,'') CSD,nvl(a.JG,'') JG,a.HKSZDM,nvl(a.HKSZD,'') HKSZD,
nvl(a.XZZ,'') XZZ,a.TXDZ,
nvl(a.JTZZ,'') JTZZ,
a.LXDH,a.JDFSM,a.HKXZM,a.SFYHDX,nvl(a.YHDXM,'') YHDXM,a.HKBHZ,a.HKSSPCS,a.HKXXDZ,a.HZGX,a.YZBM,a.ZZMMM,a.GJDQM,a.LSH,a.PWD,a.JKZK,
a.XWLB,a.SFDQ,a.SFLSETM,a.GATQWM,a.SFSQZNM,a.SFSGXQJYM,a.SFGE,a.SFLSHYFZN,a.BYXXBZ,a.BYXXMC,a.SFFCTP,a.SFBL,
a.BLYY,a.FCLB,nvl(a.CQR,'') CQR,a.CHZR,a.CQR_SFZJH,nvl(a.FCZH,'') FCZH,a.FCFZDW,a.FCDZ,a.DJBARQ,a.FZRQ,a.CZR,a.ZLKSRQ,a.ZLJSRQ,a.FCFE,
a.ZLBADW,a.JT_RELAT1,a.JT_XM1,a.JT_SFZJLX1,a.JT_SFZJH1,a.JT_MZ1,a.JT_HKSZDM1,a.JT_HKSZD1,a.JT_LXDH1,a.JT_GZDW1,
a.JT_SBDNH1,a.JT_CBRQ1,
nvl(a.JT_RELAT2,'') JT_RELAT2,nvl(a.JT_XM2,'') JT_XM2,nvl(a.JT_SFZJLX2,'') JT_SFZJLX2,
nvl(a.JT_SFZJH2,'') JT_SFZJH2,nvl(a.JT_MZ2,'') JT_MZ2,nvl(a.JT_HKSZDM2,'') JT_HKSZDM2,nvl(a.JT_HKSZD2,'') JT_HKSZD2,
nvl(a.JT_LXDH2,'') JT_LXDH2,nvl(a.JT_GZDW2,'') JT_GZDW2,nvl(a.JT_SBDNH2,'') JT_SBDNH2,
nvl(a.HJLXM,'') HJLXM,nvl(a.JT_HJLXM1,'') JT_HJLXM1,nvl(a.JT_HJLXM2,'') JT_HJLXM2,
nvl(a.DXQID,'') DXQID,a.JT_ZSJZNX1,a.JT_ZSJZNX2,a.JT_JZZQFRQ1,
a.JT_JZZQFRQ2,a.JT_YLBXYS1,a.JT_YILBXYS1,a.JT_YLBXYS2,a.JT_YILBXYS2,a.JT_SBLJYS1,a.JT_SBLJYS2,a.ZF_ISSFZH2,a.CQRGX,
a.JT_QRSZSJ1,a.JT_QRSZSJ2,a.ZF_CHZRGX,a.ZF_BADWBSC,a.ZF_ZLYT,a.ZF_ISXQ,a.ZF_ISWFZM,a.ZF_ZLLJYS,a.ZF_JHTBAH,a.ZF_JHTBARQ,
a.ZF_JHTCHZR,a.ZF_HJISQR,nvl(a.JS_QK,'') JS_QK,a.JS_FZBSC,a.JS_FZDW,a.FWID,a.JT_SBFZDW1,a.JT_SBFZDW2,a.ZF_ISKFZM,a.ZF_KFZMYS,
a.ZF_JTSSDWMC,a.NJDM,a.ZF_ZLMJ,a.JT_JYLX1,a.JT_JYLX2,a.ZF_QRSZSJ,a.XZSJ,a.XZR,a.JT_CBRGX,a.JT_CBR,
a.JT_CBRSFZJH,a.YHXQJF,a.SQLB,a.JT_JZZH1,a.JT_JZZH2,a.XQJF_JS,a.ZF_OLDFCLB,a.ZF_JHTJSRQ,a.LOCKID,a.TSBJ,a.BYXXLB,
a.JS_GZSH,a.ZF_FCQBM,a.ZF_FCQMC,a.ZF_JDMC,a.ZF_LDMC,
nvl(a.HJLXMC,'') HJLXMC,nvl(a.JT_HJLX1,'') JT_HJLX1,nvl(a.JT_HJLX2,'') JT_HJLX2,
nvl(a.JT_ISJZZH1,'') JT_ISJZZH1,nvl(a.JT_ISJZZH2,'') JT_ISJZZH2,a.YHJFGXSJ,a.YHJFGXR,a.ZXTBLDID,a.ZF_HKSFYQ,
nvl(a.JT_ZYZGDM1,'') JT_ZYZGDM1,nvl(a.JT_ZYZGBH1,'') JT_ZYZGBH1,nvl(a.JT_WHCDDM1,'') JT_WHCDDM1,
nvl(a.JT_WHCDBH1,'') JT_WHCDBH1,nvl(a.JT_WHCDBGBH1,'') JT_WHCDBGBH1,nvl(a.JT_BYXXMC1,'')JT_BYXXMC1,
nvl(a.JT_ZYZGDM2,'') JT_ZYZGDM2,nvl(a.JT_ZYZGBH2,'') JT_ZYZGBH2,nvl(a.JT_WHCDDM2,'') JT_WHCDDM2,
nvl(a.JT_WHCDBH2,'') JT_WHCDBH2,nvl(a.JT_WHCDBGBH2,'') JT_WHCDBGBH2,
nvl(a.JT_BYXXMC2,'') JT_BYXXMC2,nvl(a.JFXM,'') JFXM,nvl(a.ZF_YWFC,'') ZF_YWFC,
nvl(a.JFX_JHR,'') JFX_JHR,nvl(a.JFX_JYORWH,'') JFX_JYORWH,nvl(a.FCLBMC,'') FCLBMC,nvl(a.GJDQMC,'') GJDQMC,
nvl(a.JT_MZMC2,'') JT_MZMC2,nvl(a.JT_MZMC1,'') JT_MZMC1,nvl(a.MZMC,'') MZMC,
nvl(a.ZCDQ,'') ZCDQ,nvl(a.YJDXX,'') YJDXX,nvl(a.YJDNJ,'') YJDNJ,a.XCODE,a.YJDQX,a.YJDXXID,a.YJDQXMC,
nvl(a.JT_JZZHLJYS,'') JT_JZZHLJYS,
decode(a.xbm,'0','未知的性别','1','男','2','女','9','未知的性别','') XB,
decode(a.hkxzm,'1','农业','2','非农业','') HKXZMC,
decode(a.SFDQ,'0','否','1','是','') SFDQMC,
decode(a.jt_relat1,'01','父亲','02','母亲','07','其他法定监护人','') JT_RELATMC1,
decode(a.jt_relat2,'01','父亲','02','母亲','07','其他法定监护人','') JT_RELATMC2,
decode(a.JT_ZYZGDM1,'01','一级','03','三级','02','二级','04','四级','') JT_ZYZGMC1,
decode(a.JT_WHCDDM1,'01','大专','02','本科及以上学历','03','大专以下','') JT_WHCDMC1,
decode(a.ZF_YWFC,'01','有','02','无','') ZF_YWFCMC,a.sqxxid1 sqxxid,a.sqxxmc1 sqxxmc,a.shzt,
case when a.TSBJ='珠海户籍学生' or a.TSBJ='珠海户籍跨区报读学生' then 'ZH'
when a.TSBJ='政策性照顾生' or a.TSBJ='在珠海工作居住的港澳籍人员子女' or a.TSBJ='异地务工人员随迁子女积分入学' or a.TSBJ='父母有一方为珠户的非我市户籍子女' then 'FZH' else '0' end ISZH,
case when a.TSBJ='珠海户籍学生' or a.TSBJ='珠海户籍跨区报读学生' then 'ZH'
     when a.TSBJ='政策性照顾生' then 'YHDX'
     when a.TSBJ='在珠海工作居住的港澳籍人员子女' then 'GA'
     when a.TSBJ='异地务工人员随迁子女积分入学' or a.TSBJ='父母有一方为珠户的非我市户籍子女' then 'JFRX'
     else '0' end xslb,nvl(a.XQJF,'') XQJF,nvl(a.JFMX,'') JFMX,a.ISSDXGJF,a.zjg,a.app_id,by4
,
case when a.cqrgx in('01','02','03') then '1' else '0' end cqrisfm,
--房产
nvl(substr(d.RSJ11,0,10),'') v_fcfzrq,nvl(d.rsj1,'') v_fccode,
case d.rsj1 when '1' then '查询成功有房'　when '2' then '查询失败'　when '5' then '查询无房' when '0' then '系统错误' else ''　end v_yfcyh,--有房产验核结果
nvl(to_char(d.RSJ_CLOB1),'')　v_gyrxx,--共有人信息
--无房产
case k.RSj3 when '０' then '无房产' when '1' then '有一套房产' when '2' then '有多套房产' else '' end v_wfcyh,　--无房产验核结果
--居住证/珠户
nvl(e.RSJ12,0) v_jt_jzzhljys1,nvl(f.RSJ12,0) v_jt_jzzhljys2,
nvl(e.RSJ6,'') v_jzzh1,nvl(f.RSJ6,'') v_jzzh2,
nvl(e.RSJ3,'') v_hasjzz1,nvl(f.RSJ3,'') v_hasjzz2,
nvl(e.RSJ13,'') v_jzzxxxx1,nvl(f.RSJ13,'') v_jzzxxxx2,
e.RSJ3 iszh1,f.RSJ3 iszh2,--是否珠户
e.RSJ9 rhsj1,f.RSJ9 rhsj2,--入户时间
--社保
nvl(h.RSJ9,0) v_jbylljys1,nvl(i.RSJ9,0) v_jbylljys2,
nvl(h.RSJ10,0) v_jbyilljys11,nvl(i.RSJ10,0) v_jbyilljys12,
nvl(h.RSJ11,0) v_jbyilljys21,nvl(i.RSJ11,0) v_jbyilljys22,
nvl(h.RSJ12,0) v_shiybxljys1,nvl(i.RSJ12,0) v_shiybxljys2,
nvl(h.RSJ13,0) v_gsbxljys1,nvl(i.RSJ13,0) v_gsbxljys2,
nvl(h.RSJ14,0) v_sybxljys1,nvl(i.RSJ14,0) v_sybxljys2,
nvl(h.RSJ1,0) v_sbyhjg1,nvl(i.RSJ1,0) v_sbyhjg2,
--计生
nvl(j.RSJ1,'') v_jscode,decode(j.RSJ1,'1','查无此人','2','符合计划生育政策','3','政策外出生子女,待核实社会抚养费缴纳情况','4','违反计生政策，且未缴清费用','5','违反计生政策，但已缴清费用','') js_qkmc

,nvl(l.ZF_FCZYS,'') ZF_FCZYS,nvl(l.ZF_FCJF,'') ZF_FCJF,
nvl(l.JZZLJYS,'') JZZLJYS,nvl(l.JZZH,'') JZZH,nvl(l.JZZJF,'') JZZJF,nvl(l.BJJF,'') BJJF,
nvl(l.jbyilljys,'') jbyilljys,
nvl(l.JBYLJF,'') JBYLJF,nvl(l.JBYILJF,'') JBYILJF,nvl(l.SHIYBXJF,'') SHIYBXJF,
nvl(l.GSBXJF,'') GSBXJF,nvl(l.SYBXJF,'') SYBXJF,nvl(l.SBLJYS,'') SBLJYS,nvl(l.SBJF,'') SBJF,
nvl(l.JSJF,0) JSJF,
decode(n.RSJ3,'false','非珠户','true','珠户','') xs_iszhmc,
nvl(n.RSJ11,'') HH,nvl(n.RSJ7,'') HZ,nvl(n.RSJ8,'') hz_relat
from zs_xsxx a
left join smbd_sj n on n.sjid=a.xsid and n.sstype='101' and n.sj2=a.sfzjh and n.bmid in(select bmid from smbd_bmsz sz where sz.bmdm in('ZHHJ','FZHHJ') and sz.status='1')
left join smbd_sj e on e.sjid=a.xsid and e.sstype='101' and e.sj2=a.jt_sfzjh1 and e.bmid in(select bmid from smbd_bmsz sz where sz.bmdm in('JHR1HJ') and sz.status='1')
left join smbd_sj f on f.sjid=a.xsid and f.sstype='101' and f.sj2=a.jt_sfzjh2 and f.bmid in(select bmid from smbd_bmsz sz where sz.bmdm in('JHR2HJ') and sz.status='1')
left join smbd_sj h on h.sjid=a.xsid and h.sstype='102' and h.sj1=a.jt_sfzjh1 and h.bmid in(select bmid from smbd_bmsz sz where sz.bmdm in('ZHSBBM1') and sz.status='1')
left join smbd_sj i on i.sjid=a.xsid and i.sstype='102' and i.sj1=a.jt_sfzjh2 and i.bmid in(select bmid from smbd_bmsz sz where sz.bmdm in('ZHSBBM2') and sz.status='1')
left join smbd_sj d on d.sjid=a.xsid and d.sstype='103'
left join smbd_sj k on k.sjid=a.xsid and k.sstype='104'
left join smbd_sj j on j.sjid=a.xsid and j.sstype='105'
left join zs_jfmx_zh_notupdate l on l.xsid=a.xsid
/

