create view V_JC_SJTB_MB as
select
m.mbid,m.ywlx,m.ywlx ywlxmc,m.mbbh,m.mbmc,m.mbbz,m.mbszfs,m.mbpath,m.xzr,m.xzsj,m.gxr,m.gxsj,m.org_id,m.app_id,m.yxzt,m.xh,
a.app_mc,m.lxdm1,m.lxmc1,m.lxdm2,m.lxmc2,m.lxdm1 czlx,
case when exists(select 1 from jc_sjtb s where s.mbid=m.mbid and s.yxzt = '1') then '1' else '0' end isuse,
o.org_mc
from jc_sjtb_mb m
left join jc_org o on o.org_id = m.org_id
left join jc_app a on a.app_id = m.app_id
where m.yxzt='1'
/

