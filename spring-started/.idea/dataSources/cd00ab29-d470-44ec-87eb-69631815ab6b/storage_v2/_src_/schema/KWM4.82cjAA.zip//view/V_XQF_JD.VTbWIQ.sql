create view V_XQF_JD as
select a.JDID,a.JDDM,a.JDMC,a.YXZT,a.XZR,a.XZSJ,a.GXR,a.GXSJ,A.ORG_ID
from xqf_jd a
where a.yxzt='1'
/

