create function FN_DATE_TOSTRFORMAT(input_date date,format varchar2) return varchar2 is kwstr varchar2(32);
begin
  kwstr := to_char(input_date,format);
return kwstr;
end FN_DATE_TOSTRFORMAT;
/

