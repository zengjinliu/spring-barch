create view V_ZS_XSXX_DRXJ as
    select a.SFZH SFZJH,'1' type,b.XXCODE,'' ZX_YEAR,'' TREM,sc.XXNAME  from emis.x_jbqk a inner join emis.x_zxqk b on b.jbqk_id=a.jbqk_id and b.zxzk='是'
left join emis.a_school sc on sc.xxcode=b.xxcode
union all
select stu.SFZH SFZJH,'2' type,stu.XXCODE,'' ZX_YEAR,'' TREM,stusc.XXNAME  from emis.x_student stu left join emis.a_school stusc on stusc.xxcode=stu.xxcode
union all
select zr.SFZH SFZJH,'3',zr.XXCODE,zr.ZX_YEAR,zr.TREM,zrsc.XXNAME from emis.zr_jbqk zr left join emis.a_school zrsc on zrsc.xxcode=zr.xxcode where to_char(zr.register_d,'yyyy')=to_char(sysdate,'yyyy')
/

