create view V_JC_WJDC_WT as
select t1.WT_ID,t1.TPL_ID,t1.WT_CONTENT,t1.WT_TYPE,t1.WT_ORDER,t2.tpl_title,t1.wt_required from jc_wjdc_wt t1
left join jc_wjdc_tpl t2 on t1.tpl_id = t2.tpl_id
/

