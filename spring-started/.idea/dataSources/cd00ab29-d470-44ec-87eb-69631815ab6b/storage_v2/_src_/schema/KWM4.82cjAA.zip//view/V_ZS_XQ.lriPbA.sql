create view V_ZS_XQ as
select
  Q.XQID,
  Q.ORG_ID,
  Q.XQMC,
  Q.BZ,
  O.ORG_DM as XXDM,
  o.org_mc as XXMC,
  O.ORG_DM,
  O.ORG_MC,q.STATUS
    from ZS_XQ Q
    LEFT JOIN JC_XX X ON Q.ORG_ID = X.ORG_ID
    LEFT JOIN JC_ORG O ON Q.ORG_ID = O.ORG_ID
    WHERE Q.STATUS = '1'
/

