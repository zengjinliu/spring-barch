create view V_TSJY_XJ_XS as
SELECT  nvl(to_char(xsid),xq_xsid) as XSID,JO.ORG_ID,T.NAME as XM,T.SEX as XB,T.SFZH as SFZJH,T.XJCODE XJFH,
T.XXNAME as XXMC,T.GNAME AS NJMC,T.CNAME AS BJMC,t.jkzkm,t.jhrxm,t.jhrsj,j1.dmmx_code as njdm，
DECODE(T.JKZKM ,'0','残疾','1','健康或良好') AS JKZKMC
FROM tsjy_xs_temp T
left join jc_org jo on jo.org_dm = t.xxcode
left join jc_dmmx j1 on t.gname = j1.dmmx_mc and j1.dm_code='DM_NJDM' and j1.dmmx_state='1'
/

