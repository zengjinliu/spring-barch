create view V_ZS_LGLQ as
select
a.xsid,
a.xm,
a.sfzjh,
case when nvl(a.yhxqjf,0)>0 then a.yhxqjf else a.xqjf end xqjf,
a.hjlxm,
a.hjlxmc,
case when a.hjlxm in ('07','01','02','05') or (a.sfyhdx='1' and a.yhdxm='海外华侨') then '1' else '0' end hjlx,
case when a.hjlxm in ('07','05') then 'Y' else 'N' end is_xq,
decode(a.xwlb,'第一类型','A','第二类型','B','第三类型','C','第四类型','D','第五类型','E','第六类型','F','第七类型','G','H') xwlb,
decode(a.xwlb,'第一类型',100,'第二类型',95,'第三类型',90,'第四类型',80,'第五类型',75,'第六类型',70,'第七类型',60,0) jcf,
nvl(a.yddjf1,0) yddjf1,
a.fclb,
decode(a.fclb,'01','01',
'02','02',
'03','13',
'04','03',
'05','04',
'06','03',
'08','08',
'09','12',
'10','06',
'11','06',
'12','06',
'13','06',
'14','07',
'17','11',
'26','10',
'27','10',
'28','10',
'05') zf_fclb,
case
when a.FCLB in('01','03','04','06','33','39','52','53','54','22','24') and nvl(sm.rsj4,'null')<>'null' then to_date(sm.rsj4,'yyyy-MM-dd')
when a.FCLB in('08','09') and nvl(sm2.rsj3,'null')<>'null' then to_date(substr(sm2.rsj3,0,10),'yyyy-MM-dd')
--购房合同不作为同分排序的条件
when a.fclb='02' then null
else nvl(a.fzrq,a.djbarq) end zf_fzdate,
case when sm2.rsj3 is not null then to_date(substr(sm2.rsj3,0,10),'yyyy-MM-dd') else a.djbarq end zf_djbad,
case when sm3.rsj5 is not null then to_date(sm3.rsj5,'yyyy-MM-dd') else a.zf_qrszsj end zf_qrdate,
--验核结果
decode(d.rsj3,'独生子女','A','政策内或全面二孩','B','有政策外出生但已接受处理','C','D') js_qk,
/*
--初始结果
decode(a.js_qk,'独生子女','A','政策内或全面二孩','B','政策外但已接受处理','C','D') js_qk,
*/
case when a.hjlxm in ('03','04','06') then '1' else '' end jt_jylb,
--验核结果
sm4.rsj16 jynx,
/*
--初始结果
a.JT_SBLJYS1 jynx,
*/
a.hkszdm,
a.hkszd,
a.sqxxid1,
a.sqxxid2,
a.sqxxid3,
a.sqxxid4,
a.sqxxmc1,
a.sqxxmc2,
a.sqxxmc3,
a.sqxxmc4,
a.zf_qddx,
decode(a.sfyhdx,'1','Y','N') isyhdx,
case when a.sfyhdx='1' then a.yhdxm else '' end yhdx,
a.njdm,
case when a.hjlxm in ('07','01','05') then 100 when a.hjlxm='02' then 200 else 300 end x_szhj2,
a.ylqzt,
a.ylqxx,a.lqzt,a.app_id,a.shzt,a.sfcssj,a.zjg,a.ylq_orgid ylqxxid,a.lq_orgid lqxxid,
--杨美直升
case when a.sqxxid1='263a9db9fc434cb78e2b67ce656e415d' and exists (select 1 from zs_lglq_zssj b where b.sfzh=a.sfzjh) then '1' else '0' end sfzs
from
zs_xsxx a
left join kwm4.smbd_shjg d on d.xsid=a.xsid and d.bmid='6B7234DBDAE3347BE053BC09A8C016E9'
left join kwm4.smbd_shjg sm on sm.xsid=a.xsid and sm.bmid='6B7234DBDAD8347BE053BC09A8C016E9'
left join kwm4.smbd_shjg sm2 on sm2.xsid=a.xsid and sm2.bmid='6B7234DBDADA347BE053BC09A8C016E9'
left join kwm4.smbd_shjg sm3 on sm3.xsid=a.xsid and sm3.bmid='6C4EC47998402C54E0530100007FB4D6'
left join kwm4.smbd_shjg sm4 on sm4.xsid=a.xsid and sm4.bmid='6B7234DBDAD7347BE053BC09A8C016E9'

--left join kwm4.smbd_sj d on d.bmid='6B7234DBDAE3347BE053BC09A8C016E9' and d.sjid=a.xsid
--left join kwm4.smbd_sj sm on sm.sjid=a.xsid and sm.bmid='6B7234DBDAD8347BE053BC09A8C016E9'
--left join kwm4.smbd_sj sm2 on sm2.sjid=a.xsid and sm2.bmid='6B7234DBDADA347BE053BC09A8C016E9'
--left join kwm4.smbd_sj sm3 on sm3.sjid=a.xsid and sm3.bmid='6C4EC47998402C54E0530100007FB4D6'
--left join kwm4.smbd_sj sm4 on sm4.sjid=a.xsid and sm4.bmid='6B7234DBDAD7347BE053BC09A8C016E9'
where
exists (select 1 from jc_org_relat b where b.org_id_child=a.sqxxid1 and b.org_id='b3c2fbca21a24a8e88d493fe3f5c781a')
--61DBC3F71A377A99E0530100007FBE2D	SZLGGBXYZS	深圳市龙岗区公办小一招生管理系统
--61DBC3F71A387A99E0530100007FBE2D	SZLGGBCYZS	深圳市龙岗区公办初一招生管理系统
and a.app_id='61DBC3F71A377A99E0530100007FBE2D'
and a.sfcssj='0'
and a.shzt='2'
and a.zjg='1'
and nvl(a.lqzt,'1')<>'2'
/

