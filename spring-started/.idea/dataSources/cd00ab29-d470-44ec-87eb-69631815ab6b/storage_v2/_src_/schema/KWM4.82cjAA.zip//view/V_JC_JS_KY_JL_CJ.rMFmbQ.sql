create view V_JC_JS_KY_JL_CJ as
SELECT  zs.jsky_id as zsid,t1.jsky_id,t1.js_id,t1.xzr,t1.xzsj,t1.gxr,t1.gxsj,t1.status,t1."JLLB",t1."HJNY",t1."JLMC",t1."JLDJ",t1."JLQTDJ",t1."BRPM",t1."SJGJ",t1."SJDW",t2.dmmx_mc dmmx_JLLB_mc,t3.dmmx_mc dmmx_JLDJ_mc,t4.dmmx_mc dmmx_SJGJ_mc,t5.dmmx_mc dmmx_BRPM_mc FROM JC_JS_KY_JL_CJ T1
LEFT JOIN jc_js_ky_jl zs ON T1.JSKY_ID = zs.jsky_id
LEFT JOIN JC_DMMX T2 ON T1.JLLB = T2.DMMX_CODE AND T2.DM_CODE = 'DM_JLLB'
LEFT JOIN JC_DMMX T3 ON T1.JLDJ = T3.DMMX_CODE AND T3.DM_CODE = 'DM_JLDJ'
LEFT JOIN JC_DMMX T4 ON T1.SJGJ = T4.DMMX_CODE AND T4.DM_CODE = 'DM_GJDQ'
LEFT JOIN JC_DMMX T5 ON T1.BRPM = T5.DMMX_CODE AND T5.DM_CODE = 'DM_BRPM'
/

