create view V_JC_JS_KY_ZS_CJ as
SELECT zs.jsky_id as zsid,t1.jsky_id,t1.js_id,t1.xzr,t1.xzsj,t1.gxr,t1.gxsj,t1.status,t1."ZSH",t1."BRJS",t1."YYZSMC",to_char(t1."PZSJ",'YYYY-MM-DD')as PZSJ,to_char(t1."YXQ",'YYYY-MM-DD')as YXQ,t2.dmmx_mc dmmx_BRJS_mc FROM JC_JS_KY_ZS_CJ T1
LEFT JOIN jc_js_ky_zs zs ON T1.JSKY_ID = zs.jsky_id
LEFT JOIN JC_DMMX T2 ON T1.BRJS = T2.DMMX_CODE AND T2.DM_CODE = 'DM_BRJS'
/

