create function FN_SFZJH_18TO15(sfzjh VARCHAR) return VARCHAR is RETSFZJH VARCHAR(100);
begin
  RETSFZJH := substr(sfzjh,1,6)|| substr(sfzjh,9,9);
return RETSFZJH;
end FN_SFZJH_18TO15;

/

