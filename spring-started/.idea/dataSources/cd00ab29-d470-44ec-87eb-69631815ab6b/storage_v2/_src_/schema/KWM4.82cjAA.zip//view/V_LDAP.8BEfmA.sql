create view V_LDAP as
select ju.JK_UUID,ju.U_USERID,ju.U_PWD,ju.XM,ju.XZSJ ,jg.org_id,decode(jg.org_id,'6CD60A4A91B7599CE0530100007F0ABB','HS','90c6e34d999f4931a0b1cf63a05a8f44','MS')AS XB from jc_jg jg
left join jc_user ju on jg.user_id= ju.u_id
where jg.state='1'
/

