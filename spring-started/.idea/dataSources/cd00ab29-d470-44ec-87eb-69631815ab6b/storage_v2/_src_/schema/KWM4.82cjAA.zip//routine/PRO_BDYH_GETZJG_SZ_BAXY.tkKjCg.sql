create PROCEDURE PRO_BDYH_GETZJG_SZ_BAXY(p_appid in varchar2) IS
  cursor c_list is   SELECT xsid from  ZS_XSXX where app_id = p_appid and ZJG = '0' and SHZT = '2';
  xs c_list%rowtype;
  v_xsid varchar(32);
BEGIN
    open c_list;
    loop fetch c_list into xs;
      exit when c_list%notfound;
        v_xsid := xs.xsid;
        pro_bdyh_getzjg_sz_byxsid_in(v_xsid,'sys');
      end loop;
      close c_list;
end PRO_BDYH_GETZJG_SZ_BAXY;
/

