create procedure procedure_jszg -- 创建存储过程 教师资格
  as
   tbsj date;
  begin
  select max(time_bz) into tbsj from gz_sjjh.JS_TB_BIZ_JSZGXX;
  delete from JC_JS_ZG b where exists   (select 1 from  gz_sjjh.JS_TB_BIZ_JSZGXX a where a.id=b.jszg_id and a.TIME_BZ> ( select c.updatetime from JC_DATA_TIME c  where c.model_type = 'JC_JS_ZG'));
  insert into JC_JS_ZG b (JSZG_ID,JS_ID,ZGZZL,ZGZHM,RJXK,BZRQ,BZJG,ZCJL,STATUS,XZR,XZSJ)
  select j.id,
  JB.JSJB_ID,
  (select d2.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d2 where d2.zdbs='JSZGZZL' and d2.zdxbs = j.JSZGZZL),
  j.JSZGZHM,
  j.RJXK,
  case is_date_ymd(j.ZSBFRQ) when 1 then  to_date(j.ZSBFRQ , 'yyyy-mm-dd hh24:mi:ss') else null end,
  j.BFJG,
  j.SCZCJL,
  '1',
  'SJTB',
  sysdate
  from gz_sjjh.JS_TB_BIZ_JSZGXX j
  join JC_JS_JB JB
  on j.JSID = JB.JSJB_ID
  where j.SFSC = '0' and j.shzt='2' and j.TIME_BZ>(  select c.updatetime from JC_DATA_TIME c  where c.model_type = 'JC_JS_ZG');
  update JC_DATA_TIME set updatetime = tbsj where model_type = 'JC_JS_ZG';

   exception when others then
  dbms_output.put_line(sqlcode||'>>>>>>' || sqlerrm);
  commit;
end procedure_jszg;
/

