create view V_SMBD_SHJG_AO as
select a.jgid,a.xsid,a.bmdm,a.shjg,a.shjgmx,a.shr,a.shsj,b.bmid,b.ORGID ORG_ID,b.ishcbm,b.iszjgpd,
    (select APP_ID from ZS_XSXX where XSID = a.XSID) APP_ID
from smbd_shjg a
left join smbd_bmsz b on a.BMID=b.BMID
where b.status='1'
/

