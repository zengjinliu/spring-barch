create view V_YGST_JSD_YJD as
SELECT SUM(b.zje) zje,
SUM(b.ZKZJE) ZKZJE,
             b.xxid,
            a.org_mc XXMC,
            c.gysmc GYSMC,
            TO_CHAR(b.jsrq, 'yyyy-MM') ny,
            sum(b.xsyl) xsyl,
            sum(b.jssl) jssl,
            sum(b.jdsl) jdsl
from ygst_jsd b left join jc_org a on b.xxid=a.org_id left join ygst_gys c on c.gysid=b.gysid
group by TO_CHAR(B.jsrq, 'yyyy-MM'),a.org_mc,c.gysmc,b.xxid
/

