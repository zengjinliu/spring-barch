create procedure procedure_jzgjxxx -- 创建存储过程 教职工教学信息
  as
  tbsj date;
  begin
  select max(time_bz) into tbsj from gz_sjjh.JS_TB_BIZ_JZGJYJXXX;
  delete from JC_JS_JX b where exists   (select 1 from  gz_sjjh.JS_TB_BIZ_JZGJYJXXX a where a.id=b.jsjx_id and a.TIME_BZ> ( select c.updatetime from JC_DATA_TIME c  where c.model_type = 'JC_JS_JX'));
  insert into JC_JS_JX b (JSJX_ID,JS_ID,JXND,JXXQ,RJXD,RKZK,QTRKZK,RJKC,RKXKLB,MZKS,QTGZ,MZQTGZZHKS,JRGZ,JRGZMC,SFWBKSK,DSLB,CSXKLY,JXKS,QTGZZHKS,STATUS,XZR,XZSJ)
  select j.id,
      JB.JSJB_ID,
      j.xn,
      (select d1.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d1 where d1.zdbs='XQ' and d1.zdxbs = j.xq)xq,
      (select d2.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d2 where d2.zdbs='RJXD' and d2.zdxbs = j.RJXD)RJXD,
      (select d3.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d3 where d3.zdbs='RKZK' and d3.zdxbs = j.RKZK)RKZK,
      j.Rkzkqtqk,
      (select d4.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d4 where d4.zdbs='RJKCZXX' and d4.zdxbs = j.RJKC)RJKCZXX,
      (select d5.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d5 where d5.zdbs='RKXKLB' and d5.zdxbs = j.RKXKLB)RKXKLB,
      case when j.Pjzks is null then 0 else to_number(j.Pjzks) end,
      j.Drdqtgz,
      case is_number(j.PJMZQTGZZHJXKSS) when 1 then to_number(j.PJMZQTGZZHJXKSS) else 0 end,
      (select d6.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d6 where d6.zdbs='JRGZ' and d6.zdxbs = j.JRGZ)JRGZ,
      j.JRQTGZMC,
      j.SFWBKSSK,
      j.Dslb,
      j.XZYCSXKLY,
      case when j.XNBZKKCJXKSS is null then 0 else to_number(j.XNBZKKCJXKSS) end,
      case when j.XNQTGZZHKSS is null then 0 else to_number(j.XNQTGZZHKSS) end,
      '1',
      'SJTB',
      sysdate
  from gz_sjjh.JS_TB_BIZ_JZGJYJXXX j
  join JC_JS_JB JB
  on j.JSID = JB.JSJB_ID
  where  j.SFSC = '0' and j.shzt='2' and j.TIME_BZ>(  select c.updatetime from JC_DATA_TIME c  where c.model_type = 'JC_JS_JX');
  update JC_DATA_TIME set updatetime = tbsj where model_type = 'JC_JS_JX';

   exception when others then
  dbms_output.put_line(sqlcode||'>>>>>>' || sqlerrm);
  commit;
end procedure_jzgjxxx;
/

