create view V_JC_JS_SD_RY_CJ as
SELECT zs.jssd_id as zsid,t1.op_id,t1.jssd_id,t1.js_id,t1.xzr,t1.xzsj,t1.gxr,t1.gxsj,t1.status,t1."RYJB",t1."RYCH",to_char(t1.RYFSRQ,'YYYY-MM-DD')as RYFSRQ,t1."RYJL",t1."RYSYDW",t2.dmmx_mc dmmx_RYJB_mc
 FROM JC_JS_SD_RY_CJ T1
 LEFT JOIN jc_js_sd_ry zs ON T1.JSSD_ID = zs.jssd_id
LEFT JOIN JC_DMMX T2 ON T1.RYJB = T2.DMMX_CODE AND T2.DM_CODE = 'DM_RYJB'
/

