create view V_ZS_ZJCJ_ZJ as
select zjid,
orgid,
zjmc,
zjlx,
bz,
sfzsxt,
dx,
cols,
col_mcs,
col_dm,
col_val,
status,
xzr,
xzsj,
gxr,
gxsj
from zjcj_zj a
/

