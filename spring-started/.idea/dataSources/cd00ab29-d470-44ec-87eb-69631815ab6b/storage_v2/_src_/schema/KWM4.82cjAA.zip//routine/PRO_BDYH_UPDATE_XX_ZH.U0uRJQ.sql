create PROCEDURE pro_bdyh_update_xx_zh is
begin
  --修改房产发证日期
  update zs_xsxx a set a.fzrq=(select to_date(b.recfinishtime,'yyyy-mm-dd') from bdyh_zh_fcxx b where b.xsid=a.xsid and b.code='1')
  where exists(select 1 from bdyh_zh_fcxx b and a.xsid=b.xsid and b.code='1');
  --修改居住证总月数
  update zs_xsxx a set a.jt_jzzhljys=(b.select recentm_count from bdyh_zh_hj b where b.xsid=a.xsid and b.recentm_count is not null and b.iszh='0')
  where exists(select 1 from bdyh_zh_hj b where b.xsid=a.xsid and b.recentm_count is not null and b.iszh='0');
  update zs_xsxx a set (a.jt_sbljys1,a.jt_sbljys2)=(select  from bdyh_zh_sb b where b.xsid=a.xsid and code='1')
end pro_bdyh_update_xx_zh;
/

