create view V_JC_JS_SD_KH as
SELECT t1.jssd_id,t1.js_id,t1.xzr,t1.xzsj,t1.gxr,t1.gxsj,t1.status,t1."SDKHJL",t1."SDKHDW",to_char(t1.SDKHSJ,'YYYY-MM-DD')as SDKHSJ,t2.dmmx_mc dmmx_SDKHJL_mc FROM JC_JS_SD_KH T1
LEFT JOIN JC_DMMX T2 ON T1.SDKHJL = T2.DMMX_CODE AND T2.DM_CODE = 'DM_KHJG'
/

