create view V_XQF_SQ as
select j.ORG_MC, a.org_id,a.jdid,a.sqid,a.jdmc,a.sqmc,a.sqdz,a.sqmc||'/'||a.sqdz sqqc,a.shzt from xqf_sq a JOIN JC_ORG j ON a.ORG_ID = j.ORG_ID
/

