create view V_TSJY_GAXL_YXXS as
select "JHID","JGID","CONTENT_ID","XSID","XM","XBM","SFZJH","SFZJYXQ","HKSZD","DH","XJFH","XXMC","NJMC","BJMC" from jc_content_jhcy j
LEFT JOIN  V_TSJY_XJ_XS t ON j.jgid = t.xsid
/

