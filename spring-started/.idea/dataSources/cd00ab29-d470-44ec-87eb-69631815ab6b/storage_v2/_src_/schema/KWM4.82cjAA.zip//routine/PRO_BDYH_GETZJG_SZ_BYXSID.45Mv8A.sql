create PROCEDURE PRO_BDYH_GETZJG_SZ_BYXSID(p_xsid in char,czr in varchar2) IS
  cursor c_list is select * from v_smbd_bmshjg v where v.xsid=p_xsid;
  xs c_list%rowtype;
  --部门游标
  cursor c_bmlist(quorgid String) is select * from smbd_bmsz a where a.orgid=quorgid and a.iszjgpd='1' order by a.xh;
  bm c_bmlist%rowtype;
  v_quorgid char(32);--区机构id
  v_xsid char(32);  --获取符合部门审核的学生id
  v_shjg varchar2(2);--各个部门审核结果
  v_zjgcount int;--是否存在总结果
  v_zjg varchar2(2);--总结果
  v_zjg_hg varchar2(1);--总结果(合格)
  v_zjg_wsh varchar2(1);--总结果(未审核)
  v_zjg_bhg varchar2(1);--总结果(不合格)
  v_selsql varchar2(10000);--查询学生是否符合的学生总数
  v_xscount int;--查询学生是否符合的学生总数的into参数
  v_selsql2 varchar2(10000);--查询学生符合部门的学生信息
  v_zlstate varchar2(2);--新租赁是否合格（3月31号之前合格、3月31号之后不合格）
  v_jzlstate varchar2(2);--旧租赁是否合格
  v_zlbasjsql varchar2(10000);--查询学生符合部门的学生信息
  v_zlbasj varchar2(20);--租赁登记备案日期
  v_yscode varchar2(6);--原始结果表里面的返回状态
  v_tj varchar2(10000);--各部门条件
  v_qrsj1 varchar2(2);--迁入时间中间值（其中一个迁入时间合格则合格）
  v_qrsj2 varchar2(2);--迁入时间中间值
  v_jzz1 varchar2(2);--居住证是否合格（其中一个居住证合格则合格）
  v_jzz2 varchar2(2);--居住证是否合格（其中一个居住证合格则合格）
  v_sh1 varchar2(2);--非深户监护人是否合格（其中一个合格则合格）
  v_sh2 varchar2(2);--非深户监护人是否合格（其中一个合格则合格）
  v_zl1  varchar2(2);--租赁是否合格
  v_zl2  varchar2(2);--租赁是否合格
  v_bzxzf1 varchar2(2);--保障性住房是否合格
  v_bzxzf2 varchar2(2);--保障性住房是否合格
  v_sb varchar2(2);--社保（罗湖、如果父母有一方深户合格 则社保合格）
BEGIN
  open c_list;
  loop fetch c_list into xs;
    exit when c_list%notfound;
      v_zjg:='-1';
      v_zjg_hg:='';
      v_zjg_wsh:='';
      v_zjg_bhg:='';
      v_zlstate:='-1';
      v_jzlstate:='-1';
      v_qrsj1:='-1';
      v_qrsj2:='-1';
      v_jzz1:='-1';
      v_jzz2:='-1';
      v_sh1:='-1';
      v_sh2:='-1';
      v_zl1:='-1';
      v_zl2:='-1';
      v_bzxzf1:='-1';--保障性住房是否合格
      v_bzxzf2:='-1';--保障性住房是否合格
      v_sb:='-1';
      --获取区机构id
      select org_id into v_quorgid from jc_org a where exists(select 1 from jc_org_relat b where b.org_id_child=xs.sqxxid1 and b.org_id=a.org_id) and a.org_dj='50' and exists (select 1 from jc_app_org d where d.app_id=xs.app_id and a.org_id=d.org_id);
      open c_bmlist(v_quorgid);
      loop fetch c_bmlist into bm;
      exit when c_bmlist%notfound;
           v_xscount:=0;
           v_xsid:='1';
           v_shjg:='';
           v_tj:='''';
           if(bm.tj is not null)then
                v_tj:=''' and '||bm.tj;
           end if;
           v_selsql := 'select count(*) cnt from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||bm.bmid||'''where jo.xsid='''||xs.xsid||v_tj;
           execute immediate v_selsql into v_xscount;
           if(v_xscount>0) then
               v_selsql2:= 'select * from (select nvl(jo.xsid,''1'') xsid,nvl(b.shjg,''0'') shjg from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||bm.bmid||'''where jo.xsid='''||xs.xsid||v_tj||') where ROWNUM=1';
               execute immediate v_selsql2 into v_xsid,v_shjg;
               if(v_xsid!='1') then
                 /*if(v_quorgid='b3c2fbca21a24a8e88d493fe3f5c781a') then--龙岗监护人1户籍迁入时间
                    if(bm.bmdm='JHRQRSJ1')then
                      v_qrsj1:=v_shjg;
                      v_shjg:='-1';
                    end if;
                    if(bm.bmdm='JHRQRSJ2')then
                      v_qrsj2:=v_shjg;
                      v_shjg:='-1';
                    end if;
                 end if;*/

                 --居住证(除开南山)
                 if(v_quorgid!='b8f9aa1578734cf0ba3b75bedd0c9743') then
                    if(bm.bmdm='JZZH1')then
                      v_jzz1:=v_shjg;
                      v_shjg:='-1';
                    end if;
                    if(bm.bmdm='JZZH2')then
                      v_jzz2:=v_shjg;
                      v_shjg:='-1';
                    end if;
                    if(bm.bmdm='JHRSH1')then
                      v_jzz1:=v_shjg;
                      v_sh1:=v_shjg;
                      v_shjg:='-1';
                    end if;
                    if(bm.bmdm='JHRSH2')then
                      v_jzz2:=v_shjg;
                      v_sh2:=v_shjg;
                      v_shjg:='-1';
                    end if;
                 end if;
                  if(v_quorgid!='606d6d7ba0c04f79b880d61c31214190' and v_quorgid!='54a9072368e34ce98bcc87454cb238ff') then--除开罗湖、福田
                    if(bm.bmdm='ZLBM')then--福田租赁合格特殊判断
                       v_zl1:=v_shjg;
                       v_shjg:='-1';
                    end if;
                    if(bm.bmdm='JZLHT')then--福田旧租赁合同特殊判断
                       v_zl2:=v_shjg;
                       v_shjg:='-1';
                    end if;
                 end if;
                 if(v_quorgid='606d6d7ba0c04f79b880d61c31214190') then--罗湖租赁合格特殊判断
                   if(bm.bmdm='ZLBM') then
                      if(v_shjg='2' and (xs.hjlxm='03' or xs.hjlxm='04' or xs.hjlxm='06')) then--租赁部门已经处理了结果才可对租赁部门进行判断
                        v_zlbasjsql:='select nvl(a.rsj3,''0'') rsj3,a.rsj1  from smbd_sj a where a.bmid='''||bm.bmid||''' and a.sjid='''||xs.xsid||'''';
                        execute immediate v_zlbasjsql into v_zlbasj,v_yscode;
                        if(v_zlbasj!='0' and v_yscode='1')then
                           select case when to_date(to_char(to_date(v_zlbasj,'yyyy-mm-dd HH24:mi:SS'),'yyyy-mm-dd'),'yyyy-mm-dd')<to_date(to_number(to_char(sysdate,'yyyy'))-1||'-05'||'-01','yyyy-mm-dd')
                                  then '3' else '4' end state into v_zlstate from dual;
                        else
                          v_zlstate:=v_shjg;
                        end if;
                        v_shjg:='-1';
                      else
                        v_zlstate:=v_shjg;
                        v_shjg:='-1';
                      end if;
                    elsif(bm.bmdm='JZLHT') then
                       v_jzlstate:=v_shjg;
                       v_shjg:='-1';
                    elsif(bm.bmdm='SBBM') then
                       v_sb:=v_shjg;
                       v_shjg:='-1';
                    end if;
                 end if;
                 if(v_quorgid='54a9072368e34ce98bcc87454cb238ff')then--福田租赁特殊判断
                     if(bm.bmdm='ZLBM') then
                      if(v_shjg='2') then--租赁部门已经处理了结果才可对租赁部门进行判断
                        v_zlbasjsql:='select nvl(a.rsj3,''0'') rsj3,a.rsj1  from smbd_sj a where a.bmid='''||bm.bmid||''' and a.sjid='''||xs.xsid||'''';
                        execute immediate v_zlbasjsql into v_zlbasj,v_yscode;
                        if(v_zlbasj!='0' and v_yscode='1')then
                           select case when (select c.islock from zs_xqf c where c.org_id=xs.sqxxid1)='1'  
                                             and to_date(to_char(to_date(v_zlbasj,'yyyy-mm-dd HH24:mi:SS'),'yyyy-mm-dd'),'yyyy-mm-dd')<
                                             to_date(to_number(to_char(sysdate,'yyyy'))-1||'-09'||'-30','yyyy-mm-dd') then '3'  
                                       when (select c.islock from zs_xqf c where c.org_id=xs.sqxxid1)='1' 
                                             and to_date(to_char(to_date(v_zlbasj,'yyyy-mm-dd HH24:mi:SS'),'yyyy-mm-dd'),'yyyy-mm-dd')>to_date(to_number(to_char(sysdate,'yyyy'))-1||'-09'||'-30','yyyy-mm-dd') 
                                             then '4' 
                                       when xs.HJLXM in('01','02','07','05') then '3' 
                                       when xs.HJLXM in('03','04','06') 
                                         and to_date(to_char(to_date(v_zlbasj,'yyyy-mm-dd HH24:mi:SS'),'yyyy-mm-dd'),'yyyy-mm-dd')<to_date(to_number(to_char(sysdate,'yyyy'))-1||'-12'||'-31','yyyy-mm-dd') 
                                      then '3' else '4' end state into v_zlstate from dual;
                        else
                          v_zlstate:=v_shjg;
                        end if;
                        v_shjg:='-1';
                      else
                        v_zlstate:=v_shjg;
                        v_shjg:='-1';
                      end if;
                    elsif(bm.bmdm='JZLHT') then
                       v_jzlstate:=v_shjg;
                       v_shjg:='-1';
                    end if;
                 end if;
                 --保障性住房
                 if(bm.bmdm='ANFBZF1' or bm.bmdm='ZZF1' or bm.bmdm='GGZLF1' or bm.bmdm='LZFGZF1') then
                     v_bzxzf1:=v_shjg;
                     v_shjg:='-1';
                 end if;
                 if(bm.bmdm='ANFBZF2' or bm.bmdm='ZZF2' or bm.bmdm='GGZLF2' or bm.bmdm='LZFGZF2')then
                      v_bzxzf2:=v_shjg;
                     v_shjg:='-1';
                 end if;
                 --判断结果
                 if(v_shjg='2') then
                    v_zjg_bhg:='2';
                 end if;
                 if(v_shjg='0') then
                    v_zjg_wsh:='0';
                 end if;
                 if(v_shjg='1') then
                    v_zjg_hg:='1';
                 end if;
               end if;
           end if;
      end loop;
      close c_bmlist;
      if(v_zjg_wsh='0') then--如果各个部门有未审核 则总结果为未审核
         v_zjg:=v_zjg_wsh;
      elsif (v_zjg_bhg='2') then
         v_zjg:=v_zjg_bhg;
      elsif (v_zjg_hg='1') then
         v_zjg:='1';
      end if;

      /*if(v_qrsj1='0' or v_qrsj2='0') then --迁入时间的个性化验证
         v_zjg:='0';
      elsif(v_qrsj1='2' and (v_qrsj2='2' or v_qrsj2='-1'))then
         v_zjg:='2';
      elsif(v_qrsj2='2' and (v_qrsj1='2' or v_qrsj1='-1')) then
         v_zjg:='2';
      end if;*/
      if(v_zjg!='0')then
        if(v_jzz1='0' or v_jzz2='0') then--居住证的个性化验证
           v_zjg:='0';
        elsif(v_jzz1='2' and (v_jzz2='2' or v_jzz2='-1'))then
           v_zjg:='2';
        elsif(v_jzz2='2' and (v_jzz1='2' or v_jzz1='-1'))then
           v_zjg:='2';
        end if;

        if(v_sh1='0' or v_sh2='0' or v_sb='0')then
           v_zjg:='0';
        elsif(v_sb='2' and ((v_sh1='2' and (v_sh2='2' or v_jzz2='2' or xs.isdxq='1')) or (v_sh2='2' and (v_sh1='2' or v_jzz1='2'))))then
           v_zjg:='2';
        elsif(v_sb='2' and v_sh1='-1' and v_sh2='-1')then
           v_zjg:='2';
        end if;

        if(v_zl1='0' or v_zl2='0')then--租赁个性化验证
          v_zjg:='0';
        elsif(v_zl1='2') then
          v_zjg:='2';
        end if;

        if(v_zlstate='0' or v_jzlstate='0')then--罗湖租赁个性化验证
          v_zjg:='0';
        elsif(v_zlstate='2') then
          v_zjg:='2';
        elsif(v_zlstate='4' and (v_jzlstate='2' or v_jzlstate='-1')) then
          v_zjg:='2';
        end if;

        if(v_bzxzf1='0' or v_bzxzf2='0')then--保障性住房
          v_zjg:='0';
        elsif(v_bzxzf1='2' and (v_bzxzf2='2' or v_bzxzf2='-1')) then
          v_zjg:='2';
        end if;

        if(v_zjg='-1')then
         v_zjg:='1';
        end if;
      end if;

      select count(*) into v_zjgcount from smbd_zjg a where a.xsid=xs.xsid;
      if(v_zjgcount=0) then
          insert into smbd_zjg(xsid,zjg,xzr,xzsj) values(xs.xsid,v_zjg,czr,sysdate);
          commit;
      else
          update smbd_zjg set zjg=v_zjg,gxr=czr,gxsj=sysdate where xsid=xs.xsid;
          commit;
      end if;
      update zs_xsxx a set a.zjg=v_zjg,a.zjgmc=(select dmmx_mc from jc_dmmx where dm_code='DM_ZS_SMBD_JG' and dmmx_code=v_zjg) where xsid=xs.xsid;
      commit;
  end loop;
  close c_list;
end PRO_BDYH_GETZJG_SZ_BYXSID;
/

