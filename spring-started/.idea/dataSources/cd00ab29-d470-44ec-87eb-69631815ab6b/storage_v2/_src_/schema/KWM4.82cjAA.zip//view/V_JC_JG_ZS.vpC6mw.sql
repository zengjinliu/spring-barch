create view V_JC_JG_ZS as
SELECT  case when exists (select 1 from jc_js_sh sh where sh.js_id=j.jgid and sh.sh_zt='1') then 'T'
else 'F' end flag ,"JGID",
       "GH",
       "XM",
       "YWXM",
       "XMPY",
       "CYM",
       "XBM",
       to_char("CSRQ", 'YYYY-MM-DD') as CSRQ,
       "CSDM",
       "JG",
       "MZM",
       "GJDQM",
       "SFZJLXM",
       "SFZJH",
       "HYZKM",
       "GATQWM",
       "ZZMMM",
       "JKZKM",
       "XYZJM",
       "XXM",
       "ZP",
       "SFZJYXQ",
       "SFDSZN",
       "YZBM",
       "TXDZ",
       "DH",
       "YDDH",
       j.CZDH,
       j.DZXX,
       "WLDZ",
       "JSTXH",
       GZDW,
       JZGLB,
       j.org_id,
       o.org_mc,
       j.XZR,
       j.XZSJ,
       j.GXR,
       j.GXSJ,
       j.STATE,
       t2.dmmx_mc dmmx_xb_mc,
       t3.dmmx_mc dmmx_sfzjlx_mc,
       o.org_mc xxmc

  from jc_jg j
  left join jc_org o
    on o.org_id = j.org_id
  LEFT JOIN JC_XX XX
    ON j.org_id = XX.ORG_ID
  LEFT JOIN JC_DMMX T2
    ON j.xbm = T2.DMMX_CODE
   AND T2.DM_CODE = 'DM_XB'
  LEFT JOIN JC_DMMX T3
    ON j.SFZJLXM = T3.DMMX_CODE
   AND T3.DM_CODE = 'DM_SFZJLX'
 where j.state != '0'
/

