create view V_JC_SJTB_SZ as
select
z.TBID,z.BH,z.MC,z.XZR,z.XZSJ,z.GXR,z.GXSJ,z.ORG_ID,z.APP_ID,z.YXZT,z.YWLX,z.XH,z.BZ,z.SZID,a.app_mc,o.org_mc,s.tbmc,z.tblx,
decode(z.tblx,'1','所有人','2','选择的机构的所有人','3','选择的机构下的所有人','4','具体的用户') tblxmc,decode(s.txxz,'0','无限制','1','机构填写单条','2','用户填写单条','3','用户填写多条') txxzmc,s.txxz,
(select wm_concat(o1.org_mc) from jc_sjtb_target t left join jc_org o1 on o1.org_id = t.targetid and t.type = '2' where t.szid = z.szid ) tx_orgmcs,
(select wm_concat(u.u_username) from jc_sjtb_target t left join jc_user u on u.u_id = t.targetid and t.type = '1' where t.szid = z.szid ) tx_usermcs
from jc_sjtb_sz z
left join jc_sjtb s on s.tbid = z.tbid and s.yxzt='1'
left join jc_app a on a.app_id = z.app_id
left join jc_org o on o.org_id = z.org_id
where z.yxzt = '1'
/

