create function FN_STR_TO_MOUTH(input in varchar2) return number is
   Result number;
begin
   Result:=to_number(substr(input ,0,instr(input ,'年',1,1)-1))*12+to_number(substr(input ,instr(input,'年',1,1)+1,length(input)-2-instr(input ,'年',1,1)));
  return(Result);
end FN_STR_TO_MOUTH;
/

