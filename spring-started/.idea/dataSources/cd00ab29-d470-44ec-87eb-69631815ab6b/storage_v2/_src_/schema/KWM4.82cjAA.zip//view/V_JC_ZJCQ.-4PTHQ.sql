create view V_JC_ZJCQ as
select
  C.ZJCQ_ID,
  C.XMLX,
  C.XM_ID,
  C.ZJ_ID,
  C.ZJLX,
  C.CQFS,
  C.CQDW,
  C.CQSJ,
  C.CQR,
  C.ZJDFBLR,
  C.ZJQRSJ,
  C.CXDFJG,
  C.CXYJ,
  C.CZLX,
  C.CZYY,
  C.CZCLR,
	C.STATUS
    from JC_ZJCQ C
    where C.STATUS='1'
/

