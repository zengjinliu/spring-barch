create procedure pro_test is
str varchar(100);
json varchar(100);
JSON_LAST varchar(100);
i number;
MI number;
MA number;
tj varchar(100);
val NUMBER;
jf_val number;
TJ_VAL NUMBER;
jsgs varchar(200);
sql_str varchar(200);
dlzh_val NUMBER;

expression varchar(200);
yxtj varchar(50);

yxtj_jd_str varchar(50);
yxtj_jd number;

yxtj_cp_str varchar(50);
yxtj_cp number;

yxtj_zj_str varchar(50);
yxtj_zj number;

begin
  expression := '0~20:1#20~40:0.9#40~60:0.8#60~80:0.7#80~100:0.6#$0#?#1#';
  json := substr(expression,0,instr(expression,'$',1,1)-1);
  
  yxtj := substr(expression,instr(expression,'$',1,1)+1,length(expression));
  DBMS_OUTPUT.PUT_LINE('优先条件' || yxtj);

  yxtj_jd_str := substr(yxtj,0,instr(yxtj,'#',1,1)-1);
  DBMS_OUTPUT.PUT_LINE('降低' || yxtj_jd_str);
  
  yxtj := substr(yxtj,instr(yxtj,'#',1,1)+1,length(yxtj));
  
  yxtj_cp_str := substr(yxtj,0,instr(yxtj,'#',1,1)-1);
  DBMS_OUTPUT.PUT_LINE('持平' || yxtj_cp_str);
  
  yxtj := substr(yxtj,instr(yxtj,'#',1,1)+1,length(yxtj));
  
  yxtj_zj_str := substr(yxtj,0,instr(yxtj,'#',1,1)-1);
  DBMS_OUTPUT.PUT_LINE('增加' || yxtj_zj_str);
  
  DBMS_OUTPUT.PUT_LINE('json' || json);
  --json := '0~20:1#20~40:0.9#40~60:0.8#60~80:0.7#80~100:0.6#';
  jsgs := '${spf?c}*0.6+${bdf?c}*0.4;';
  
  jsgs := replace(replace(replace(jsgs,'${spf?c}',0.86517),'${bdf?c}',0.91000),';','');
  DBMS_OUTPUT.PUT_LINE(jsgs);
  
  sql_str := 'select '|| jsgs || ' from dual';
  EXECUTE IMMEDIATE sql_str INTO dlzh_val;
  DBMS_OUTPUT.PUT_LINE('定量综合值：' || dlzh_val);
  
  i := 0;
  jf_val := 2;
  WHILE i<100 LOOP
    BEGIN

    
       str := substr(json,0,instr(json,'#',1,1)-1);
       DBMS_OUTPUT.PUT_LINE(str);
       
       tj := SUBSTR(str,0,INSTR(str,':',1,1)-1);
       DBMS_OUTPUT.PUT_LINE('条件:' || tj);
       
       MI := to_number(SUBSTR(tj,0,INSTR(tj,'~',1,1)-1))*0.01; 
       DBMS_OUTPUT.PUT_LINE('最小值:' || MI);
       
       MA := to_number(SUBSTR(tj,INSTR(tj,'~',1,1)+1,length(tj)))*0.01; 
       DBMS_OUTPUT.PUT_LINE('最大值:' || MA);
       
       val := to_number(SUBSTR(str,INSTR(str,':',1,1)+1,length(str)));
       DBMS_OUTPUT.PUT_LINE('值:' || val); 
       
       JSON_LAST := substr(json,instr(json,'#',1,1)+1,length(json));
       
       DBMS_OUTPUT.PUT_LINE(JSON_LAST);
       json := JSON_LAST;
       i := i+1;
       
       IF(jf_val > MI AND JF_VAL <= MA) THEN
         TJ_VAL := VAL;
         EXIT;
       END IF;
       IF JSON IS NULL THEN
         EXIT;
       END IF;
    END;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('最终值：' || TJ_VAL);
end pro_test;
/

