create view V_ZS_XJ_XXXX as
select a.XXCODE,a.XXID,a.XXNAME,to_char(sysdate,'yyyy') NOWYEAR,b.org_id
from emis.a_school a
inner join zs_xj_org b on b.xj_org_id=a.xxid
where nvl(a.used,'Y')<>'N'
/

