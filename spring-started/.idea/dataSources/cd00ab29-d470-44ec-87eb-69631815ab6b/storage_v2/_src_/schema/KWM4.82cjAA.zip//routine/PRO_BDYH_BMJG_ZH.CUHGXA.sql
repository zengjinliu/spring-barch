create PROCEDURE PRO_BDYH_BMJG_ZH IS

BEGIN
--珠海户籍
     -- delete smbd_shjg a where a.ssbmdm='ZHHJSH' and exists(select 1 from bdyh_zh_hj b where b.xsid=a.xsid and b.sfzjh=a.sfzjh and b.type='1' and nvl(b.iszh,'2')<>'2');
     insert into smbd_shjg(jgid,xsid,bmdm,shjg,shjgmx,shr,shsj,ssbmdm)
     select fn_uuid(),a.xsid,
     decode(a.iszh,'ZH','ZHHJ','FZH','FZHHJ'),
     case when a.iszh='ZH' then decode(b.iszh,'1','1','0','2')
          when a.iszh='FZH' then decode(b.iszh,'0','1','1','2') else '0' end,
     case when a.iszh='ZH' and b.iszh='1' then '珠户'||';居住地址:'||b.jzdz
          when a.iszh='ZH' and b.iszh='0' then '非珠户!'||a.JFX_JHR||'居住证信息:['||decode(a.JFX_JHR,'监护人一',e.jzzxxxx||',居住地址:'||e.jzdz,'监护人二',f.jzzxxxx||',居住地址:'||f.jzdz,'居住地址:'||nvl(e.jzdz,f.jzdz))||']'
          when a.iszh='FZH' and b.iszh='0' then '非珠户!'||a.JFX_JHR||'居住证信息:['||decode(a.JFX_JHR,'监护人一',e.jzzxxxx||',居住地址:'||e.jzdz,'监护人二',f.jzzxxxx||',居住地址:'||f.jzdz,'居住地址:'||nvl(e.jzdz,f.jzdz))||']'
          when a.iszh='FZH' and b.iszh='1' then '珠户'||';居住地址:'||b.jzdz else '' end,'SYS',sysdate,'ZHHJSH'
     from  v_smbd_bmshjg a
     left join bdyh_zh_hj b on b.xsid=a.xsid and b.sfzjh=a.sfzjh and b.type='1' and nvl(b.iszh,'2')<>'2'
     left join bdyh_zh_hj e on e.xsid=a.xsid and e.recentm_count is not null and e.iszh='0' and e.hasjzz is not null and e.sfzjh=a.jt_sfzjh1
     left join bdyh_zh_hj f on f.xsid=a.xsid and f.recentm_count is not null and f.iszh='0' and f.hasjzz is not null and f.sfzjh=a.jt_sfzjh2
     where a.shzt='2' and a.iszh in('FZH','ZH')
     and not exists(select 1 from jc_org_relat b where b.org_id in('a3ddcfe111084005b8841bbc9569da15') and b.org_id_child=a.sqxxid1);

--职业资格
   --delete smbd_shjg a where a.ssbmdm='ZYZGSH' and exists(select 1 from bdyh_zh_zs b where b.xsid=a.xsid);
   insert into smbd_shjg(jgid,xsid,bmdm,shjg,shjgmx,shr,shsj,ssbmdm)
   select fn_uuid(),a.xsid,'ZYZG',decode(b.code,'-1','2','1','1','0'),
          decode(b.code,'-1',b.reason,'1',b.zslevel,''),'SYS',sysdate,'ZYZGSH'
   from v_smbd_bmshjg a
   left join bdyh_zh_zs b on b.xsid=a.xsid
   where a.shzt='2' and a.xslb='JFRX' and a.JFX_JYORWH='职业资格'
   and not exists(select 1 from jc_org_relat b where b.org_id in('a3ddcfe111084005b8841bbc9569da15') and b.org_id_child=a.sqxxid1);
--计生情况
   --delete smbd_shjg a where ssbmdm='JSQKSH' and exists(select 1 from bdyh_zh_jsxx b where b.xsid=a.xsid);
   insert into smbd_shjg(jgid,xsid,bmdm,shjg,shjgmx,shr,shsj,ssbmdm)
   select fn_uuid(),a.xsid,'JSQK',
   case when a.js_qk='政策内生育' and b.status='2' then '1'
        when a.js_qk='政策外已接受处理' and b.status='5' then '1'
        when a.js_qk='政策外未接受处理' and (b.status='3' or b.status='4') then '1'
        when b.status='1' or b.status='2' or b.status='3' or b.status='4' or b.status='5' then '2'
        else '0' end,
   decode(b.status,'1','查无此人','2','符合计划生育政策','3','政策外出生子女,待核实社会抚养费缴纳情况',
          '4','违反计生政策，且未缴清费用','5','违反计生政策，但已缴清费用'),
   'SYS',sysdate,'JSQKSH'
   from v_smbd_bmshjg a
   left join bdyh_zh_jsxx b on b.xsid=a.xsid
   where a.shzt='2' and a.xslb='JFRX'
   and not exists(select 1 from jc_org_relat b where b.org_id in('a3ddcfe111084005b8841bbc9569da15') and b.org_id_child=a.sqxxid1);
--社保情况
    insert into smbd_shjg(jgid,xsid,bmdm,shjg,shjgmx,shr,shsj,ssbmdm)
    select fn_uuid(),a.xsid,'ZHSB','1',
    case when a.JFX_JHR='监护人一'
         then '基本养老累计缴费月数:'||b.jyylbx_year_count||';职工医疗一档累计缴费月数:'||b.jbyl_year_count
              ||';失业累计缴费月数:'||b.sybx_year_count||';工伤累计缴费月数;'||b.gsbx_year_count
              ||';生育累计缴费月数:'||b.bear_year_count||';职工医疗二挡累计缴费月数:'||b.dbyl_year_count
         when a.JFX_JHR='监护人二'
         then '基本养老累计缴费月数:'||c.jyylbx_year_count||';职工医疗一档累计缴费月数:'||c.jbyl_year_count
              ||';失业累计缴费月数:'||c.sybx_year_count||';工伤累计缴费月数;'||c.gsbx_year_count
              ||';生育累计缴费月数:'||c.bear_year_count||';职工医疗二挡累计缴费月数:'||c.dbyl_year_count
         else '' end
    ,'SYS',sysdate,'ZHSBSH'
    from v_smbd_bmshjg a
    left join bdyh_zh_sb b on b.xsid=a.xsid and b.sfzjh=a.jt_sfzjh1 and b.type='1'
    left join bdyh_zh_sb c on c.xsid=a.xsid and c.sfzjh=a.jt_sfzjh2 and c.type='2'
    where a.shzt='2' and a.xslb='JFRX'
   and not exists(select 1 from jc_org_relat b where b.org_id in('a3ddcfe111084005b8841bbc9569da15') and b.org_id_child=a.sqxxid1);
--房产
     --delete smbd_shjg a  where a.ssbmdm='ZHFCSH' and (exists(select 1 from bdyh_zh_fcxx b where b.xsid=a.xsid) or exists(select 1 from bdyh_zh_fcexists c where c.xsid=a.xsid));
     insert into smbd_shjg(jgid,xsid,bmdm,shjg,shjgmx,shr,shsj,ssbmdm)
     select fn_uuid(),a.xsid,'ZHFC',
     case when b.code='1' and a.ZF_YWFC='01' then '1'
          when b.code='5' and a.ZF_YWFC='01' then '2'
          when c.counttype='0'and a.ZF_YWFC='02' then '1'
          when nvl(c.counttype,'A')<>'0'and a.ZF_YWFC='02' then '2'
          else '0' end
     ,case when b.code='1' and a.ZF_YWFC='01' then '查询成功有房'||';房产权属人:'||ownername||';权利人证件号码:'||ownercertnum||';权证号码:'||rightcertnum||';权证类别:'||rightcerttype||';权证状态:'||rightcertstate||';房屋建筑面积:'||architarea||';房屋地址:'||sitnumgather||';登记时间:'||recfinishtime||';产权比例:'||rightscale||';房屋用途:'||houseusage||';共有人信息:'||nvl(commowner,'')||';房屋所在区域:'||region
          when b.code='5' and a.ZF_YWFC='01' then '查询异常无房'
          when c.counttype='0'and a.ZF_YWFC='02' then '查询成功无房'
          when nvl(c.counttype,'A')='1'and a.ZF_YWFC='02' then '有一套房'
          when nvl(c.counttype,'A')='2'and a.ZF_YWFC='02' then '有多套房'
          else '结果异常' end,'SYS',sysdate,'ZHFCSH'
     from  v_smbd_bmshjg a
     left join bdyh_zh_fcxx b on a.xsid=b.xsid and nvl(b.code,'0') not in ('0','2')
     left join bdyh_zh_fcexists c on c.xsid=a.xsid and c.code='1'
     where a.shzt='2' and
     (exists(select 1 from bdyh_zh_fcxx b where b.xsid=a.xsid) or
      exists(select 1 from bdyh_zh_fcexists c where c.xsid=a.xsid))
     and not exists(select 1 from jc_org_relat b where b.org_id='a3ddcfe111084005b8841bbc9569da15' and b.org_id_child=a.sqxxid1);
  EXCEPTION
        when others then
          rollback;
END PRO_BDYH_BMJG_ZH;
/

