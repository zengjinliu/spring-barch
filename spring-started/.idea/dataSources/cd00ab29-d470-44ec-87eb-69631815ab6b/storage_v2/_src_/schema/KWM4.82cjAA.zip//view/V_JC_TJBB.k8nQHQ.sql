create view V_JC_TJBB as
select
    T.BBID,
    T.BH,
    T.MC,
    T.BZ,
    T.MYSQL_MBID,
    T.ORACLE_MBID,
    T.Mblx,
    T.Oracle_Csmb,
    T.Mysql_Csmb,
    t.sfhc,
    t.hclx,
    t.HCJG
    from JC_TJBB T
    where T.STATUS = '1'
/

