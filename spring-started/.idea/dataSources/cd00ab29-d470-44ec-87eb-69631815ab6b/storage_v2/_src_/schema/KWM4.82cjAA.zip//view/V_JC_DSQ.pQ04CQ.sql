create view V_JC_DSQ as
select
d.dsqid,d.dsqmc,d.dsqbh,d.type,d.dsqclass,d.xhcs,d.zxjg,d.kssj,d.cronbds,d.ytkssj,d.ytjssj,d.yzzxt,d.app_id,d.yxzt,d.xzr,d.xzsj,d.gxr,d.gxsj,d.xh,d.xhlx,
decode(d.type,'1','简单定时器','2','日常定时器','3','日历定时器','4','CRON定时器') typemc,decode(d.yxzt,'1','正常','2','停止') yxztmc,a.app_mc,a.app_dm
from jc_dsq d
left join jc_app a on a.app_id = d.app_id
where d.yxzt > 0
/

