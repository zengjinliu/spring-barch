create FUNCTION FN_getRandPwd(p_dj varchar2)
  return varchar2
  is
  ts varchar2(7);
  zm varchar2(24);
  ts_xh int;
  zm_xh1 int;
  zm_xh2 int;
  zm_xh3 int;
  zm_xh4 int;
  zm1 varchar2(1);
  zm2 varchar2(1);
  zm3 varchar2(1);
  zm4 varchar2(1);
  sjs int;
  begin

  ts:='!#?';
  select ceil(dbms_random.value(1,3)) into ts_xh from dual;
  select substr(ts,ts_xh,1) into ts from dual;

  zm:='abcdefghjkmnpqrstuvwxyz';
  select ceil(dbms_random.value(1,22)) into zm_xh1 from dual;
  select substr(zm,zm_xh1,1) into zm1 from dual;

  select ceil(dbms_random.value(1,22)) into zm_xh2 from dual;
  select substr(zm,zm_xh2,1) into zm2 from dual;

  select ceil(dbms_random.value(1,22)) into zm_xh3 from dual;
  select substr(zm,zm_xh3,1) into zm3 from dual;

  select ceil(dbms_random.value(1,22)) into zm_xh4 from dual;
  select substr(zm,zm_xh4,1) into zm4 from dual;

  select ceil(dbms_random.value(1000,9998)) into sjs from dual;
  
  if(p_dj='3') then 
     return zm1||zm2||zm3||sjs||ts;
  else
     return zm1||zm2||zm3||zm4||sjs;
  end if;
  end;
/

