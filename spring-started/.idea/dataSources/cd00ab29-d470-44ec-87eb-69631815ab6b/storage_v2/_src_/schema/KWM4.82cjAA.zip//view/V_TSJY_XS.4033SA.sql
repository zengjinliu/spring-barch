create view V_TSJY_XS as
SELECT  TS.XSID,TS.XXID ORG_ID,TS.XM,TS.XXID,TS.SFZJH,TS.AZFS,
TS.XBM,TS.XBM XBMC,TS.XBM XB,TS.XJFH,jo.org_mc,jo.org_mc as xxmc,
TS.TSXSLXM,TS.ZJHM,TS.CJLX,TS.CJDJ,TS.HKLB,TS.LXR,TS.GH,TS.SJ,TS.SFYCJZ,TS.SFSBJD,TS.SBJDBH,TS.STATUS,TS.BJMC,TS.NJMC,X.XZQH,
E8.DMMX_MC AS TSXSLXMC,j1.dmmx_code as njdm
FROM TSJY_XS TS
 join jc_xx X on TS.XXID=X.ORG_ID
 left join jc_org jo on jo.org_id = ts.xxid
 LEFT JOIN JC_DMMX E8 ON TS.TSXSLXM = E8.DMMX_CODE AND E8.DM_CODE = 'DM_XS_TSXSLXM'
 left join jc_dmmx j1 on ts.njmc = j1.dmmx_mc and j1.dm_code='DM_NJDM' and j1.dmmx_state='1'
 where TS.STATUS !='0'
/

