create view V_JC_SJTB as
select s.tbid,s.tbbh,s.tbmc,s.mbid,s.org_id,s.ywlx,s.mbpath,s.app_id,s.mbmc,s.xzsj,mb.mbmc mbmc1,
s.ywlx ywlxmc,s.yxzt,s.sfstb,s.stbmc,s.kssj,s.jssj,s.txxz,s.bz,s.xh,decode(s.txxz,'0','无限制','1','机构填写单条','2','用户填写单条','3','用户填写多条') txxzmc,
o.org_mc,a.app_mc,case when exists(select 1 from v_jc_sjtb_sz sz where sz.tbid = s.tbid) then '1' else '2' end isuse,
decode(s.stbmc,null,0,(select count(*) from user_tables where table_name = 'DATA_'||s.stbmc)) stbcount
from jc_sjtb s
left join jc_org o on o.org_id = s.org_id
left join jc_app a on a.app_id = s.app_id
left join v_jc_sjtb_mb mb on mb.mbid = s.mbid
where s.yxzt > 0
/

