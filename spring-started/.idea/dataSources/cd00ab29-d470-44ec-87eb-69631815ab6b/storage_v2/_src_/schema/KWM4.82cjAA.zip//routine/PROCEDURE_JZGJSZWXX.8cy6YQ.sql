create procedure procedure_jzgjszwxx -- 创建存储过程 教职工技术职务信息
  as
  tbsj date;
  begin
  select max(time_bz) into tbsj from gz_sjjh.JS_TB_BIZ_JZGZYJSZWPRXX;
  delete from JC_JS_JS b where exists   (select 1 from  gz_sjjh.JS_TB_BIZ_JZGZYJSZWPRXX a where a.id=b.jsjs_id and a.TIME_BZ> ( select c.updatetime from JC_DATA_TIME c  where c.model_type = 'JC_JS_JS'));
  insert into JC_JS_JS b (jsjs_id,JS_ID,PRJSZW,PRKSNY,PRJSNY,PRDWMC,STATUS,XZR,XZSJ)
  select j.id,
      JB.JSJB_ID,
      (select d1.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d1 where d1.zdbs='ZYJSZW' and d1.zdxbs = j.PRZYJSZW)PRZYJSZW,
      j.Prksny,
      j.Prjsny,
      j.Prdwmc,
      '1',
      'SJTB',
      sysdate
  from gz_sjjh.JS_TB_BIZ_JZGZYJSZWPRXX j
  join JC_JS_JB JB
  on j.JSID = JB.JSJB_ID
  where  j.SFSC = '0' and j.shzt='2' and j.TIME_BZ>(  select c.updatetime from JC_DATA_TIME c  where c.model_type = 'JC_JS_JS');
  update JC_DATA_TIME set updatetime = tbsj where model_type = 'JC_JS_JS';

   exception when others then
  dbms_output.put_line(sqlcode||'>>>>>>' || sqlerrm);
  commit;
end procedure_jzgjszwxx;
/

