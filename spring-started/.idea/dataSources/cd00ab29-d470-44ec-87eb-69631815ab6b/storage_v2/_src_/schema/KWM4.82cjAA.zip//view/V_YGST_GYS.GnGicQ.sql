create view V_YGST_GYS as
SELECT
A.ORG_ID,A.ORG_DM,A.ORG_MC,A.ORG_ORDERID,a.ORG_BZ,b.gysid,
b.gysmc,
b.app_id,
b.nsrsbh,
b.dz,
b.dh,
b.khh,
b.hm,
b.zh,
b.bz,
b.xzr,
b.xzsj,
b.gxr,
b.gxsj，
STATUS,
DECODE (B.STATUS,'0','已过期','1','中标'） STATUSMC
FROM JC_ORG A
INNER JOIN ygst_gys B ON B.GYSID=A.ORG_ID
WHERE
A.ORG_STATE = 1
    /

