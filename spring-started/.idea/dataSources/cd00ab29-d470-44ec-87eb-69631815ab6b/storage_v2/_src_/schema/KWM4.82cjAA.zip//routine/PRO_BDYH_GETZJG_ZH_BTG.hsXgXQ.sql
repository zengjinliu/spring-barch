create PROCEDURE PRO_BDYH_GETZJG_ZH_BTG IS
  cursor c_list is select * from v_smbd_bmshjg v where v.ZJG ='0' and shzt='2';
    xs c_list%rowtype;
  v_xsid varchar(32);
BEGIN
  open c_list;
  loop fetch c_list into xs;
    exit when c_list%notfound;
      v_xsid := xs.xsid;
      pro_bdyh_getzjg_zh_byxsid(v_xsid,'sys');
  end loop;
  close c_list;
end PRO_BDYH_GETZJG_ZH_BTG;
/

