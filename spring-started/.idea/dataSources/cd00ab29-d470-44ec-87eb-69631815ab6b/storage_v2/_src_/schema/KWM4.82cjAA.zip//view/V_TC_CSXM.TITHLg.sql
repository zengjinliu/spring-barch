create view V_TC_CSXM as
select A.CSID,A.CSXMMC,A.DW_CODE,A.XSWS,A.JSGS,A.ORGID ORG_ID,A.APPID,
--case when exists(select 1 from TC_CSXM_JFXM B where A.CSID=B.CSID) then '1' else '0' end ISGL,
case when (exists(select 1 from TC_CSXM_JFXM B where A.CSID=B.CSID) or exists(select 1 from TC_BATCH_CSXM C where A.CSID=C.CSID)) then '1' else '0' end ISUSE
from TC_CSXM A
/

