create view V_GDSJCJ_XJBL_ZZ as
select
a.zzid,a.xsid,a.f_id,a.filename,b.f_name,b.f_path,b.f_ext,a.xzsj,
c.xxbsm,c.xm,c.xb,c.csrq,c.sfzjlx,c.sfzjh,c.hkszdm,c.rxny,c.jtzz,c.org_id,d.org_mc xxmc
from gdsjcj_xjbl_zz a
inner join jc_file b on a.f_id=b.f_id
inner join gdsjcj_xjbl c on a.xsid=c.xsid
left join jc_org d on c.xxbsm=d.org_dm and d.org_state='1'
/

