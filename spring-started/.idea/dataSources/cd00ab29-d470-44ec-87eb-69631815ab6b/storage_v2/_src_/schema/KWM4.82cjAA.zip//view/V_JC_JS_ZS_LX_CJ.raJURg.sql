create view V_JC_JS_ZS_LX_CJ as
SELECT zs.jszs_id as zsid,t1.jszs_id,t1.op_id,t1.js_id,t1.xzr,t1.xzsj,t1.gxr,t1.gxsj,t1.status,t1.ZSLX,t1.YYZSMC,t1.ZSMC,t1.FZSJ,t1.FZDW,t1.ZSBH
,t2.dmmx_mc dmmx_ZSLX_mc
FROM JC_JS_ZS_LX_CJ t1
LEFT JOIN jc_js_zs_lx zs ON T1.JSZS_ID = zs.jszs_id
LEFT JOIN JC_DMMX T2 ON t1.ZSLX = T2.DMMX_CODE AND T2.DM_CODE = 'DM_ZSLX'
/

