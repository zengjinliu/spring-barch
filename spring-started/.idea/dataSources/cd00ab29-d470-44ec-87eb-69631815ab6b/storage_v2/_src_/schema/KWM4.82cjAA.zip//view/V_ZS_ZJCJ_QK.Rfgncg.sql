create view V_ZS_ZJCJ_QK as
select yw_pkid,
zjs,
cjzt,
xzr,
xzsj,
gxr,
gxsj
from zjcj_qk a
/

