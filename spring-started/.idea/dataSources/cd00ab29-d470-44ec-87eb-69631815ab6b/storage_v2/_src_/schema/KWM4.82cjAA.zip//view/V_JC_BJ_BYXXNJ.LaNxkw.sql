create view V_JC_BJ_BYXXNJ as
select a.BJID,a.BJMC,a.BJZT,a.org_id,a.org_mc,
--a.ishave,
a.org_dm,a.org_orderid,a.BH,a.jhs,bjmc_n,
c.org_id njorg_id,c.org_mc njorg_mc,c.org_dm njorg_dm,c.org_orderid njorg_orderid,
c.xjnjdm,c.xjnjdm_n,c.xz,c.jyjd,c.jyjd_n,c.njmc_n,
e.ORG_ID xxorg_id,e.ORG_DM xxorg_dm,e.ORG_MC xxorg_mc,e.ORG_ORDERID xxorg_orderid
from v_jc_bj a
left join jc_org_relat b on a.org_id=b.org_id_child
left join v_jc_nj c on b.org_id=c.org_id
left join jc_org_relat d on c.org_id=d.org_id_child
left join v_org_xx e on d.org_id=e.ORG_ID
--where c.ishave<>'0'
/

