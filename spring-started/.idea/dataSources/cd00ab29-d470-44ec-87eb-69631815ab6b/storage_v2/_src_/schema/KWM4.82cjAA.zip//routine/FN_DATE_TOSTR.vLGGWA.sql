create function FN_DATE_TOSTR(input_date date) return varchar2 is kwstr varchar2(32);
begin
  kwstr := to_char(input_date,'yyyy-mm-dd hh24:mi:ss');
return kwstr;
end FN_DATE_TOSTR;
/

