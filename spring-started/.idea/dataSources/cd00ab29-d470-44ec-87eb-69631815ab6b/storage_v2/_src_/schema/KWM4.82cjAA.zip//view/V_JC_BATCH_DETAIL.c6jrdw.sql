create view V_JC_BATCH_DETAIL as
select  j.bid,j.bmc,j.remark,j.xzr,j.xzsj,j.gxr,j.gxsj,j.ywlx,j.mbid,j.starttime,j.endtime,j.bdm,j.targettype,
jbt.qid,jbt.ptype,jbt.rate,jpm.pgid,jpm.pgmc,jpm.mb_org_id,jpm.u_id,jpmx.sj,jpmx.fz,jpmx.mxid,
(select  count(*) from jc_pgbz_mx jpl where jpl.sj is not null and jbt.ptype = jpm.ptype)as ZS,
(select avg(jcp.fz) from jc_pgbz_mx jcp)as FS,
(select GMXMC from jc_pgbz_grade_mx jpgm where (select avg(jcp.fz) from jc_pgbz_mx jcp) between jpgm.min and jpgm.max and jpgm.gid = jpg.gid)as DJMC,
jp.gid,jpg.gmc,p.dmmx_mc as typemc
from jc_batch j
left join jc_batch_type jbt on jbt.bid = j.bid
left join jc_pgbz_mb jpm on jpm.bid = j.bid
left join jc_pgbz_mx jpmx on jpmx.pgid = jpm.pgid
left join jc_pgbz jp on jp.bzid = j.mbid
left join jc_pgbz_grade jpg on jpg.gid = jp.gid
left join jc_dmmx p on p.dm_code='DM_DD_PGLX' and jbt.ptype=p.dmmx_code
where jpmx.sj is not null and jbt.ptype = jpm.ptype
/

