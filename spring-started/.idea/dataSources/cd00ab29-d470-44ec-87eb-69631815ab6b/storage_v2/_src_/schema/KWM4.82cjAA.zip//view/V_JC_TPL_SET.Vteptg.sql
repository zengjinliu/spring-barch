create view V_JC_TPL_SET as
select
t1.SET_ID,
t1.ORG_ID,
t1.TPL_ID,
t1.FUN_ID,
t2.FUN_MC,
t3.ORG_MC,
t3.ORG_DJ,
t4.TPL_MC,
t6.TG_MC,
t6.TG_ID,
t6.TG_ORDER,
t3.ORG_ORDERID,
t2.FUN_ORDER,
t7.DJ_LEVEL from jc_tpl_set t1
left join jc_fun t2 on t1.fun_id = t2.fun_id
left join jc_org t3 on t1.org_id = t3.org_id
left join jc_org_dj t7 on t3.org_dj=t7.dj_dm
left join jc_tpl t4 on t1.tpl_id = t4.tpl_id
left join jc_tpl_group_child t5 on t5.tpl_id = t4.tpl_id
left join jc_tpl_group t6 on t6.tg_id = t5.tg_id
/

