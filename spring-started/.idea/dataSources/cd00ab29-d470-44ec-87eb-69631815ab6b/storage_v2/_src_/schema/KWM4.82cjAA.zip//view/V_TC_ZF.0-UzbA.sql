create view V_TC_ZF as
select JO.ZFID,JO.PCID,JO.XSID,JO.BZF,JO.FJF,JO.ZF,JO.DJMC,JO.Appid,JO.Orgid ORG_ID,JB.Bmc PCMC
,VJX.ORG_ID XXID,VJX.ORG_MC,VJX.XM,VJX.XBM,VJX.XJH,VJX.BJBH,VJX.BJMC,VJX.NJDM
from tc_zf JO
left join jc_batch JB on JB.Bid=JO.Pcid
left join V_TC_XS VJX on VJX.XSID=JO.Xsid
/

