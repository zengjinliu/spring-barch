create view V_JCJK_ZS_XSXX as
select
a.xsid XSID,
'' as DLMM,
a.XM as XSXM,
x.dmmx_mc as XSZJLX,
FN_MD5(a.SFZJH) as XSHM,
a.SFZJH,
a.LSH as BMLSH,
a.PWD,
m.dmmx_mc as XBM,
to_char(a.CSRQ,'yyyymmdd') as CSRQ,
q.dmmx_mc as JHR1GX,
y.dmmx_mc as JHR1ZJLX,
FN_MD5(a.JT_SFZJH1) as JHR1HM,
FN_MD5(a.JT_LXDH1) as JHR1SJH,
r.dmmx_mc as JHR2GX,
z.dmmx_mc  as JHR2ZJLX,
FN_MD5(a.JT_SFZJH2) as JHR2HM,
FN_MD5(a.JT_LXDH2) as JHR2SJH,
'' as JHR1CSRQ,
'' as JHR2CSRQ,
a.FCLB as FCLBBM,
a.ZF_FCQBM as FCQBM,
a.ZF_FCQMC  as FCQMC,
a.ZF_JDMC as FCSQMC,
a.ZF_LDMC as LDMC,
o.dmmx_mc as FCLBMS,
to_char(a.xzsj,'yyyy') as RXNF,
case a.njdm when '11' then '小学' when '21' then '初中' else '未指定' end as XD,
jo.org_dm XXBM,
jo.org_mc XXMC,
a.ZF_FCQBM as XZQBM,
a.ZF_FCQMC as XZQMC,
case c.GMB when '1' then '公办' else '民办' end as XXBBDM,
b.XH as ZYSX,
jo.org_id as ORG_ID
from zs_xsxx a
left join zs_xsxx_shzt d on d.xsid=a.xsid    --学生信息审核状态
left join zs_xsxx_sqxx b on a.xsid=b.xsid
left join zs_xxxx c on b.sqxxid=c.org_id
left join jc_org jo on c.org_id=jo.org_id
left join jc_dmmx m on m.dm_code='DM_XB'and m.dmmx_code=a.XBM and m.dmmx_state='1'
left join jc_dmmx o on o.dm_code='DM_ZS_FCLB' and o.dmmx_code=a.FCLB and o.dmmx_state='1'
left join jc_dmmx x on x.dm_code='DM_SFZJLX' and x.dmmx_code=a.SFZJLXM and x.dmmx_state='1'
left join jc_dmmx y on y.dm_code='DM_SFZJLX' and y.dmmx_code=a.JT_SFZJLX1 and y.dmmx_state='1'
left join jc_dmmx z on z.dm_code='DM_SFZJLX' and z.dmmx_code=a.JT_SFZJLX2 and z.dmmx_state='1'
left join jc_dmmx q on q.dm_code='DM_JHR_RELAT' and q.dmmx_code=a.JT_RELAT1 and q.dmmx_state='1'
left join jc_dmmx r on r.dm_code='DM_JHR_RELAT' and r.dmmx_code=a.JT_RELAT2 and r.dmmx_state='1'
where jo.org_state='1' and d.shzt!='0'
/

