create view V_ZS_XSXX_GWXS as
select
--学籍接续标识
'' XQJXBS,
--学校标识码
'' XXBSM,
--班号
'' BHM,
--曾用名
'' CYM,
--身份证有效期
'' SFZJYXQ,
--血型
'' XLX,
--学籍辅号
'' XJFH,
--班内学号
'' BNXH,
--学生来源
'' XSLY,
--电子邮箱
'' DZYX,
--主页地址
'' ZYDZ,
--成员1关系说明
'' JT_RELAT_SM1,
--成员2关系说明
'' JT_RELAT_SM2,
--成员1是否监护人
'是' JT_SFJHR1,
--成员2是否监护人
'是' JT_SFJHR2,
--入学年月
'' RXNY,
a.xsid XSID,a.XM,a.SFZJLXM,a.SFZJH,a.PWD,a.LSH,a.JT_SFZJH1,a.JT_LXDH1,a.HKXZM,a.HJLXM,decode(a.sfdq,'1',a.JT_LXDH1,'0',a.JT_LXDH2) JT_LXDH2,
decode(a.sfdq,'1',a.JT_SFZJH1,'0',a.JT_SFZJH2) JT_SFZJH2,to_char(a.CSRQ,'yyyy-mm-dd') CSRQ,a.JT_YLBXYS1,a.JT_YLBXYS2,a.JT_YILBXYS1,a.JT_YILBXYS2,a.JT_SBLJYS1,a.JT_SBLJYS2,
a.ZF_ISSFZH2,a.CQRGX,to_char(a.JT_QRSZSJ1,'yyyy-mm-dd') JT_QRSZSJ1,to_char(a.JT_QRSZSJ2,'yyyy-mm-dd') JT_QRSZSJ2,
a.ZF_CHZRGX,a.ZF_ZLYT,a.ZF_ISXQ,a.ZF_ISWFZM,a.ZF_ZLLJYS,a.ZF_JHTBAH,to_char(a.ZF_JHTBARQ,'yyyy-mm-dd') ZF_JHTBARQ,
a.ZF_JHTCHZR,ZF_HJISQR,a.FWID,a.JT_SBFZDW1,a.JT_SBFZDW2,a.ZF_ISKFZM,a.ZF_KFZMYS,to_char(a.XZSJ,'yyyy-mm-dd hh24:mi:ss') XZSJ,a.XZR,a.JFMX,
a.XBM,a.JT_XM1,a.YHXQJF,a.by4,decode(a.sfdq,'1',a.JT_XM1,'0',a.JT_XM2) JT_XM2,a.ZZZH,a.MZM,a.CSDM,a.CSD,
a.JG,(SELECT SSXDM FROM V_ZS_SSX_LINK SL WHERE SL.SSXMC=a.JG) JGDM,a.HKSZDM,a.HKSZD,a.LXDH,a.JDFSM,a.SFYHDX,a.YHDXM,a.HKBHZ,
case  when a.fcdz is null then a.xzz else a.fcdz end XZZ,
case  when a.fcdz is null then a.TXDZ else a.fcdz end TXDZ,
case  when a.fcdz is null then a.JTZZ else a.fcdz end JTZZ,
a.HKSSPCS,a.HKXXDZ,a.HZGX,a.YZBM,a.ZZMMM,a.GJDQM,a.JKZK,a.XWLB,a.SFDQ,a.SFLSETM,a.GATQWM,a.SFSQZNM,a.SFSGXQJYM,
a.SFGE,a.SFLSHYFZN,a.BYXXBZ,a.BYXXMC,a.SFFCTP,a.SFBL,a.BLYY,a.FCLB,a.CQR,a.CHZR,a.CQR_SFZJH,a.FCZH,a.FCFZDW,a.FCDZ,
to_char(a.DJBARQ,'yyyy-mm-dd') DJBARQ,to_char(a.FZRQ,'yyyy-mm-dd') FZRQ,a.CZR,to_char(a.FZRQ,'yyyymmdd') FZRQ2,
to_char(a.ZLKSRQ,'yyyy-mm-dd') ZLKSRQ,to_char(a.ZLJSRQ,'yyyy-mm-dd')ZLJSRQ,a.FCFE,a.ZLBADW,a.JT_RELAT1,
a.JT_SFZJLX1,a.JT_MZ1,a. JT_HKSZDM1,a.JT_HKSZD1,a.JT_GZDW1,a.JT_SBDNH1,to_char(a.JT_CBRQ1,'yyyy-mm-dd')JT_CBRQ1,
a.JT_RELAT2,a.JT_SFZJLX2,a.JT_MZ2,
decode(a.sfdq,'1',a.JT_HKSZDM1,'0',a.JT_HKSZDM2) JT_HKSZDM2,a.JT_SBDNH2,
decode(a.sfdq,'1',a.JT_GZDW1,'0',a.JT_GZDW2) JT_GZDW2,
decode(a.sfdq,'1',a.JT_HKSZD1,'0',a.JT_HKSZD2) JT_HKSZD2,
to_char(a.JT_CBRQ2,'yyyy-mm-dd')JT_CBRQ2,a.JT_HJLXM1,a.JT_HJLXM2,a.DXQID,a.JT_ZSJZNX1,a.JT_ZSJZNX2,
to_char(a.JT_JZZQFRQ1,'yyyy-mm-dd') JT_JZZQFRQ1,to_char(a.JT_JZZQFRQ2,'yyyy-mm-dd') JT_JZZQFRQ2,
a.JS_QK,a.JS_FZBSC,a.JS_FZDW,a.ZF_JTSSDWMC,a.NJDM,a.ZF_ZLMJ,a.JT_JYLX1,a.JT_JYLX2,
to_char(a.ZF_QRSZSJ,'yyyy-mm-dd') ZF_QRSZSJ,a.JT_CBRGX,a.JT_CBR,a.JT_CBRSFZJH,a.SQLB,a.JT_JZZH1,a.JT_JZZH2,
a.XQJF_JS,to_char(a.ZF_JHTJSRQ,'yyyy-mm-dd') ZF_JHTJSRQ,a.ZF_OLDFCLB,a.FCDZ FWDZ,a.BYXXLB,a.JS_GZSH,
a.ZF_FCQBM,a.ZF_FCQMC,a.ZF_JDMC,a.ZF_LDMC,a.JT_ISJZZH1,a.JT_ISJZZH2,
--未加入数据字典
a.LOCKID,a.ZF_HKSFYQ,a.XZSJ XZSJ2,a.TSBJ,a.ZF_BADWBSC,
to_char(a.YHJFGXSJ,'yyyy-mm-dd hh24:mi:ss') YHJFGXSJ,a.YHJFGXR,a.ZXTBLDID,
a.HJLXMC,a.JT_HJLX1,a.JT_HJLX2,--基本信息页面显示 冗余存储
JT_ZYZGDM1,JT_ZYZGBH1,JT_WHCDDM1,JT_WHCDBH1,JT_WHCDBGBH1,JT_BYSJ1,JT_BYXXMC1,
JT_ZYZGDM2,JT_ZYZGBH2,JT_WHCDDM2,JT_WHCDBH2,JT_WHCDBGBH2,JT_BYSJ2,JT_BYXXMC2,
a.JFXM,a.ZF_YWFC,a.JFX_JHR,a.JFX_JYORWH,--珠海
a.XB,
a.SQXXID1,a.SQXXMC1,a.sqxxid1 ORG_ID,a.sqxxid1 as orgid,a.SQXXID2,a.SQXXMC2,a.sqxxid2 as orgid2,a.SQXXID3,a.SQXXMC3,a.sqxxid3 as orgid3,
a.SQXXID4,a.SQXXMC4,a.sqxxid4 as orgid4,a.SHZT,a.SHXX,a.SHR,a.SHSJ,a.SHZTMC,a.SFCSSJ,a.DRXJZT,a.DRXJR,a.DRXJSJ,a.DRXJZTMC,a.QUSHZT,a.QUSHXX,a.QUSHR,a.QUSHSJ,a.QUSHZTMC,
nvl(a.ZJG,'0') ZJG,a.ZJGMC,a.hkxzmc,
decode(a.sfzjlxm,'1','居民身份证','2','其他','3','其他','4','其他','5','其他','6','香港特区护照/身份证明','7','澳门特区护照/身份证明','8','台湾居民来往大陆通行证','9','境外永久居住证','B','户口薄','A','护照','Z','其他') SFZJLX,
nvl(a.LQZT,'1') LQZT,a.LQ_ORGID LQXXID,a.LQZTMC,nvl(a.lqxx,'未录取') LQXX,
a.ZCZTMC,nvl(a.ZCZT,'1') ZCZT,a.ZCR,to_char(a.ZCSJ,'yyyy-mm-dd') ZCSJ,
a.JT_HJLXMC1,a.JT_HJLXMC2,
decode(a.njdm,'11','小学一年级','12','小学二年级','13','小学三年级','14','小学四年级','15','小学五年级','16','小学六年级','21','初中一年级','22','初中二年级','23','初中三年级','31','高中一年级','32','高中二年级','33','高中三年级','41','大学一年级','42','大学二年级','43','大学三年级','44','大学四年级','01','小班','02','中班','03','大班','04','大大班') NJMC,
decode(a.hzgx,'01','父亲','02','母亲','03','祖父','04','祖母','05','外祖父','06','外祖母','07','其他') HZGXMC,
decode(a.jt_relat1,'01','父亲','02','母亲','07','其他监护人') JT_RELATMC1,
decode(a.sfdq,'1',decode(a.jt_relat1,'01','父亲','02','母亲','07','其他监护人'),'0',decode(a.jt_relat2,'01','父亲','02','母亲','07','其他监护人')) JT_RELATMC2,
decode(a.fcfe,'1','大于等于51%','2','小于51%','4','小于50%','3','大于等于50%','5','大于等于30%小于等于50%','6','小于30%') FCFEMC,
a.fclbmc FCLBMC,
to_char(sysdate,'yyyy') NOWYEAR,to_char(sysdate,'yyyy-mm-dd') NOWDATE,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss') NOWDATETIME,case when a.DXQID is null then '否' else '是' end ISDXQ,
decode(a.NJDM,'11','幼儿园','21','小学') BYXXDETAIL,decode(a.NJDM,'11','小孩','21','学生') XSLBDETAIL,decode(a.NJDM,'11','小学','21','初中') NJLBDETAIL,
a.gjdqmc GJDQMC,a.mzmc MZMC,decode(a.SFYHDX,'0','否','1','是') SFYHDXMC,decode(a.SFFCTP,'0','否','1','是') SFFCTPMC,a.jt_mzmc1 JT_MZMC1,
decode(a.sfdq,'1',jt_mzmc1,'0',jt_mzmc2) JT_MZMC2,
decode(a.jt_sfzjlx1,'1','居民身份证','2','军官证','3','士兵证','4','文职干部证','5','部队离退休证','6','香港特区护照/身份证明','7','澳门特区护照/身份证明','8','台湾居民来往大陆通行证','9','境外永久居住证','B','户口薄','A','护照','Z','其他') JT_SFZJLXMC1,
decode(a.sfdq,'1',decode(a.jt_sfzjlx1,'1','居民身份证','2','军官证','3','士兵证','4','文职干部证','5','部队离退休证','6','香港特区护照/身份证明','7','澳门特区护照/身份证明','8','台湾居民来往大陆通行证','9','境外永久居住证','B','户口薄','A','护照','Z','其他'),'0',decode(a.jt_sfzjlx2,'1','居民身份证','2','军官证','3','士兵证','4','文职干部证','5','部队离退休证','6','香港特区护照/身份证明','7','澳门特区护照/身份证明','8','台湾居民来往大陆通行证','9','境外永久居住证','B','户口薄','A','护照','Z','其他')) JT_SFZJLXMC2,
decode(a.ZF_ISWFZM,'0','否','1','是') ZF_ISWFZMMC,
decode(a.ZF_ISXQ,'0','否','1','是') ZF_ISXQMC,
decode(a.ZF_HJISQR,'0','否','1','是') ZF_HJISQRMC,
decode(a.SFDQ,'0','否','1','是') SFDQMC,
decode(a.ZF_OLDFCLB,'08','房屋租赁凭证（合法产权房屋）','09','房屋租赁信息') ZF_OLDFCLBMC,'走读' JDFSMC,
decode(a.ZF_HKSFYQ,'0','否','1','是') ZF_HKSFYQMC,
decode(a.ZF_ISKFZM,'0','否','1','是') ZF_ISKFZMMC,a.by1 ZHXWLB,
decode(fwid,'00','1','0') SFZXTB,decode(fwid,'00','是','否') SFZXTBMC,ZF_ISSFZH2 SFCXJFJS,
case when SFBL='1' then '补申请录入' else '正常录入' end SFBLMC,
decode(ZF_ISSFZH2,'Y','是','否') SFCXJFJSMC,
decode(a.ZF_YWFC,'01','有','02','无') ZF_YWFCMC,
decode(a.JT_ZYZGDM1,'01','一级','03','三级','02','二级','04','四级') JT_ZYZGMC1,
decode(a.JT_WHCDDM1,'01','大专','02','本科及以上学历','03','大专以下') JT_WHCDMC1,a.ZF_BADWBSCMC,
to_char(a.ZLKSRQ,'yyyy-MM-dd')||'~'||to_char(a.ZLJSRQ,'yyyy-MM-dd') ZLQX,
a.ZCDQ,a.YJDXX,a.YJDNJ,a.XCODE,a.YJDQX,a.YJDXXID,a.YJDQXMC,
decode(a.YJDNJ,'11','小学一年级','12','小学二年级','13','小学三年级','14','小学四年级','15','小学五年级','16','小学六年级','21','初中一年级','22','初中二年级','23','初中三年级','31','高中一年级','32','高中二年级','33','高中三年级','41','大学一年级','42','大学二年级','43','大学三年级','44','大学四年级','01','小班','02','中班','03','大班','04','大大班') YJDNJMC,
a.jt_jzzhljys,a.YHDXZSHM,a.YHDXZSFZDW,
case when a.TSBJ='珠海户籍学生' or a.TSBJ='珠海户籍跨区报读学生' then 'ZH'
when a.TSBJ='政策性照顾生' or a.TSBJ='在珠海工作居住的港澳籍人员子女' or a.TSBJ='异地务工人员随迁子女积分入学' or a.TSBJ='父母有一方为珠户的非我市户籍子女' then 'FZH' else '0' end sfzh,--珠海是否珠户
a.SFECBM,decode(SFECBM,'1','是','否') SFECBMMC,--二次报名
a.dqcl--转学插班 单亲材料
--民办招生字段
,a.JT_ZW1,a.RXFS,a.SFZXS,a.SFYZFGMXW,a.SBJD,a.CJLX,a.SFXSYB,a.SFSQZZ,a.SFDSZN,a.TC,a.SXXJTFS,a.SFCZXC,a.SXXJTJL,
decode(a.sfdq,'1',a.JT_ZW1,'0',a.JT_ZW2) JT_ZW2,
'就近入学' RXFSMC,
decode(a.SXXJTFS,'1','步行','2','自行车(含摩托车、电动自行车)','3','公共交通(含城市公交、农村客运、地铁)','4','家长自行接送','5','校车','6','其他') SXXJTFSMC,
decode(a.SBJD,'0','非随班就读','1','视力残疾随班就读','2','听力残疾随班就读','3','智力残疾随班就读','4','其他残疾随班就读') SBJDMC,
decode(a.CJLX,'0','无残疾','1','视力残疾','2','听力残疾','3','智力残疾','4','言语残疾','5','肢体残疾','6','精神残疾','7','多重残疾','9','其他残疾') CJLXMC,
'健康或良好' JKZKMC,
decode(a.GATQWM,'01','香港同胞','02','香港同胞亲属','03','澳门同胞','04','澳门同胞亲属','05','台湾同胞','06','台湾同胞亲属','11','华侨','12','侨眷','13','归侨','14','归侨子女','21','归国留学人员','31','非华裔中国人','41','外籍华裔人','51','外国人','99','其他','0','否','','否') GATQWMMC,
'群众' ZZMMMC,
decode(a.SFXSYB,'0','否','','否','1','是') SFXSYBMC,
decode(a.SFSQZZ,'0','否','','否','1','是') SFSQZZMC,
decode(a.SFDSZN,'0','否','','否','1','是') SFDSZNMC,
decode(a.SFCZXC,'0','否','','否','1','是') SFCZXCMC,
decode(a.SFLSHYFZN,'0','否','','否','1','是') SFLSHYFZNMC,
decode(a.SFZXS,'0','否','','否','1','是') SFZXSMC,
decode(a.SFLSETM,'0','否','','否','1','是') SFLSETMMC,
decode(a.SFSQZNM,'0','否','','否','1','是') SFSQZNMMC,
decode(a.SFSGXQJYM,'0','否','','是','1','是') SFSGXQJYMMC,
decode(a.SFGE,'0','否','','否','1','是') SFGEMC,
decode(a.SFYZFGMXW,'0','否','','否','1','是') SFYZFGMXWMC,a.app_id,
decode(nvl(a.CJLX,'0'),'0','否','是') SFCJR,
case  when a.SFLSETM = '1' and HKXZM = '1' then '是' else '否' end SFNCLSRT,
case  when a.SFSQZNM = '1' and HKXZM = '1' then '是' else '否' end SFJCWGRYSQZN
from zs_xsxx a
/

