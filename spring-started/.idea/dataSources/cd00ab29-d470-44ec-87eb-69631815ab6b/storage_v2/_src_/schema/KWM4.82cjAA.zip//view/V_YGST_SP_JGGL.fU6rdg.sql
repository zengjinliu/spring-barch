create view V_YGST_SP_JGGL as
select jo.bm,jo.mc,a.jgid,a.spid,a.jg,a.ny,a.jgly,a.xzsj,a.org_id,jo.app_id,jo.gg,jo.dw,jo.bz,org.org_mc
from ygst_sp jo left join ygst_sp_jg a on jo.spid=a.spid and jo.yxzt='1'
 left join jc_org org on a.org_id= org.org_id where org.org_state='1'
/

