create PROCEDURE PRO_BDYH_GETZJG_SZ_BYXSID_IN(p_xsid in char,czr in varchar2) IS
  cursor c_list is select * from v_smbd_bmshjg v where v.xsid=p_xsid;
  xs c_list%rowtype;
  --部门游标
  cursor c_bmlist(quorgid String) is select * from smbd_bmsz a where a.orgid=quorgid and a.iszjgpd='1' order by a.xh;
  bm c_bmlist%rowtype;
  v_quorgid char(32);--区机构id
  v_xsid char(32);  --获取符合部门审核的学生id
  v_shjg varchar2(2);--各个部门审核结果
  v_zjgcount int;--是否存在总结果
  v_zjg varchar2(2);--总结果
  v_zjg_hg varchar2(1);--总结果(合格)
  v_zjg_wsh varchar2(1);--总结果(未审核)
  v_zjg_bhg varchar2(1);--总结果(不合格)
  v_selsql varchar2(10000);--查询学生是否符合的学生总数
  v_xscount int;--查询学生是否符合的学生总数的into参数
  v_selsql2 varchar2(10000);--查询学生符合部门的学生信息
  v_tj varchar2(10000);--各部门条件
  
  v_ztj varchar2(10000);--子部门条件
  v_zbmid char(32);--子部门id
  v_zxsid char(32);  --获取符合部门审核的学生id
  v_zshjg varchar2(2);--各个部门审核结果
  v_sh1 varchar2(2);--非深户监护人是否合格（其中一个合格则合格）
  v_sh2 varchar2(2);--非深户监护人是否合格（其中一个合格则合格）
BEGIN
  open c_list;
  loop fetch c_list into xs;
    exit when c_list%notfound;
      v_zjg:='0';
      v_zjg_hg:='';
      v_zjg_wsh:='';
      v_zjg_bhg:='';
      --获取区机构id
      select org_id into v_quorgid from jc_org a where exists(select 1 from jc_org_relat b where b.org_id_child=xs.sqxxid1 and b.org_id=a.org_id) and exists(select 1 from jc_app_org c where c.org_id=a.org_id and c.app_id=xs.app_id) and a.org_dj='50';
      open c_bmlist(v_quorgid);
      loop fetch c_bmlist into bm;
      exit when c_bmlist%notfound;
           v_xscount:=0;
           v_xsid:='1';
           v_shjg:='';
           v_tj:='''';
           
           v_ztj:='''';
           v_zbmid:='';
           v_zxsid:='1';
           v_zshjg:='';
           v_sh1:='-1';
           v_sh2:='-1';
           if(bm.tj is not null)then
                v_tj:=''' and '||bm.tj;
           end if;
           v_selsql := 'select count(*) cnt from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||bm.bmid||'''where jo.xsid='''||xs.xsid||v_tj;
           execute immediate v_selsql into v_xscount;
           if(v_xscount>0) then
               v_selsql2:= 'select * from (select nvl(jo.xsid,''1'') xsid,nvl(b.shjg,''0'') shjg from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||bm.bmid||'''where jo.xsid='''||xs.xsid||v_tj||') where ROWNUM=1';
               execute immediate v_selsql2 into v_xsid,v_shjg;
               if(v_xsid!='1') then
                 if(v_quorgid='606d6d7ba0c04f79b880d61c31214190') then--罗湖非深户 监护人一方深户并且合格 社保结果不参加总结果判定特殊判断
                   if(xs.hjlxm in('03','04') and bm.bmdm='SBBM') then
                     if(xs.jt_hjlxm1 in('01','02','07'))then--监护人深户1
                        select a.tj,a.bmid into v_ztj,v_zbmid from smbd_bmsz a where a.orgid=v_quorgid and a.bmdm='JHRSH1';
                        if(v_ztj is not null)then
                          v_ztj:=''' and '||v_ztj;
                        end if;
                        v_selsql2:= 'select * from (select nvl(jo.xsid,''1'') xsid,nvl(b.shjg,''0'') shjg from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj||') where ROWNUM=1';
                        execute immediate v_selsql2 into v_zxsid,v_zshjg;
                        if(v_zxsid!='1') then
                            v_sh1:=v_zshjg;
                        end if;
                     end if;
                     if(xs.jt_hjlxm2 in('01','02','07'))then--监护人深户2
                       select a.tj,a.bmid into v_ztj,v_zbmid  from smbd_bmsz a where a.orgid=v_quorgid and a.bmdm='JHRSH2';
                       if(v_ztj is not null)then
                          v_ztj:=''' and '||v_ztj;
                       end if;
                       v_selsql2:= 'select * from (select nvl(jo.xsid,''1'') xsid,nvl(b.shjg,''0'') shjg from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj||') where ROWNUM=1';
                       execute immediate v_selsql2 into v_zxsid,v_zshjg;
                       if(v_zxsid!='1') then
                          v_sh2:=v_zshjg;
                       end if;
                     end if;
                     if(bm.bmdm='SBBM' and (v_sh1='1' or v_sh2='1')) then
                       v_shjg:='1';
                     end if;
                   end if;
                 end if;
                 --判断结果
                 if(v_shjg='2') then
                    v_zjg_bhg:='2';
                 end if;
                 if(v_shjg='0' or v_shjg='9') then
                    v_zjg_wsh:='0';
                 end if;
                 if(v_shjg='1') then
                    v_zjg_hg:='1';
                 end if;
               end if;
           end if;
      end loop;
      close c_bmlist;
      if(v_zjg_wsh='0') then--如果各个部门有未审核 则总结果为未审核
         v_zjg:=v_zjg_wsh;
      elsif (v_zjg_bhg='2') then
         v_zjg:=v_zjg_bhg;
      elsif (v_zjg_hg='1') then
         v_zjg:='1';
      end if;
      select count(*) into v_zjgcount from smbd_zjg a where a.xsid=xs.xsid;
      if(v_zjgcount=0) then
          insert into smbd_zjg(xsid,zjg,xzr,xzsj) values(xs.xsid,v_zjg,czr,sysdate);
          commit;
      else
          update smbd_zjg set zjg=v_zjg,gxr=czr,gxsj=sysdate where xsid=xs.xsid;
          commit;
      end if;
      update zs_xsxx a set a.zjg=v_zjg,a.zjgmc=(select dmmx_mc from jc_dmmx where dm_code='DM_ZS_SMBD_JG' and dmmx_code=v_zjg) where xsid=xs.xsid;
      commit;
  end loop;
  close c_list;
end PRO_BDYH_GETZJG_SZ_BYXSID_IN;
/

