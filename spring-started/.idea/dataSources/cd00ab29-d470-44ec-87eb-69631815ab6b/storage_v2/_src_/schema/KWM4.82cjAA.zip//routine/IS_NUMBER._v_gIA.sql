create function is_number(num varchar2) return number is
val number;
begin
  val := to_number(num);
  return 1;
  exception when others then return 0;
end;
/

