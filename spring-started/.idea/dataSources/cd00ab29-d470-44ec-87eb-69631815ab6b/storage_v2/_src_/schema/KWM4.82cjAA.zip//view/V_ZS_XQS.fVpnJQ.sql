create view V_ZS_XQS as
select
    X.ORG_ID,
    X.XQS,
    O.ORG_MC,
    O.ORG_DM
    from ZS_XQS X
      LEFT JOIN JC_ORG O ON X.ORG_ID = O.ORG_ID
/

