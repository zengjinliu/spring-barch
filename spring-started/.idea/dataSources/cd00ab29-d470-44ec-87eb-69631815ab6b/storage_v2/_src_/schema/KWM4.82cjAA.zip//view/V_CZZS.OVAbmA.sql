create view V_CZZS as
select
a.name xm,decode(a.sex,'男','1','2') xbm,a.sfzh sfzjh,d.org_id by_xxid
from
emis.x_jbqk a
inner join emis.x_zxqk b on a.jbqk_id=b.jbqk_id
inner join emis.a_school c on b.xxcode=c.xxcode
left join zs_xj_org d on d.xj_org_id=c.xxid
where
c.xxcode like '440202%'
and b.zxzk='是'
and b.nj_c='X6'
/

