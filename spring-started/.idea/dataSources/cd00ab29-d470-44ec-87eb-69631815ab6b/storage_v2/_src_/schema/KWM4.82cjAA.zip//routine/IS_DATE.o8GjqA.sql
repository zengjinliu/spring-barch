create function is_date(csrq varchar2) return number is
val date;
begin
  val := to_date(nvl(csrq,'n'),'yyyyMM');
  return 1;
  exception when others then return 0;
end;
/

