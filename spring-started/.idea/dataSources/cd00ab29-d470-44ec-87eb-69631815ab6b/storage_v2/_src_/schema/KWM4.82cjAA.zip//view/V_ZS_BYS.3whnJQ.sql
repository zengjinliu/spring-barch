create view V_ZS_BYS as
select
A.BYSID,
A.XM,
A.SFZJH,
A.XJ_XXID,
A.XJ_XXMC,
A.XB,
A.CSRQ,
A.BYDQ,
A.BY_YEAR,
A.XJH
from ZS_BYS A
/

