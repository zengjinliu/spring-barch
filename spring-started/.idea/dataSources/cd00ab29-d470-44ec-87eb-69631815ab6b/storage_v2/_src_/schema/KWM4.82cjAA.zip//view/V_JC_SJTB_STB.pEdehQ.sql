create view V_JC_SJTB_STB as
    select 'NONE' mxid,'NONE' tablename from dual
union all
select mxid,'DATA_SJTBDEMO' tablename from data_sjtbdemo
/

