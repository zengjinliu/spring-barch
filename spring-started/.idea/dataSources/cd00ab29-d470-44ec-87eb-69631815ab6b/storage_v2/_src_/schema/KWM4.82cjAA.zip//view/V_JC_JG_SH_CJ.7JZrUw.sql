create view V_JC_JG_SH_CJ as
SELECT "JGID","GH","XM","YWXM","XMPY","CYM","XBM","CSRQ","CSDM","JG","MZM","GJDQM","SFZJLXM","SFZJH","HYZKM","GATQWM","ZZMMM","JKZKM","XYZJM","XXM","ZP","SFZJYXQ","SFDSZN","YZBM","TXDZ","DH","YDDH","CZDH","DZXX","WLDZ","JSTXH",cj.xzr,cj.xzsj,cj.gxr,cj.gxsj,"STATE","CSD","GZDW",t2.OP_LX LX,t2.OP_ID OP_ID from jc_jg_CJ cj
LEFT JOIN jc_js_op T2 ON cj.jgid = t2.js_id
where cj.state!='4' and t2.op_zt=0
/

