create view USER_ROLE_ORG as
select distinct
u.u_customid,u.xzsj,o.org_mc,a.app_mc,r.role_mc
from
jc_user u
left join jc_user_role_org uro on uro.user_id=u.u_id
left join jc_role_org ro on ro.or_uuid=uro.or_uuid
left join jc_role r on r.role_id=ro.role_id
left join jc_org o on o.org_id=r.org_id
left join jc_app_org ao on ao.org_id=o.org_id
left join jc_app a on a.app_id=ao.org_id

where
u.u_state='1'
/

