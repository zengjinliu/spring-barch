create view V_JC_WJDC_XX as
select t1."XX_ID",t1."WT_ID",t1."XX_CONTENT",t1."XX_ORDER",t1."IS_OTHER",t1."WT_REQUIRED",t2.wt_content from jc_wjdc_xx t1
left join jc_wjdc_wt t2 on t1.wt_id = t2.wt_id
/

