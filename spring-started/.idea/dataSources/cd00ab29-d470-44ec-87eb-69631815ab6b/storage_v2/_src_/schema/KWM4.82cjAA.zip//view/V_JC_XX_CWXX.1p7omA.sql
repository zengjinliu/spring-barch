create view V_JC_XX_CWXX as
select jxec.cwxx_id,jxec.org_id,jxec.xq_id,jxec.jsondata,jxec.status,jxec.xzr,jxec.gxr,jxec.xzsj,jxec.gxsj,jxec.czbk,jxec.sysr,
jxec.qtsr,jxec.bjfbz,jxec.zsf,jxec.qtfwxdsf,jxec.gzfl,jxec.sssbgz,jxec.bgjf,jxec.hsfbz,jxec.sdq,jxec.jxcl,
jxec.yszp,jxec.szpx,jxec.qt,jxec.zxj,jx.xq_mc,jx.xq_nd,nvl(jxec.czbk,0)+nvl(jxec.sysr,0)+nvl(jxec.qtsr,0) as hja,
nvl(jxec.gzfl,0)+nvl(jxec.sssbgz,0)+nvl(jxec.bgjf,0)+nvl(jxec.sdq,0)+nvl(jxec.jxcl,0)+nvl(jxec.yszp,0)+nvl(jxec.szpx,0)+nvl(jxec.qt,0)+nvl(jxec.zxj,0) as hjb from jc_xx_ext_cwxx jxec
left join jc_xq jx on jx.xq_id = jxec.xq_id
/

