create view V_DZ_PGMB as
select dpb.MBID,dpb.MBORG_ID,dpb.PCID,dpb.XZR,dpb.XZSJ,dpb.GXR,dpb.GXSJ,dpb.ORG_ID,dpb.APP_ID,dp.pcmc,dp.PID,
     dp.z_starttime,dp.z_endtime,dp.s_starttime,dp.s_endtime,dpb.SBSJ,dpb.status,dpb.tbr,dpg.z_zf,dpg.s_zf,dpg.zpzj,dpg.czwt,dpg.tcld
    from dz_pgmb dpb left join dz_pc dp on dpb.pcid = dp.pcid
    left join dz_pgjg dpg on dpg.mbid = dpb.mbid
    where dp.status = 1
/

