create view V_JCJK_ZS_XSLQXX as
select
a.XSID,
a.LSH BMLSH,
a.SFZJH,
a.XM XSXM,
a.PWD,
i.DMMX_MC XXCSZT,
f.DMMX_MC ZLSHZT,
n.DMMX_MC LQZT,
'' QSHZT,
p.DMMX_MC ZCZT,
a.XQJF JF,
m.LQ_ORGID LQXXBM,
o.ORG_MC LQXXMC,
b.sqxxid SQXXID
from zs_xsxx a
left join zs_xsxx_sqxx b on b.xsid=a.xsid and b.xh=1
left join zs_xsxx_shzt d on d.xsid=a.xsid    --学生信息审核状态
left join smbd_zjg e on e.xsid=a.xsid --双免总结果
left join zs_xsxx_lqzt m on m.xsid=a.xsid --录取状态表
left join jc_org o on m.lq_orgid=o.org_id and o.org_state='1'
left join zs_xsxx_zczt x on x.xsid=a.xsid --注册状态表
left join jc_dmmx f on f.dm_code='DM_ZS_SMBD_JG' and f.dmmx_code=e.zjg and f.dmmx_state='1'
left join jc_dmmx i on i.dm_code='DM_ZS_SHZT' and d.shzt=i.dmmx_code and i.dmmx_state='1'
left join jc_dmmx n on n.dm_code='DM_ZS_LQZT' and m.lqzt=n.dmmx_code and n.dmmx_state='1'
left join jc_dmmx p on p.dm_code='DM_ZS_ZCZT' and x.zczt=p.dmmx_code and p.dmmx_state='1'
where d.shzt!='0'
/

