create function FN_UUID return varchar2 is  kwuuid varchar2(32);
begin
  kwuuid := sys_guid();
return kwuuid;
end FN_UUID;
/

