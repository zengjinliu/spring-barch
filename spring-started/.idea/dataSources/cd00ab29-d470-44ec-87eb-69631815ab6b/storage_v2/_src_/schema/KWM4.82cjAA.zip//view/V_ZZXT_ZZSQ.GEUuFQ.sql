create view V_ZZXT_ZZSQ as
SELECT z."ZZSQID",z."XMID",z."XSID",z."STATE",FN_DATE_TOSTRFORMAT(z."SQSJ",'yyyy-MM-dd') "SQSJ",z."FLOWSTATE",z."NODECODE",
z."NODENAME",z."XZR",z."XZSJ",z."GXR",z."GXSJ",z."XMZID",z."ZJID", v.XM,v.xjfh,
 v.XBMC,v.njmc,v.bjmc,x.XMMC,j.zzbh,j.zjlx,d3.dmmx_mc "ZJLXM",m.xmzmc,m.xmzzt,m.xd,v.xbm,
 v.xxmc,v.SFZJH,v.SFZJLX,FN_DATE_TOSTRFORMAT(j.zjyxq,'yyyy-MM-dd') ZJYXQ,D2.DMMX_MC HJMC, V.HJ,X.START_TIME,
 X.End_Time,X.XDMC,D4.DMMX_MC CZRHJMC,J.CZRHJ,
 X.Je,X.XMMS,X.ZZDX,J.BFDW,FN_DATE_TOSTRFORMAT(J.BFSJ,'yyyy-MM-dd') BFSJ,J.CZR,E2.DMMX_MC CZRGXMC,j.CZRLXFS,J.ZJFJ,v.XXID,v.NJID,v.BJID,v.ORG_ID
        FROM ZZXT_ZZSQ z
        LEFT JOIN v_jc_zz_xs v ON z.XSID = v.TXSID
        LEFT JOIN v_zzxt_xm x ON z.xmid = x.xmid
        LEFT JOIN jc_xs_zj j ON z.zjid = j.zjid
        LEFT JOIN zzxt_xmz m ON z.xmzid = m.xmzid
        LEFT JOIN JC_DMMX D2 ON D2.DMMX_CODE = v.hj AND D2.DM_CODE = 'DM_HJ'
        LEFT JOIN JC_DMMX D4 ON D4.DMMX_CODE = J.CZRHJ AND D4.DM_CODE = 'DM_HJ'
        LEFT JOIN JC_DMMX D3 ON D3.DMMX_CODE = j.ZJLX AND D3.DM_CODE = 'DM_CZLX'
        LEFT JOIN JC_DMMX E1 ON m.xd = E1.DMMX_CODE AND E1.DM_CODE = 'DM_JYJD'
        LEFT JOIN JC_DMMX E2 ON E2.DMMX_CODE = J.Czrgx AND E2.DM_CODE = 'DM_YDQRGX'
        WHERE z.STATE = 1
/

