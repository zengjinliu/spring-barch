create view V_JC_ZJK_ZPMS as
select t.zjk_id,v."JGID",v."GH",v."XM",v."YWXM",v."XMPY",v."CYM",v."XBM",
v."XBMC",v."CSRQ",v."CSDM",v."JG",v."MZM",v."GJDQM",v."SFZJLXM",v."SFZJLXMC",
v."SFZJH",v."HYZKM",v."GATQWM",v."ZZMMM",v."JKZKM",v."XYZJM",v."XXM",v."ZP",
v."SFZJYXQ",v."SFDSZN",v."YZBM",v."TXDZ",v."DH",v."YDDH",v."CZDH",v."DZXX",
v."WLDZ",v."JSTXH",v."STATE",v."CSD",v."GZDW",
e1.dmmx_mc "SSHYMC",e1.dmmx_code "SSHY", z3.lbmc "DLBMC",z3.zjlb_id "DLBDM",
z3.uuid "DLBDMID", z4.lbmc "XLBMC",z4.zjlb_id "XLBDM",z4.uuid "XLBDMID"
from jc_zjk_zpms t
LEFT JOIN v_jc_dxxz v ON t.jg_id = v.JGID
LEFT JOIN jc_dmmx E1 ON t.sshy = E1.DMMX_CODE and e1.dm_code = 'DM_SSHY'
LEFT JOIN (
select z1.lbmc,z2.jg_id,z1.lbdm,z2.gl_id,z1.zjlb_id,z2.uuid from jc_zjk_zjlb z1
left join jc_zjk_zpms_zjlb z2 on z1.lbdm = z2.lbdm
where z1.dj = '1'
) z3 ON t.jg_id = z3.jg_id and t.zjk_id = z3.gl_id
LEFT JOIN (
select z1.lbmc,z2.jg_id,z1.lbdm,z2.gl_id,z1.zjlb_id,z2.uuid from jc_zjk_zjlb z1
left join jc_zjk_zpms_zjlb z2 on z1.lbdm = z2.lbdm
where z1.dj = '2'
) z4 ON t.jg_id = z4.jg_id and t.zjk_id = z4.gl_id
where t.status = 1
/

