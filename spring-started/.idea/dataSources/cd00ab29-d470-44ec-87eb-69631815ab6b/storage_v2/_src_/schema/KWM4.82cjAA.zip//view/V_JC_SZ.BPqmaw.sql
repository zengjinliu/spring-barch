create view V_JC_SZ as
select
SZ_ID,a.ORG_ID,PRO_ID,SZ_VAL,SZ_ORDER,SZ_DM,GROUP_MC,a.XZSJ,b.DMMX_MC SZMC,c.DMMX_CODE FDMMX_CODE,
a.SZ_LX,d.DMMX_MC SZ_LX_N,e.ORG_DJ
from jc_sz a
inner join jc_org e on e.org_id=a.org_id and e.org_state='1'
left join jc_dmmx b on a.sz_dm=b.dmmx_code and b.DM_CODE='DM_SZ_CHILD' and b.dmmx_state='1'
left join jc_dmmx c on b.p_dm_id=c.dmmx_id and c.DM_CODE='DM_SZ' and c.dmmx_state='1'
left join jc_dmmx d on a.sz_lx=d.dmmx_code and d.DM_CODE='DM_SZ_VAL_LX' and c.dmmx_state='1'
/

