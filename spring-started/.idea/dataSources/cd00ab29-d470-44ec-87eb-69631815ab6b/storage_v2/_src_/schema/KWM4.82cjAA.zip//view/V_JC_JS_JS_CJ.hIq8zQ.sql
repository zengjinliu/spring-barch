create view V_JC_JS_JS_CJ as
SELECT zs.jsjs_id as zsid,t1.op_id,t1.jsjs_id,t1.js_id,t1.xzr,t1.xzsj,t1.gxr,t1.gxsj,t1.status,t1."PRJSZW",t1."PRKSNY",t1."PRJSNY",t1."PRDWMC"
FROM JC_JS_JS_CJ T1
LEFT JOIN jc_js_js zs ON T1.JSJS_ID = zs.jsjs_id
/

