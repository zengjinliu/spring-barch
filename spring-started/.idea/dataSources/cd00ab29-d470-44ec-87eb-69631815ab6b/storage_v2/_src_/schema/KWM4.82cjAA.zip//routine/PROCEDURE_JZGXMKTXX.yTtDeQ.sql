create procedure procedure_jzgxmktxx -- 创建存储过程 教职工项目（课题）信息
  as
  tbsj date;
  begin
  select max(time_bz) into tbsj from gz_sjjh.JS_TB_BIZ_JZGKJXMXX;
  delete from JC_JS_KY_KT b where exists   (select 1 from  gz_sjjh.JS_TB_BIZ_JZGKJXMXX a where a.id=b.jsky_id and a.TIME_BZ> ( select c.updatetime from JC_DATA_TIME c  where c.model_type = 'JC_JS_KY_KT'));
  insert into JC_JS_KY_KT b (jsky_id,JS_ID,XMLX,SFCGDB,XMMC,XMPZH,XKLY,XMJFED,KSNY,JSNY,BRJS,BRPM,XMWTDW,XMLY,STATUS,XZR,XZSJ)
  select j.id,
      JB.JSJB_ID,
      (select d4.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d4 where d4.zdbs='XMLX' and d4.zdxbs = j.XMLX)XMLX,
      (select d1.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d1 where d1.zdbs='SFSDBXCGHXM' and d1.zdxbs = j.SFSDBXCGHXM)SFSDBXCGHXM,
      j.Xmmc,
      j.Xmpzh,
      (select d5.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d5 where d5.zdbs='XKLY' and d5.zdxbs = j.Xkly)Xkly,
      j.Xmjfed,
      j.Ksrq,
      j.jsrq,
      (select d2.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d2 where d2.zdbs='XMZBRJS' and d2.zdxbs = j.XMZBRJS)XMZBRJS,
      (select d3.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d3 where d3.zdbs='BRPM' and d3.zdxbs = j.BRPM)BRPM,
      j.XMWTDW,
      (select d6.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d6 where d6.zdbs='XMLY' and d6.zdxbs = j.XMLY)XMLY,
      '1',
      'SJTB',
      sysdate
  from gz_sjjh.JS_TB_BIZ_JZGKJXMXX j
  join JC_JS_JB JB
  on j.JSID = JB.JSJB_ID
  where  j.SFSC = '0' and j.shzt='2' and j.TIME_BZ>(  select c.updatetime from JC_DATA_TIME c  where c.model_type = 'JC_JS_KY_KT');
  update JC_DATA_TIME set updatetime = tbsj where model_type = 'JC_JS_KY_KT';

   exception when others then
  dbms_output.put_line(sqlcode||'>>>>>>' || sqlerrm);
  commit;
end procedure_jzgxmktxx;
/

