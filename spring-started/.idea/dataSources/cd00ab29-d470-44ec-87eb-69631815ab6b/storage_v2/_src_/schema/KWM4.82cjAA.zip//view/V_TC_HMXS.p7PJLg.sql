create view V_TC_HMXS as
select
th.HMID,th.XSID,th.PCID,th.HMDM,th.APPID,th.REMARK,th.ORGID,jb.bmc,jx.xm,DECODE(jx.XBM,'1','男'，'2','女','') XB,
jx.sfzjh,jo.org_id,jo.org_mc,jx.njdm as njmc,jx.bjmc,jb.bid
from tc_hmxs th
left join jc_batch jb on jb.bid = th.pcid
left join tc_xs jx on jx.xsid = th.xsid
left join jc_org jo on jo.org_id = jx.org_id
/

