create view V_YGST_SP_JGJS as
select a.mc,jo.jsjgid,jo.spid,jo.jsjg, jo.ny,jo.bz,jo.xzsj from ygst_sp_jgjs jo left join ygst_sp a on a.spid=jo.spid
/

