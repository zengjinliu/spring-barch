create Procedure pro_zs_createlsh
is
cursor xss is select xsid,sqxxid1 sqxx,app_id from v_zs_xsxx where lsh is null;
xs xss%rowtype;
v_lshwz number;
v_lshbz varchar2(10);
v_lshwz_count number;
v_lshbz_count number;

begin
 open xss;
 loop
   fetch xss into xs;
   exit when xss%notfound;
     if xs.sqxx is not null then

     select count(*) into v_lshbz_count from zs_xxxx where org_id=xs.sqxx and app_id=xs.app_id;
     if(v_lshbz_count>0) then
       select lshbz into v_lshbz from zs_xxxx where org_id=xs.sqxx and app_id=xs.app_id;
       if(v_lshbz is null) then
         select nvl(max(substr(to_char(to_number('1'||lshbz)+1),2,5)),'1000') into v_lshbz from zs_xxxx;
         update zs_xxxx a set a.lshbz=v_lshbz where a.org_id=xs.sqxx and a.app_id=xs.app_id;
       end if;

         select count(*) into v_lshwz_count from zs_xxxx_lsh where org_id=xs.sqxx and app_Id=xs.app_id;
         if(v_lshwz_count=0) then
           insert into zs_xxxx_lsh(org_id,app_id,wz)values(xs.sqxx,xs.app_id,1000);
           commit;
         end if;

         select substr(to_char(to_number('1'||wz)+1),2,5) into v_lshwz from zs_xxxx_lsh where org_id=xs.sqxx and app_id=xs.app_id;
         update zs_xxxx_lsh set wz=v_lshwz where org_id=xs.sqxx and app_id=xs.app_id;
         update zs_xsxx set lsh=v_lshbz||v_lshwz where xsid=xs.xsid;
         commit;
       end if;
     end if;
   end loop;
   close xss;
      EXCEPTION
        when others then
          rollback;
  end;
/

