create view V_ZJCJ_ZJ as
select
zjid,
orgid,
orgid as org_id,
zjmc,
zjlx,
bz,
sfzsxt,
dx,
cols,
col_mcs,
col_dm,
col_val,
status,
xzr,
xzsj,
gxr,
gxsj,
orgmc,
col_dmmc,
ZJCJ_ORDER
from zjcj_zj
/

