create procedure PRO_DZ_TJ_SHJD 
is
begin
  
end DZ_TJ_SHJD;
/

