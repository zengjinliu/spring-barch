create function FN_GETDESKEY return varchar2 is
  v_des_key varchar2(8);
begin
  v_des_key := '';
  SELECT nvl(DES_KEY,'1wdvvhu8') into v_des_key FROM JC_DESKEY;
  return v_des_key;
  EXCEPTION
     WHEN OTHERS THEN
     v_des_key:='8uhbvdw1';
  return v_des_key;
end FN_GETDESKEY;

/

