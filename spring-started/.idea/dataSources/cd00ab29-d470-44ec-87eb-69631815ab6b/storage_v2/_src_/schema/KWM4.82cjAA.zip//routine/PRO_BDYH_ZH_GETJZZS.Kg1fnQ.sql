create PROCEDURE pro_bdyh_zh_getjzzs(p_sfzjh in varchar2) IS
CURSOR person is select * from smbd_sj a where a.rsj3='false'
    --and exists(select 1 from smbd_bmsz b where b.bmdm in('JHR1HJ','JHR2HJ') and b.bmid=a.bmid)
    and a.sj2=p_sfzjh;
perc person%ROWTYPE;

TYPE t_arr_datestr IS TABLE OF VARCHAR2(30) INDEX BY BINARY_INTEGER;
v_arr_datestr t_arr_datestr;--记录起始时间和结束时间之间的月份集合

TYPE t_arr_count IS TABLE OF VARCHAR2(30) INDEX BY BINARY_INTEGER;
v_arr_count t_arr_count;--记录不重复的月份集合

TYPE datelist IS REF CURSOR;

v_cnt   NUMBER;--最终的数组长度
v_jjzbh VARCHAR2(30);--居住证编号
v_xsid CHAR(32);--学生id
v_xsid_count NUMBER;--根据学生id查找到的记录数量
v_month_start date;--计算月份的起始时间
v_month_end date;--计算月份的结束时间
v_month NUMBER;--月份差
v_str varchar2(4000);--用户的历史记录明细
v_jzzbq varchar2(20);--用户的历史记录明细
BEGIN
OPEN person;
 LOOP FETCH person INTO perc;
   EXIT WHEN person%NOTFOUND;
      /** select count(*) INTO v_xsid_count from v_zs_xsxx where xsid=perc.sjid;
       IF v_xsid_count=0 THEN
         v_xsid:='null';
       ELSE
         select xsid INTO v_xsid from v_zs_xsxx where lsh=perc.sjid;
       END IF;*/
       
       v_str:='';
       --根据家长的身份证件号循环出所有的历史办理录时间段 作为datelist开始循环
       FOR datelist in (select t.yxrq_s ,t.yxrq_e,t.jzzbh,t.sspcs,t.xjdz,instr(xjdz,'斗门') iscz,instr(xjdz,'金湾') isjw,instr(xjdz,'高栏港') isglg,instr(xjdz,'横琴') ishq,
         case when sspcs in ('斗门分局上横派出所','斗门分局乾务派出所','斗门分局五山派出所','斗门分局井岸派出所','斗门分局六乡派出所','斗门分局坭湾派出所','斗门分局城南派出所','斗门分局斗门派出所','斗门分局新青派出所','斗门分局白蕉派出所','斗门分局莲溪派出所') then '1' else '0' end ispcs,
         case when sspcs in ('金湾分局三灶派出所','金湾分局小林派出所','金湾分局红旗派出所','金湾分局金海岸派出所','金湾分局金海滩派出所') then '1' else '0' end isjwpcs,
         case when sspcs in ('高栏港分局高栏港派出所','高栏港分局南水派出所','高栏港分局平沙派出所','高栏港分局温泉派出所') then '1' else '0' end isglgpcs,
         case when sspcs in ('横琴分局横琴派出所') then '1' else '0' end ishqpcs from smbd_zh_jzzs t where t.sfzjh=perc.SJ2 order by t.sfzjh,yxrq_s) LOOP
       v_jzzbq:='true';
       --斗门
       if(perc.org_id='7f051fd34abf41a6bd5b27c5848bfed2'and datelist.ispcs='0'and datelist.iscz<1) then
          v_jzzbq:='false';
       --金湾
       elsif(perc.org_id='52f4614f636a4a45ada54bedb33f0ae4' and datelist.isjwpcs='0' and datelist.isjw<1) then
          v_jzzbq:='false';
       --高栏港
       elsif(perc.org_id='' and datelist.isglg='0' and datelist.isglgpcs<1) then
          v_jzzbq:='false';
       --横琴
       elsif(perc.org_id='' and datelist.ishq='0' and datelist.ishqpcs<1) then
          v_jzzbq:='false';
       end if;
       
       IF datelist.yxrq_s is not null and datelist.yxrq_e is not null and v_jzzbq='true' THEN --当某条记录的办理开始时间和结束时间不为空时 
                v_jjzbh:=datelist.jzzbh;--记录此时的居住证编号到v_jjzbh

                --根据规定的起始时间段重新规划起始时间
                select case when to_date('2018-08-31','yyyy-mm-dd')<datelist.yxrq_e then to_date('2018-08-31','yyyy-mm-dd') when to_date('2010-09-1','yyyy-mm-dd')>datelist.yxrq_e then to_date('2010-09-1','yyyy-mm-dd') else datelist.yxrq_e end into v_month_end from dual;
                select case when to_date('2010-09-1','yyyy-mm-dd')<datelist.yxrq_s then datelist.yxrq_s when to_date('2018-08-31','yyyy-mm-dd')<datelist.yxrq_s then to_date('2018-08-31','yyyy-mm-dd') else to_date('2010-09-1','yyyy-mm-dd') end into v_month_start from dual;

                --得到办理记录的起始月份差
                select round(months_between(v_month_end,v_month_start)) rr  INTO v_month from dual;

                IF V_MONTH>0 THEN
                    v_str:=v_str||to_char(v_month_start,'yyyy-mm-dd')||'至'||to_char(v_month_end,'yyyy-mm-dd')||'('||v_jjzbh||');';--添加用户积分明细
                    select  to_char(add_months(v_month_start,level-1),'yyyyMM') BULK COLLECT INTO v_arr_datestr from dual connect by level <= v_month;
                    FOR i IN 1 .. v_arr_datestr.COUNT LOOP
                         IF v_arr_count.COUNT>0 THEN
                            FOR j IN 1 .. v_arr_count.COUNT LOOP
                               IF v_arr_count(j)=v_arr_datestr(i)
                               THEN EXIT;
                               ELSE IF j=v_arr_count.COUNT
                                  THEN v_arr_count(j+1):=v_arr_datestr(i);
                                  ELSE continue;
                                  END IF;
                               END IF;
                            END LOOP;
                         ELSE v_arr_count(1):=v_arr_datestr(i);END IF;
                    END LOOP;
              END IF;
            END IF;
        END LOOP;
        v_cnt:=v_arr_count.COUNT;
        update smbd_sj set RSJ12=v_cnt,RSJ13=v_str where ORDER_ID=perc.order_id;
        COMMIT;
        v_arr_count.DELETE;
 END LOOP;
CLOSE person;
EXCEPTION
WHEN OTHERS THEN
    ROLLBACK;
END;
/

