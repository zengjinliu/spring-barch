create view V_JC_JS_DY as
SELECT t1.jsdy_id,t1.js_id,t1.xzr,t1.xzsj,t1.gxr,t1.gxsj,t1.status,t1."DYND",t1."NDGZ",t1."YDJBGZ",t1."YDJXGZ",t1."YDXCBZ",t1.ydtjbt,t1."YDQTBT",t1."SFWXYJ",t2.dmmx_mc dmmx_SFWXYJ_mc FROM JC_JS_DY T1
LEFT JOIN JC_DMMX T2 ON T1.SFWXYJ = T2.DMMX_CODE AND T2.DM_CODE = 'DM_SFBZ'
/

