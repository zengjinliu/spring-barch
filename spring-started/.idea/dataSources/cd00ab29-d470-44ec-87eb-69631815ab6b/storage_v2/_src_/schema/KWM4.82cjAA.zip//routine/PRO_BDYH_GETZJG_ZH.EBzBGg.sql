create PROCEDURE PRO_BDYH_GETZJG_ZH IS
  cursor c_list is select * from smbd_max_time_zh;
  xs c_list%rowtype;
  v_app_id varchar(32);
  v_org_id varchar(32);
BEGIN
  open c_list;
  loop fetch c_list into xs;
    exit when c_list%notfound;
      v_app_id := xs.app_id;
      v_org_id := xs.org_id;
      pro_bdyh_getzjg_zh_by_shsj(v_app_id,v_org_id);
  end loop;
  close c_list;
end PRO_BDYH_GETZJG_ZH;
/

