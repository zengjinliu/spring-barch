create function FN_TONUMBER(input_ NUMBER) return  NUMBER is v_number NUMBER(6,2);
begin
   v_number:=to_number(input_);
  return v_number;
end FN_TONUMBER;
/

