create view V_ZS_XSXXORHISTORY as
select a.XSID,a.XM,a.SFZJH,a.CQR,a.CQR_SFZJH,b.SQXXID ORG_ID
from zs_xsxx a left join zs_xsxx_sqxx b on b.xsid=a.xsid and b.xh='1'
/

