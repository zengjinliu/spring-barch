create view V_TC_CS_RESULT as
select JO.R_ID,JO.PCID,JO.XSID,JO.CSID,JO.RESULT,JO.CSSJ,JO.APPID,JO.ORGID,
TC.Csxmmc,TC.Dw_Code,trunc(JO.Result/60) Result1,mod(JO.Result,60) Result2,JB.Bmc PCMC
,VJX.ORG_ID,VJX.ORG_MC,VJX.XM,VJX.XBM,VJX.XJH,VJX.BJBH,VJX.BJMC,VJX.NJDM,I.DMMX_MC DWMC
from tc_cs_result JO
left join tc_csxm TC on tc.csid=JO.csid
left join jc_batch JB on JB.Bid=JO.Pcid
left join v_tc_xs VJX on VJX.XSID=JO.Xsid
LEFT JOIN JC_DMMX I ON I.DMMX_CODE=TC.Dw_Code AND I.DM_CODE='DM_DWCODE' AND I.DMMX_STATE='1'
/

