create function FN_SYSDATE return date is  kwdate date;
begin 
  kwdate := sysdate;
return kwdate;
end FN_SYSDATE;
/

