create procedure PRO_TC_DXCJTJ --计分结果中间表，方便echarts使用
is
  --游标1：体测批次
  cursor batches is select * from v_jc_batch a where a.bid='ea30beabfcc645319324f3208a01120e';
  --游标2：体测计分项目
  cursor jfxms is select * from tc_jfxm b;
  --游标3：体测年级代码
  cursor njs is select * from jc_dmmx where dm_code='DM_NJDM' and dmmx_code in('11','12','13','14','15','16','21','22','23','31','32','33');
  --游标4：体测性别
  cursor xbs is select * from jc_dmmx where dm_code='DM_XB' and dmmx_code in('1','2');
  --游标5：体测学校
  cursor xxids is select distinct(orgid) from tc_jf_result where orgid is not null;
  
  batch batches%rowtype ;
  jfxm jfxms%rowtype ;
  nj njs%rowtype ;
  xb xbs%rowtype ;
  xxid xxids%rowtype ;

  v_zrs number default 0;
  v_yx number default 0;
  v_lh number default 0;
  v_jg number default 0;
  v_bjg number default 0;
  v_yl number default 0;
  v_hg number default 0;
  v_iscz number default 0;
begin
    open batches;
    loop
     fetch batches into batch;
     exit when batches%notfound;
     
       open jfxms;
       loop
         fetch jfxms into jfxm;
         exit when jfxms%notfound;  
         
          open xxids;
          loop
            fetch xxids into xxid;
            exit when xxids%notfound;  
            
          open njs;
          loop
            fetch njs into nj;
            exit when njs%notfound;     
                  
             open xbs;
             loop
               fetch xbs into xb;
               exit when xbs%notfound;     
                  
                    select count(rid) into v_zrs from tc_jf_result a left join v_tc_xs b on b.xsid=a.xsid 
                    where a.pcid=batch.bid and a.jfid=jfxm.jfid and a.orgid=xxid.orgid and b.njdm=nj.dmmx_code and b.xbm=xb.dmmx_code;
                    if(v_zrs>0)
                    then
                        select count(rid) into v_yx from tc_jf_result a left join v_tc_xs b on b.xsid=a.xsid 
                        where a.pcid=batch.bid and a.jfid=jfxm.jfid and a.orgid=xxid.orgid and b.njdm=nj.dmmx_code and b.xbm=xb.dmmx_code and a.bzf>=90;                      
                        select count(rid) into v_lh from tc_jf_result a left join v_tc_xs b on b.xsid=a.xsid 
                        where a.pcid=batch.bid and a.jfid=jfxm.jfid and a.orgid=xxid.orgid and b.njdm=nj.dmmx_code and b.xbm=xb.dmmx_code and a.bzf>=80 and a.bzf<90;
                        select count(rid) into v_jg from tc_jf_result a left join v_tc_xs b on b.xsid=a.xsid 
                        where a.pcid=batch.bid and a.jfid=jfxm.jfid and a.orgid=xxid.orgid and b.njdm=nj.dmmx_code and b.xbm=xb.dmmx_code and a.bzf>=60 and a.bzf<80;
                        select count(rid) into v_bjg from tc_jf_result a left join v_tc_xs b on b.xsid=a.xsid 
                        where a.pcid=batch.bid and a.jfid=jfxm.jfid and a.orgid=xxid.orgid and b.njdm=nj.dmmx_code and b.xbm=xb.dmmx_code and a.bzf<60;    
                        select count(rid) into v_yl from tc_jf_result a left join v_tc_xs b on b.xsid=a.xsid 
                        where a.pcid=batch.bid and a.jfid=jfxm.jfid and a.orgid=xxid.orgid and b.njdm=nj.dmmx_code and b.xbm=xb.dmmx_code and a.bzf>=80; 
                        select count(rid) into v_hg from tc_jf_result a left join v_tc_xs b on b.xsid=a.xsid 
                        where a.pcid=batch.bid and a.jfid=jfxm.jfid and a.orgid=xxid.orgid and b.njdm=nj.dmmx_code and b.xbm=xb.dmmx_code and a.bzf>=60;   
                        
                        select count(*) into v_iscz from tc_jf_result_mid where pcid=batch.bid and jfid=jfxm.jfid and xxid=xxid.orgid and njdm=nj.dmmx_code and xb=xb.dmmx_code;
                        if(v_iscz>0)
                        then
                             update tc_jf_result_mid  set zrs=v_zrs,yxrs=v_yx,lhrs=v_yl,jgrs=v_jg,bjgrs=v_bjg,ylrs=v_yl,hgrs=v_hg
                             where pcid=batch.bid and jfid=jfxm.jfid and xxid=xxid.orgid and njdm=nj.dmmx_code and xb=xb.dmmx_code;
                        else  
                               insert into tc_jf_result_mid(zjid,pcid,jfid,xxid,njdm,xb,zrs,yxrs,lhrs,jgrs,bjgrs,ylrs,hgrs) values
                               (fn_uuid,batch.bid,jfxm.jfid,xxid.orgid,nj.dmmx_code,xb.dmmx_code,v_zrs,v_yx,v_lh,v_jg,v_bjg,v_yl,v_hg);    
                        end if;        
                    end if;
                    commit;
             end loop;
             close xbs;   
                  
          end loop;
          close njs;  
          
          end loop;
          close xxids;   
                   
       end loop;
       close jfxms;  
                    
    end loop;
    close batches;
  
end PRO_TC_DXCJTJ;
/

