create view V_XXCOUNT as
    (select jx.org_id,jo.org_mc xxmc,
               case
                 when jx.SFFSY = '0' then
                  '是'
                 else
                  '否'
               end sfdlsz,
               case
                 when jx.XXJBZM != '999' then
                  '公办'
                 else
                  '民办'
               end fbqk,
               case
                 when jx.JGZDCXLB = '111' or jx.JGZDCXLB = '112' then
                  '城区'
                 when jx.JGZDCXLB = '121' or jx.JGZDCXLB = '122' then
                  '镇区'
                 when jx.JGZDCXLB = '210' or jx.JGZDCXLB = '220' then
                  '乡村'
               end fczqk
          from jc_xx jx
          left join jc_org jo
            on jo.org_id = jx.org_id
         where
           (jx.XXBXLXM = '111' or jx.XXBXLXM = '119')
           and jo.org_state = '1')
/

