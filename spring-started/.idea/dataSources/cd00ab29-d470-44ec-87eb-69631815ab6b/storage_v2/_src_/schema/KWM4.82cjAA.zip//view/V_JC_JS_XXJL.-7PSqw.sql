create view V_JC_JS_XXJL as
    select jsxx_id,
js_id,
sfzgxl,
xlm,
xlgj,
xlyx,
sxzy,
sfsf,
rxny,
byny,
xwcc,
xwmc,
xwgj,
xwyx,
xwsyny,
xxfs,
zxdwlb,
status,
xzr,
gxr,
xzsj,
gxsj from JC_JS_XX_CJ union
select "JSXX_ID","JS_ID","SFZGXL","XLM","XLGJ","XLYX","SXZY","SFSF","RXNY","BYNY","XWCC","XWMC","XWGJ","XWYX","XWSYNY","XXFS","ZXDWLB","STATUS","XZR","GXR","XZSJ","GXSJ" from JC_JS_XX
/

