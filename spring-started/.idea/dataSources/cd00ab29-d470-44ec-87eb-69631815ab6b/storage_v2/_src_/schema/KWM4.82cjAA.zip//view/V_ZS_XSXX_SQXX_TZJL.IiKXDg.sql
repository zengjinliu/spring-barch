create view V_ZS_XSXX_SQXX_TZJL as
select
    B.LSH,b.xm,B.SFZJH,Z.TZID,Z.TZQ_XXID,Z.TZQ_XXMC,Z.TZH_XXID,Z.TZH_XXMC,Z.TZSJ,Z.TZR,Z.XSID,a.U_USERNAME TZRMC,Z.TZSM,b.HJLXMC,b.FCLBMC,b.XWLB
from ZS_XSXX_SQXX_TZJL Z
left join jc_user a on z.tzr=a.u_id
left join zs_xsxx b on b.shzt>0 and b.sfcssj='0' and z.xsid=b.xsid
/

