create view V_JC_SJTBMX as
select "MXID","SJ",sj."XZR",sj."XZSJ",sj."GXR",sj."GXSJ",sj."ORG_ID","APP_ID","YWLX","TBID",nvl(sj.GXSJ,sj.XZSJ) zjxgsj,sj.szid,sj.xzrid
from jc_sjtbmx sj
where sj.yxzt > '0'
/

