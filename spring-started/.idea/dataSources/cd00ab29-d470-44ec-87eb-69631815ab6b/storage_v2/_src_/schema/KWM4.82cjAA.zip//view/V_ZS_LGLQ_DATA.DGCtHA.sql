create view V_ZS_LGLQ_DATA as
select
a.zf_fclb,
a.xsid,
a.sfzjh,
a.xqjf,
a.yddjf1,
a.hjlxmc,
case when xqjf-jcf+a.yddjf1 > 10 then jcf + 10 else a.xqjf + a.yddjf1 end yddxqjf,
a.xwlb,
a.is_xq,
a.xm,
a.hkszdm,
a.hkszd,
decode(a.js_qk,'A','A','B') js_qk,
a.sqxxid1,
a.sqxxid2,
a.sqxxid3,
a.sqxxid4,
a.sqxxmc1,
a.sqxxmc2,
a.sqxxmc3,
a.sqxxmc4,

/*
第三类学区户籍中，使用特殊住房（集资房、祖辈房、自建房）的，在原始数据中的发证时间，你取的是户籍迁入时间，
同时使用租赁材料的取的备案时间，两个是不同的时间，不能作为比较，
使用租赁材料的用备案时间比较居住时间长短，使用特殊住房的，在同分情况下，应该先录取有居住材料的才对
*/
case when a.hjlxm='07' and (a.zf_fclb in ('03','04','05','06','07') or (a.zf_fclb='11' and a.zf_qddx='公司')) then 2 else 1 end zfdj,

case when a.hjlxm='07' and (a.zf_fclb in ('03','04','05','06','07') or (a.zf_fclb='11' and a.zf_qddx='公司')) then a.zf_qrdate
--when a.hjlxm in ('01','02','05') and (a.zf_fclb in ('01','02','08','09','10','12','13') or (a.zf_fclb='11' and a.zf_qddx='个人')) then a.zf_fzdate
--购房合同的时间不作为排序条件
when a.hjlxm in ('01','02','05') and (a.zf_fclb in ('01','08','09','10','12','13') or (a.zf_fclb='11' and a.zf_qddx='个人')) then a.zf_fzdate
--when a.zf_fclb in ('01','02','08','09','10','13','12') then a.zf_fzdate
when a.zf_fclb in ('01','08','09','10','13','12') then a.zf_fzdate
else null end zf_fzdate,
case when a.hjlxm='07' and (a.zf_fclb in ('03','04','05','06','07') or (a.zf_fclb='11' and a.zf_qddx='公司')) then a.zf_qrdate
when a.hjlxm in ('01','02','05') and (a.zf_fclb in ('01','08','09','10','12','13') or (a.zf_fclb='11' and a.zf_qddx='个人')) then a.zf_fzdate
else null end zf_fzdate2,
case when a.hjlxm='07' and (a.zf_fclb in ('03','04','05','06','07') or (a.zf_fclb='11' and a.zf_qddx='公司')) then a.zf_qrdate
when (a.zf_fclb in ('01','08','09','10','13','12') or (a.zf_fclb='11' and a.hjlxm in ('01','02','05'))) then a.zf_fzdate
else null end zf_fzdate3,
a.njdm,
a.hjlx,
a.jynx+0 jynx,
decode(a.zf_fclb,'08','租赁凭证','12','租赁信息','') zflb,
decode(a.zf_fclb,'08',1,2) zfjb,
decode(a.js_qk,'A','独生子女','B','政策内或全面二孩','C','政策外但已接受处理','D','其它情况') js_qk2,
a.x_szhj2,
a.ylqzt,a.ylqxx,
a.lqzt,a.app_id,a.shzt,a.sfcssj,a.zjg,a.ylqxxid,a.lqxxid,
a.isyhdx,
a.sfzs
from v_zs_lglq a
/

