create view V_ZS_BYQX as
select BYID,NF,BYXX,XM,XB,SFZJH,HKSZD,BJ,LSH,APP_ID,ORG_ID,XX_ORG_ID
--申请学校
--录取学校
from zs_byqx
/

