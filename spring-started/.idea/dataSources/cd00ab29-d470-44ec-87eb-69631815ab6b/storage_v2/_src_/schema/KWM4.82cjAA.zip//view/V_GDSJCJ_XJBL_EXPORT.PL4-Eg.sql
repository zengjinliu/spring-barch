create view V_GDSJCJ_XJBL_EXPORT as
select
a.u_id,a.xzsj,a.f_id,b.f_name,b.f_path,b.f_ext
from gdsjcj_xjbl_export a inner join jc_file b on a.f_id=b.f_id
/

