create PROCEDURE PRO_ZS_XXXX_TB_CJXT IS
/*CURSOR O_LIST IS
    SELECT A.*,B.APP_ID,
          (select f.org_id from jc_org_relat d left join jc_org f on f.org_id=d.org_id where A.org_id=d.org_id_child and f.org_dj='60' and rownum=1) JDID,
          (select f.org_mc from jc_org_relat d left join jc_org f on f.org_id=d.org_id where A.org_id=d.org_id_child and f.org_dj='60' and rownum=1) JDMC
    FROM JC_ORG A INNER JOIN JC_APP_ORG B ON B.ORG_ID=A.ORG_ID WHERE A.ORG_DJ='80' AND A.ORG_STATE='1'
    AND EXISTS(SELECT 1 FROM JC_APP C WHERE C.APP_ID=B.APP_ID AND C.APP_YXZT='1' AND C.PRO_ID='5BCEAE53683F580CE0530100007F50D9');
ORG O_LIST%ROWTYPE;*/
V_ISHAVE NUMBER;
V_ISUPDATE NUMBER;
V_ISDELETE NUMBER;
BEGIN
   --OPEN O_LIST;LOOP FETCH O_LIST INTO ORG; --循环机构游标
   --exit when O_LIST%NOTFOUND;
        --SELECT COUNT(ORG_ID) INTO V_ISHAVE FROM ZS_XXXX A WHERE NOT EXISTS(SELECT 1 FROM JC_APP_ORG B WHERE A.ORG_ID=B.ORG_ID AND A.APP_ID=B.APP_ID);--查询机构是否存在
       --需要同步的数据
       SELECT COUNT(A.ORG_ID) INTO V_ISHAVE FROM JC_ORG A INNER JOIN JC_APP_ORG B ON B.ORG_ID=A.ORG_ID
            WHERE A.ORG_DJ='80' AND A.ORG_STATE='1'
            AND EXISTS(SELECT 1 FROM JC_APP C WHERE C.APP_ID=B.APP_ID AND C.APP_YXZT='1' AND C.PRO_ID='5BCEAE53683F580CE0530100007F50D9')
            AND NOT EXISTS(SELECT 1 FROM ZS_XXXX D WHERE D.APP_ID=B.APP_ID AND D.ORG_ID=B.ORG_ID);
       --查询需要修改的数据
       SELECT COUNT(ORG_ID) INTO V_ISUPDATE FROM ZS_XXXX A
       WHERE EXISTS(SELECT 1 FROM JC_APP_ORG B WHERE A.ORG_ID=B.ORG_ID AND A.APP_ID=B.APP_ID)
       AND
       (NVL(A.jdid,'A')<>(select f.org_id from jc_org_relat d inner join jc_org f on f.org_id=d.org_id where f.org_state='1' and A.org_id=d.org_id_child and f.org_dj='60' and rownum=1)
        or
        NVL(A.jdmc,'A')<>(select f.org_mc from jc_org_relat d inner join jc_org f on f.org_id=d.org_id where f.org_state='1' and A.org_id=d.org_id_child and f.org_dj='60' and rownum=1)
       );
       --查询需要删除的数据
       SELECT COUNT(ORG_ID) INTO V_ISDELETE FROM ZS_XXXX A WHERE NOT EXISTS(SELECT 1 FROM JC_APP_ORG B INNER JOIN JC_ORG C ON C.ORG_ID=B.ORG_ID WHERE A.ORG_ID=B.ORG_ID AND A.APP_ID=B.APP_ID AND C.ORG_STATE='1');
       --查询机构是否存在
       IF(V_ISHAVE>0)THEN--新增
             INSERT INTO ZS_XXXX(ORG_ID,APP_ID, XZR, XZSJ,JDID,JDMC)
             SELECT A.ORG_ID,B.APP_ID,A.XZR,A.XZSJ,
                   (select f.org_id from jc_org_relat d left join jc_org f on f.org_id=d.org_id where A.org_id=d.org_id_child and f.org_dj='60' and rownum=1) JDID,
                   (select f.org_mc from jc_org_relat d left join jc_org f on f.org_id=d.org_id where A.org_id=d.org_id_child and f.org_dj='60' and rownum=1) JDMC
                    FROM JC_ORG A INNER JOIN JC_APP_ORG B ON B.ORG_ID=A.ORG_ID
                    WHERE A.ORG_DJ='80' AND A.ORG_STATE='1'
                    AND EXISTS(SELECT 1 FROM JC_APP C WHERE C.APP_ID=B.APP_ID AND C.APP_YXZT='1' AND C.PRO_ID='5BCEAE53683F580CE0530100007F50D9')
                    AND NOT EXISTS(SELECT 1 FROM ZS_XXXX D WHERE D.APP_ID=B.APP_ID AND D.ORG_ID=B.ORG_ID);
        END IF;
        IF(V_ISUPDATE>0) THEN--修改
             UPDATE ZS_XXXX JO SET (JDID,JDMC)=(select f.org_id,f.org_mc from jc_org_relat d inner join jc_org f on f.org_id=d.org_id where f.org_state='1' and JO.org_id=d.org_id_child and f.org_dj='60' and rownum=1)
             WHERE EXISTS(SELECT 1 FROM JC_APP_ORG B WHERE JO.ORG_ID=B.ORG_ID AND JO.APP_ID=B.APP_ID)
             AND
             (NVL(JO.jdid,'A')<>(select f.org_id from jc_org_relat d inner join jc_org f on f.org_id=d.org_id where f.org_state='1' and JO.org_id=d.org_id_child and f.org_dj='60' and rownum=1)
              or
              NVL(JO.jdmc,'A')<>(select f.org_mc from jc_org_relat d inner join jc_org f on f.org_id=d.org_id where f.org_state='1' and JO.org_id=d.org_id_child and f.org_dj='60' and rownum=1)
             );
        END IF;
        IF(V_ISDELETE>0) THEN--删除
             --删除不存在的当前应用的机构
             DELETE ZS_XXXX A WHERE NOT EXISTS(SELECT 1 FROM JC_APP_ORG B INNER JOIN JC_ORG C ON C.ORG_ID=B.ORG_ID WHERE A.ORG_ID=B.ORG_ID AND A.APP_ID=B.APP_ID AND C.ORG_STATE='1');
        END IF;
        commit;
   --END LOOP;
END PRO_ZS_XXXX_TB_CJXT;
/

