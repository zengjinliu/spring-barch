create view V_ZZXT_XM as
select
z.xmid,z.xmmc,z.zzlb,z.sqtj_czlb,z.sqtj_gzhj,z.je,FN_DATE_TOSTRFORMAT(z.start_time,'yyyy-MM-dd') "START_TIME",
FN_DATE_TOSTRFORMAT(z.end_time,'yyyy-MM-dd') "END_TIME",z.xmzt,z.zzdx,DJ.DJ_MC,
O.ORG_MC,
z.zjly,z.zzxmm,z.zjyt,z.xmms,z.xzsj,z.zztjms,z.xmlx,z.sfxqjy,z.sfcdjy,z.sfzdjy,z.sfgdjy,z.org_id,z.org_dj,z.xq_id,X.XQ_MC,

(CASE WHEN z.sfxqjy='1' THEN '幼儿 ' end  ||
 CASE WHEN z.sfcdjy='1' THEN '小学 ' end  ||
 CASE WHEN z.sfzdjy='1' THEN '初中 ' end  ||
 CASE WHEN z.sfgdjy='1' THEN '高中 '  end  ||
 CASE WHEN z.sftsjy='1' THEN '特殊教育'  end
)as xdmc
from zzxt_xm z
LEFT JOIN JC_XQ X ON X.Xq_Id = Z.Xq_Id
LEFT JOIN JC_ORG_DJ DJ ON DJ.DJ_LEVEL =Z.ORG_DJ
LEFT JOIN JC_ORG O ON O.org_id = z.org_id
/

