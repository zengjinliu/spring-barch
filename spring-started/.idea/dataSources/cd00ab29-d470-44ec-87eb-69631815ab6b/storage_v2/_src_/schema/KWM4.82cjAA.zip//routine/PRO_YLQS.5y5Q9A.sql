create PROCEDURE PRO_YLQS(p_dxqid in char,ylqr in varchar2,p_appid in char,p_sqxxids in varchar2,nums out varchar2) IS
  cursor c_list is select * from (select row_number()over(order by a.by1 asc,a.yhxqjf+0 desc,a.x_szhj2 asc,
         decode(a.hjlxm2,'1',floor(months_between(to_date(to_char(sysdate,'yyyy')||'-03-31','yyyy-MM-dd'),a.fcrq)),a.jysc) desc,
         a.fcrq asc) orderid,a.* from V_ZS_XSXX_YLQ a where
         exists(select 1 from zs_dxq dxq inner join zs_dxq_mx mx on mx.dxq_id=dxq.dxq_id
         where mx.org_id in(a.SQXXID1,a.SQXXID2,a.SQXXID3,a.SQXXID4,a.SQXXID5,a.SQXXID6,a.SQXXID7,a.SQXXID8,a.SQXXID9,a.SQXXID10) and dxq.dxq_yxzt='1' and dxq.dxq_id=p_dxqid)
         and app_id=p_appid -- and a.DXQID=p_dxqid 
         and sfcssj='0' and zjg='1' and shzt='2' and nvl(lqzt,'1')<>'2' and nvl(a.YLQZT,'1')<>'2'
         and a.LQXXID is null and a.YLQXXID is null) t1  order by t1.orderid asc;
  xs c_list%rowtype; --定义变量类型
  v_ybsql varchar2(500);
  --type array_contain is  varray(10) of char(32);--静态数组
  TYPE array_contain IS TABLE OF varchar2(32) INDEX BY BINARY_INTEGER;--可变数组
  v_array array_contain;
  v_sqxxid1 varchar2(32);
  v_sqxxid2 varchar2(32);
  v_sqxxid3 varchar2(32);
  v_sqxxid4 varchar2(32);
  v_sqxxid5 varchar2(32);
  v_sqxxid6 varchar2(32);
  v_sqxxid7 varchar2(32);
  v_sqxxid8 varchar2(32);
  v_sqxxid9 varchar2(32);
  v_sqxxid10 varchar2(32);
  v_xxid varchar2(32);
  v_quorgid varchar2(32);--区org_ID
  v_ylqs number;--已录取数
  v_jhs number;--学校计划数
  v_selxxid varchar2(32);--预录取查询学校id
  v_selxxmc varchar2(100);--预录取查询学校名称
  v_ylqxxid varchar2(32);--预录取学校id
  v_ylqxxmc varchar2(100);--预录取学校名称
  v_ylqzt varchar2(10);--预录取状态
  v_ylqztmc varchar2(10);--预录取状态名称
  v_lqfsx number;--录取最低分数线
  v_lqxwlb varchar2(100);----录取最低学位类别
  i number;
  str_sql varchar2(2000);
  cxxx_sql varchar2(2000);
  num number;
BEGIN
 --打开游标
  open c_list;
  loop fetch c_list into xs;
    exit when c_list%notfound;
      v_sqxxid1:=xs.sqxxid1;
      v_sqxxid2:=xs.sqxxid2;
      v_sqxxid3:=xs.sqxxid3;
      v_sqxxid4:=xs.sqxxid4;
      v_sqxxid5:=xs.sqxxid5;
      v_sqxxid6:=xs.sqxxid6;
      v_sqxxid7:=xs.sqxxid7;
      v_sqxxid8:=xs.sqxxid8;
      v_sqxxid9:=xs.sqxxid9;
      v_sqxxid10:=xs.sqxxid10;
      v_ylqxxid:='';
      v_ylqxxmc:='';
      v_ylqzt:='1';--预录取状态
      v_ylqztmc:='待录取';
    select org_id into v_quorgid from jc_org a where exists(select 1 from jc_org_relat b where b.org_id_child=xs.sqxxid1 and b.org_id=a.org_id) and exists(select 1 from jc_app_org c where c.org_id=a.org_id and c.app_id=xs.app_id) and a.org_dj='50';
     --可变数组
    if(xs.sqxxid1 is not null) then
        v_array(1):=v_sqxxid1;
    end if;
    if(xs.sqxxid2 is not null) then
        v_array(2):=v_sqxxid2;
    end if;
    if(xs.sqxxid3 is not null) then
        v_array(3):=v_sqxxid3;
    end if;
    if(xs.sqxxid4 is not null) then
        v_array(4):=v_sqxxid4;
    end if;
    if(xs.sqxxid5 is not null) then
        v_array(5):=v_sqxxid5;
    end if;
    if(xs.sqxxid6 is not null) then
        v_array(6):=v_sqxxid6;
    end if;
    if(xs.sqxxid7 is not null) then
        v_array(7):=v_sqxxid7;
    end if;
    if(xs.sqxxid8 is not null) then
        v_array(8):=v_sqxxid8;
    end if;
    if(xs.sqxxid9 is not null) then
        v_array(9):=v_sqxxid9;
    end if;
    if(xs.sqxxid10 is not null) then
        v_array(10):=v_sqxxid10;
    end if;
    i:=1;
    num:=v_array.COUNT;
    FOR i IN 1 .. v_array.COUNT LOOP
      v_ylqs:=0;
      v_jhs:=0;
      v_lqfsx:='';
      v_lqxwlb:='';
      --v_xxid:=v_sqxxidi;
      cxxx_sql:='select sqxxid'||i||' from V_ZS_XSXX_YLQ a where a.xsid='''||xs.xsid||'''';
      execute immediate cxxx_sql into v_xxid;
      str_sql:='select (select count(*) from V_ZS_XSXX_YLQ where (YLQXXID=a.sqxxid'||i||' or LQXXID=a.sqxxid'||i||') and (YLQZT=''2'' or LQZT=''2'') and APP_ID='''||xs.app_id||''') ylq,
                       (select yhxqjf from (select nvl(yhxqjf,0) yhxqjf from V_ZS_XSXX_YLQ c where (YLQXXID='''||v_xxid||''' or LQXXID='''||v_xxid||''') and (YLQZT=''2'' or LQZT=''2'') and APP_ID='''||xs.app_id||''' order by c.by1 desc,c.yhxqjf+0 asc,c.x_szhj2 desc,decode(c.hjlxm2,''1'',floor(months_between(to_date(to_char(sysdate,''yyyy'')||''-03-31'',''yyyy-MM-dd''),c.fcrq)),c.jysc) asc,c.fcrq desc) where rownum=1) lqfsx,
                       (select xwlb from (select xwlb from V_ZS_XSXX_YLQ c where (YLQXXID='''||v_xxid||''' or LQXXID='''||v_xxid||''') and (YLQZT=''2'' or LQZT=''2'') and APP_ID='''||xs.app_id||''' order by c.by1 desc,c.yhxqjf+0 asc,c.x_szhj2 desc,decode(c.hjlxm2,''1'',floor(months_between(to_date(to_char(sysdate,''yyyy'')||''-03-31'',''yyyy-MM-dd''),c.fcrq)),c.jysc) asc,c.fcrq desc) where rownum=1) lqxwlb,
                       (select nvl(jhs,0) from zs_xxxx where ORG_ID=a.sqxxid'||i||' and APP_ID='''||xs.app_id||''') jhs,
                       a.sqxxid'||i||',a.sqxxmc'||i||' from V_ZS_XSXX_YLQ a
               where a.xsid='''||xs.xsid||'''';
      execute immediate str_sql into v_ylqs,v_lqfsx,v_lqxwlb,v_jhs,v_selxxid,v_selxxmc;
      if(v_ylqs<v_jhs and ((v_array(i)='496FFFE16DE45558E053BC09A8C0A5ED' and i=1) or nvl(v_array(i),'A')<>'496FFFE16DE45558E053BC09A8C0A5ED'))then--录取数小于计划数
          v_ylqxxid:=v_selxxid;
          v_ylqxxmc:=v_selxxmc;
          v_ylqzt:='2';
          v_ylqztmc:='已录取';
          EXIT;
      elsif(nvl(xs.yhxqjf,0)=nvl(v_lqfsx,0) and xs.xwlb=v_lqxwlb and v_quorgid='5a23dbdd9b0e40979d0f88451e901efe') then--宝安同分录取（如果申请学校的最后一个录取分数等同于当前学生的分数 当前学生超过计划数也可被录取）
           v_ylqxxid:=v_selxxid;
           v_ylqxxmc:=v_selxxmc;
           v_ylqzt:='2';
           v_ylqztmc:='已录取';
           EXIT;
      end if;
    END LOOP;
    UPDATE ZS_XSXX a SET YLQZT=v_ylqzt,YLQ_ORGID=v_ylqxxid, YLQXX=v_ylqxxmc,YLQR=ylqr,YLQZTMC=v_ylqztmc,YLQSJ=FN_SYSDATE() WHERE a.XSID=xs.xsid;
    commit;
    select to_number(nvl(nums,0))+1 into nums from dual;
    v_array.DELETE;
  end loop;
  close c_list;
end PRO_YLQS;
/

