create view V_TC_HMXS_XSCX as
select
jx.xm,DECODE(jx.XBM,'1','男'，'2','女','') XB,jx.sfzjh,jx.xjh,jo.org_id,jo.org_mc,jx.xsid
from tc_xs jx
left join jc_org jo on jo.org_id = jx.org_id
/

