create procedure procedure_jzgndkhxx -- 创建存储过程 教职工年底考核信息
  as
  tbsj date;
  begin
  select max(time_bz) into tbsj from gz_sjjh.JS_TB_BIZ_JZGNDKHXX;
  delete from JC_JS_KH b where exists   (select 1 from  gz_sjjh.JS_TB_BIZ_JZGNDKHXX a where a.id=b.jskh_id and a.TIME_BZ> ( select c.updatetime from JC_DATA_TIME c  where c.model_type = 'JC_JS_KH'));
  insert into JC_JS_KH b (JSKH_ID,JS_ID,KHND,KHJG,KHDWMC,STATUS,XZR,XZSJ)
  select j.id,
      JB.JSJB_ID,
      j.Khnd,
      (select d1.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d1 where d1.zdbs='KHJL' and d1.zdxbs = j.KHJL)KHJL,
      j.Khdwmc,
      '1',
      'SJTB',
      sysdate
  from gz_sjjh.JS_TB_BIZ_JZGNDKHXX j
  join JC_JS_JB JB
  on j.JSID = JB.JSJB_ID
  where  j.SFSC = '0' and j.shzt='2' and j.TIME_BZ>(  select c.updatetime from JC_DATA_TIME c  where c.model_type = 'JC_JS_KH');
  update JC_DATA_TIME set updatetime = tbsj where model_type = 'JC_JS_KH';

   exception when others then
  dbms_output.put_line(sqlcode||'>>>>>>' || sqlerrm);
  commit;
end procedure_jzgndkhxx;
/

