create view V_ZS_SZ as
select a.SZ_ID,a.ORG_ID,a.PRO_ID,a.val,nvl(c.dmmx_mc,a.VAL) val_n,a.XZR,a.XZSJ,a.GXR,a.GXSJ,a.XH,
a.column_dm,a.group_mc,
b.column_name szmc
from zs_sz a
left join JC_COLUMN b on a.column_dm=b.column_dm
left join jc_dmmx c on c.dm_code=b.relat_table and c.dmmx_code=a.val
/

