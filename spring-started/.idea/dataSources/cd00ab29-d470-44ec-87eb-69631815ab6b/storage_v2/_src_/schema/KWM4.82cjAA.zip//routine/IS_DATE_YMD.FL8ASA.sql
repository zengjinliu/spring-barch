create function is_date_ymd(csrq varchar2) return number is
val date;
begin
  val := to_date(nvl(csrq,'n'),'yyyy-mm-dd');
  return 1;
  exception when others then return 0;
end;
/

