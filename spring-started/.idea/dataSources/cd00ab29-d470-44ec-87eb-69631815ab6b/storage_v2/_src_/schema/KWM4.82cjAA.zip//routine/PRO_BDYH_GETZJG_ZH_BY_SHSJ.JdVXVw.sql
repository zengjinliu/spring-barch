create PROCEDURE PRO_BDYH_GETZJG_ZH_BY_SHSJ(p_appid in varchar2,p_orgid in varchar2) IS
  cursor c_list is select distinct xsid from smbd_shjg a
         where a.shsj > (select max_time from  smbd_max_time_zh where app_id =p_appid and org_id = p_orgid )
         and exists (select 1 from smbd_bmsz b where b.iszjgpd = '1' and a.bmid = b.bmid and b.orgid = p_orgid )
         and exists(select 1 from zs_xsxx c where c.shzt='2' and c.xsid = a.xsid and c.app_id = p_appid )
         AND BMDM !='JSBM'
         and a.xsid not in ('286931ac912b4e8d9c3e2a6b93d98a91','2ee23b9a2ba44f77ac46e85acfa327c5','91b3b3d25dc6493cab5f2869aad45c1f','38a8a8fe43ab40b3af890696f3ac2d3d','65ce9f76ede24b75ace12dca28c69308','695bba0b8b0a49f88f9e3c8d8f346086','21b061ced8314f059df2821b692b6562','e980db8547f049d99226513023b0b456')
         ;
  xs c_list%rowtype;
  v_max_shsj date;
  v_xsid varchar(32);
  v_ishave varchar2(1);
BEGIN
  select max(shsj) into v_max_shsj from  v_smbd_shjg_ao where app_id = p_appid and org_id = p_orgid and iszjgpd = '1';
    open c_list;
    loop fetch c_list into xs;
      exit when c_list%notfound;
       v_ishave:='Y';
        v_xsid := xs.xsid;
        pro_bdyh_getzjg_zh_byxsid(v_xsid,'sys');
      end loop;
      close c_list;
      if(v_ishave='Y')then
      update smbd_max_time_zh set max_time = v_max_shsj where app_id = p_appid and org_id = p_orgid;
       commit;
       end if;
end PRO_BDYH_GETZJG_ZH_BY_SHSJ;
/

