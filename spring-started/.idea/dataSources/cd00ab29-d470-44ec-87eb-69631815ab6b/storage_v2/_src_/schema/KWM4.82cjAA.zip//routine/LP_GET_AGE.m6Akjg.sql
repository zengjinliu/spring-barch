create function LP_GET_AGE(v_bir date) return number is
begin
return floor(months_between(sysdate, v_bir)/ 12);
end;
/

