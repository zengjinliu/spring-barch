create PROCEDURE PRO_YLQS_test2(p_dxqid in char,p_sqxxids in varchar2,ylqr in varchar2,p_appid in char) IS
  TYPE c_list_type IS REF CURSOR; --定义一个动态游标
  c_list c_list_type;   --定义游标类型
  xs V_ZS_XSXX_YLQ%rowtype; --定义变量类型
  v_ybsql varchar(500);
  --type array_contain is  varray(10) of char(32);--静态数组
  TYPE array_contain IS TABLE OF char(32) INDEX BY BINARY_INTEGER;--可变数组
  v_array array_contain;
  v_sqxxid1 char(32);
  v_sqxxid2 char(32);
  v_sqxxid3 char(32);
  v_sqxxid4 char(32);
  v_sqxxid5 char(32);
  v_sqxxid6 char(32);
  v_sqxxid7 char(32);
  v_sqxxid8 char(32);
  v_ylqs number;--已录取数
  v_jhs number;--学校计划数
  v_selxxid char(32);--预录取查询学校id
  v_selxxmc varchar(100);--预录取查询学校名称
  v_ylqxxid char(32);--预录取学校id
  v_ylqxxmc varchar(100);--预录取学校名称
  i number;
  str_sql varchar(500);
  num number;
BEGIN
 --exists(select 1 from zs_dxq dxq inner join zs_dxq_mx mx on mx.dxq_id=dxq.dxq_id where a.SQXXID1=mx.org_id and dxq.dxq_yxzt='1' and dxq.dxq_id=p_dxqid)
 --打开游标
 v_ybsql:='select * from (select row_number()over(order by a.xwlb asc,a.xqjf+0 desc,a.x_szhj2 asc,
         decode(a.hjlxm2,''1'',floor(months_between(to_date(to_char(sysdate,''yyyy'')||''-03-31'',''yyyy-MM-dd''),a.fcrq)),a.jysc) desc,
         a.fcrq asc) orderid,a.* from V_ZS_XSXX_YLQ a where
         sqxxid in('||p_sqxxids||') and app_id='''||p_appid||''' and sfcssj=''0'' and shzt=''2'' and nvl(lqzt,''1'')<>''2''
         and a.lq_orgid is null) t1 order by t1.orderid asc';
  open c_list for v_ybsql;
  loop fetch c_list into xs;
    exit when c_list%notfound;
      v_sqxxid1:=xs.sqxxid1;
      v_sqxxid2:=xs.sqxxid2;
      v_sqxxid3:=xs.sqxxid3;
      v_sqxxid4:=xs.sqxxid4;
      v_sqxxid5:=xs.sqxxid5;
      v_sqxxid6:=xs.sqxxid6;
      v_sqxxid7:=xs.sqxxid7;
      v_sqxxid8:=xs.sqxxid8;
      v_ylqxxid:='';
     --可变数组
    if(xs.sqxxid1 is not null) then
        v_array(1):=v_sqxxid1;
    end if;
    if(xs.sqxxid2 is not null) then
        v_array(2):=v_sqxxid2;
    end if;
    if(xs.sqxxid3 is not null) then
        v_array(3):=v_sqxxid3;
    end if;
    if(xs.sqxxid4 is not null) then
        v_array(4):=v_sqxxid4;
    end if;
    if(xs.sqxxid5 is not null) then
        v_array(5):=v_sqxxid5;
    end if;
    if(xs.sqxxid6 is not null) then
        v_array(6):=v_sqxxid6;
    end if;
    if(xs.sqxxid7 is not null) then
        v_array(7):=v_sqxxid7;
    end if;
    if(xs.sqxxid8 is not null) then
        v_array(8):=v_sqxxid8;
    end if;
    i:=1;
    num:=v_array.COUNT;
    FOR i IN 1 .. v_array.COUNT LOOP
      v_ylqs:=0;
      v_jhs:=0;
      str_sql:='select (select count(*) from V_ZS_XSXX_YLQ where YLQ_ORGID=b.sqxxid'||i||' and YLQZT=''2'') ylq,
                       (select nvl(a.jhs,0) from zs_jhs where ORG_ID=b.sqxxid'||i||') jhs,
                       a.sqxxid'||i||',a.sqxxmc'||i||' from V_ZS_XSXX_YLQ a
               where a.xsid='''||xs.xsid||'''';
      execute immediate str_sql into v_ylqs,v_jhs,v_selxxid,v_selxxmc;
      if(v_ylqs<v_jhs and ((v_array(i)='496FFFE16DE45558E053BC09A8C0A5ED' and i=1) or nvl(v_array(i),'A')<>'496FFFE16DE45558E053BC09A8C0A5ED'))then--录取数小于计划数
          v_ylqxxid:=v_selxxid;
          v_ylqxxmc:=v_selxxmc;
           EXIT;
      end if;
    END LOOP;
    UPDATE ZS_XSXX a SET YLQZT='2',YLQ_ORGID=v_ylqxxid, YLQXX=v_ylqxxmc,YLQR=ylqr,YLQZTMC='已录取',YLQSJ=FN_SYSDATE() WHERE a.XSID=xs.xsid;
    commit;
    v_array.DELETE;
  end loop;
  close c_list;
end PRO_YLQS;
/

