create view V_JC_XS_ZJ_SQ as
select
JO.ORG_ID,xs.xsid,xs.xm,xs.xbm,xs.hjlx,xs.xxid,xs.njid,xs.bjid,xs.xjfh,xs.sfzjh,j.czrhj,j.zjlx,
FN_DATE_TOSTRFORMAT(J.ZJYXQ,'yyyy-MM-dd') ZJYXQ,j.bfsj,j.shzt,N.NJMC,X.XXMC,BJ.BJMC,j.zjid,j.state,T3.DMMX_MC CZRHJMC,T4.DMMX_MC ZJLXMC,
FN_DATE_TOSTRFORMAT(J.XZSJ,'yyyy-MM-dd') XZSJ,J.XZSJ as zjxzsj
from
jc_xs xs
join jc_xs_zj j on xs.xsid =j.xsid
LEFT JOIN JC_ORG JO ON xs.XXID = JO.ORG_ID
left join jc_xx X on xs.XXID=X.ORG_ID
left join jc_grade N on xs.NJID=N.NJID
left join jc_class BJ on xs.BJID=BJ.BJID
LEFT JOIN JC_DMMX T3 ON  j.czrhj= T3.DMMX_CODE AND T3.DM_CODE = 'DM_HJ'
LEFT JOIN JC_DMMX T4 ON  j.ZJLX= T4.DMMX_CODE AND T4.DM_CODE = 'DM_CZLX'
WHERE j.State='1'
/

