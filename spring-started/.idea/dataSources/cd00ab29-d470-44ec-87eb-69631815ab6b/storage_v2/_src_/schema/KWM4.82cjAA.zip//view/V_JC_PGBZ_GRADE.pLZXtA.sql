create view V_JC_PGBZ_GRADE as
select
jpg.gid,jpg.gmc,jpg.xzr,jpg.xzsj,jpg.gxr,jpg.gxsj,jpg.appid,jpg.orgid,jpg.ywlx,jpg.remark,
case when exists(select 1 from jc_pgbz s where s.gid=jpg.gid and s.yxzt = '1' ) then '1' else '0' end isuse
from
JC_PGBZ_GRADE JPG
/

