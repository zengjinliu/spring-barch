create view V_ZS_ZXTB_LD as
select
    Z.LDID,Z.ORG_ID,J.ORG_DM,J.ORG_MC,Z.YXZT,Z.LDDZ,Z.LDMC,Z.BZ,(Z.LDDZ||'('||Z.LDMC||')') AS LDDZLDMC
    from ZS_ZXTB_LD Z
    left join JC_ORG J on Z.ORG_ID=J.ORG_ID
    where Z.YXZT='1'
/

