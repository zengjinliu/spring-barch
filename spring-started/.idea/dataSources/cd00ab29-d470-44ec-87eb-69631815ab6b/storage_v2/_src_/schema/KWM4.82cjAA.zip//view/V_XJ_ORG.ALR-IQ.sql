create view V_XJ_ORG as
select
a.xxid,a.xxcode,a.xxname,
case when b.xxname is null then '深圳市市直属' else b.xxname end qumc
from emis.a_school a
left join emis.a_school b on b.xxcode=substr(a.xxcode,0,6)
where length(a.xxcode)=12 and nvl(a.used,'Y')<>'N' and a.xxcode like '4402%'
and a.XXNAME not like '%区属%' and a.xxname not in ('学校名称','南方（拍照）','茂名','其他'
,'外地学校','临时学校1','测试','平湖街道暂存点','横岗街道暂存点','龙岗街道暂存点','坪地街道暂存点',
'葵涌街道暂存点','大鹏街道暂存点','南澳街道暂存点','龙城街道暂存点','坂田街道暂存点','南湾街道暂存点',
'市内非龙岗区小学','非深圳市内小学（市外）','非深圳市省内小学','省外小学','外地学校','市内非大鹏新区小学','非深圳市内小学（市外）')
order by a.xxcode
/

