create PROCEDURE PRO_XQFDQJS(p_appid in char,p_orgid in varchar2,czr in varchar2) IS --学区房到期解锁
BEGIN
     update zs_xqf_lock a set a.status='2',a.statusmc='已解锁',a.gxr=czr,a.gxsj=sysdate,a.bz='已到解锁时间,房屋解锁'
     where to_char(unlocktime,'yyyy')=to_char(sysdate,'yyyy');
    commit;
end PRO_XQFDQJS;
/

