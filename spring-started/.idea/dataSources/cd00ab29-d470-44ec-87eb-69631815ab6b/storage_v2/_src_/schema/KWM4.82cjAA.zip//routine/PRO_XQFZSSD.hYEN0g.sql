create PROCEDURE PRO_XQFZSSD(p_appid in char,p_orgid in varchar2,czr in varchar2,nums out varchar2) IS--学区房正式锁定
BEGIN
    if(p_orgid='b3c2fbca21a24a8e88d493fe3f5c781a' or p_orgid='cfccea51695f4b739a2c341fcf01d15f') then--龙华(2018)、龙岗(20190325)：只要录取到公办的，全锁定；
     --3、龙华(2018)、龙岗(20190325)：只要录取到公办的，全锁定；
     insert into zs_xqflock_zssd  
     select LOCK_ID,FWID,CQR,CQRSFZH,XM,LOCKTIME,SFZJH,XSID,UNLOCKTIME,STATUS,XZR,XZSJ,GXR,GXSJ,XXID,XXMC,BZ,'正式锁定' sdbz from zs_xqf_lock c 
     where exists(select 1 from v_zs_xsxx v 
             where v.DRXJZT='1' and c.xsid=v.xsid and c.fwid=v.fwid and c.lock_id=v.LOCKID 
             and exists(select 1 from zs_xxxx d where d.org_id=v.lqxxid and d.gmb='1')
             and v.APP_ID=p_appid
             and exists (select 1 from jc_org_relat e where e.org_id=p_orgid and e.org_id_child=v.SQXXID1)
             )
             and c.status='0'
           and not exists (select 1 from zs_xqflock_zssd x where x.lock_id=c.lock_id);
     commit;
   elsif(p_orgid='b8f9aa1578734cf0ba3b75bedd0c9743') then--4、南山根据申请学校锁定(分流都锁定) E3类不锁
     insert into zs_xqflock_zssd
     select LOCK_ID,FWID,CQR,CQRSFZH,XM,LOCKTIME,SFZJH,XSID,UNLOCKTIME,STATUS,XZR,XZSJ,GXR,GXSJ,XXID,XXMC,BZ,'正式锁定' sdbz from zs_xqf_lock c 
     where exists(select 1 from v_zs_xsxx v 
             where v.DRXJZT='1' and c.xsid=v.xsid and c.fwid=v.fwid and c.lock_id=v.LOCKID 
             and exists(select 1 from zs_xxxx d where d.org_id=v.LQXXID and d.gmb='1')
             and exists(select 1 from zs_xqf_hf d where d.org_id=v.sqxxid1 and d.fwid=v.FWID)
             and v.APP_ID=p_appid 
             and exists(select 1 from jc_org_relat f where f.org_id=p_orgid and f.org_id_child=v.sqxxid1)
             and nvl(xwlb,'00')!='E3'
             )
             and c.status='0'
             and not exists(select 1 from zs_xqflock_zssd e where e.lock_id=c.lock_id);      
   else
     --1、家长所选的房子在录取学校有划分的锁定，否则解锁；
    insert into zs_xqflock_zssd  
    select LOCK_ID,FWID,CQR,CQRSFZH,XM,LOCKTIME,SFZJH,XSID,UNLOCKTIME,STATUS,XZR,XZSJ,GXR,GXSJ,XXID,XXMC,BZ,'正式锁定' sdbz from zs_xqf_lock c 
    where exists(select 1 from v_zs_xsxx v 
             where v.DRXJZT='1' and c.xsid=v.xsid and c.fwid=v.fwid and c.lock_id=v.LOCKID 
             and exists(select 1 from zs_xxxx d where d.org_id=v.lqxxid and d.gmb='1')
             and exists(select 1 from zs_xqf_hf e where e.org_id=v.lqxxid and e.fwid=v.FWID)
             and v.APP_ID=p_appid 
             and exists(select 1 from jc_org_relat f where f.org_id=p_orgid and f.org_id_child=v.LQXXID)
             )
          and not exists (select 1 from zs_xqflock_zssd x where x.lock_id=c.lock_id);
     commit;
   end if;
   --2、申请学校和录取学校是共享的，房子在申请学校或者录取学校有划分的锁定，否则解锁 
    insert into zs_xqflock_zssd  
    select LOCK_ID,FWID,CQR,CQRSFZH,XM,LOCKTIME,SFZJH,XSID,UNLOCKTIME,STATUS,XZR,XZSJ,GXR,GXSJ,XXID,XXMC,BZ,'正式锁定' sdbz from zs_xqf_lock c 
    where exists(select 1 from v_zs_xsxx v 
             where v.DRXJZT='1' and c.xsid=v.xsid and c.fwid=v.fwid and c.lock_id=v.LOCKID 
             and exists(select 1 from zs_xxxx d where d.org_id=v.lqxxid and d.gmb='1')
             and exists(select 1 from zs_xqf_hf d 
                 where                  
                 d.org_id in(v.sqxxid1,v.sqxxid2,v.sqxxid3,v.sqxxid4,v.sqxxid5,v.sqxxid6,v.sqxxid7,v.SQXXID8,v.SQXXID9,v.SQXXID10) 
                  and v.lqxxid in(v.sqxxid1,v.sqxxid2,v.sqxxid3,v.sqxxid4,v.sqxxid5,v.sqxxid6,v.sqxxid7,v.SQXXID8,v.SQXXID9,v.SQXXID10)
                 and d.fwid=v.FWID)
             and ((exists(select 1 from zs_dxq_mx g where g.org_id=v.SQXXID1)))
             and v.APP_ID=p_appid 
             and exists(select 1 from jc_org_relat f where f.org_id=p_orgid and f.org_id_child=v.SQXXID1)
             )
             and c.status='0'
             and not exists (select 1 from zs_xqflock_zssd x where x.lock_id=c.lock_id);
     commit;
     insert into zs_xqflock_zssd  
     select LOCK_ID,FWID,CQR,CQRSFZH,XM,LOCKTIME,SFZJH,XSID,UNLOCKTIME,STATUS,XZR,XZSJ,GXR,GXSJ,XXID,XXMC,BZ,'正式锁定' sdbz from zs_xqf_lock c 
     where exists(select 1 from v_zs_xsxx v 
             where v.DRXJZT='1' and c.xsid=v.xsid and c.fwid=v.fwid and c.lock_id=v.LOCKID 
             and exists(select 1 from zs_xxxx d where d.org_id=v.lqxxid and d.gmb='1')
             and exists(select 1 from zs_xqf_hf d 
                 where                  
                 d.org_id in(v.sqxxid1,v.sqxxid2,v.sqxxid3,v.sqxxid4,v.sqxxid5,v.sqxxid6,v.sqxxid7,v.SQXXID8,v.SQXXID9,v.SQXXID10) 
                  and v.lqxxid in(v.sqxxid1,v.sqxxid2,v.sqxxid3,v.sqxxid4,v.sqxxid5,v.sqxxid6,v.sqxxid7,v.SQXXID8,v.SQXXID9,v.SQXXID10)
                 and d.fwid=v.FWID)
             and exists(select 1 from zs_fxxq f where f.org_id=v.SQXXID1)
             and v.APP_ID=p_appid 
             and exists(select 1 from jc_org_relat f where f.org_id=p_orgid and f.org_id_child=v.SQXXID1)
             )
             and c.status='0'
             and not exists (select 1 from zs_xqflock_zssd x where x.lock_id=c.lock_id);
      commit;
   --解锁数据备份
   insert into zs_xqflock_js 
   select LOCK_ID,FWID,CQR,CQRSFZH,XM,LOCKTIME,SFZJH,XSID,UNLOCKTIME,STATUS,XZR,XZSJ,GXR,GXSJ,XXID,XXMC,BZ,'解锁' sdbz 
   from zs_xqf_lock c 
   where not exists(select 1 from zs_xqflock_zssd b where c.lock_id=b.lock_id)
   and exists(select 1 from v_zs_xsxx v where c.xsid=v.xsid and c.fwid=v.fwid and c.lock_id=v.LOCKID 
              and v.APP_ID=p_appid and exists(select 1 from jc_org_relat f where f.org_id=p_orgid and f.org_id_child=v.SQXXID1)
             )
   and c.status='0'
   and not exists(select 1 from zs_xqflock_js d where d.lock_id=c.lock_id);
   commit;
   ---正式锁定
   update zs_xqf_lock a set a.status='1',a.statusmc='正式锁定',a.bz='导入学籍，正式锁定',a.gxr=czr,a.gxsj=sysdate 
            where exists(select 1 from zs_xqflock_zssd b where a.lock_id=b.lock_id)
                  and exists(select 1 from v_zs_xsxx v where a.xsid=v.xsid and a.fwid=v.fwid and a.lock_id=v.LOCKID 
                   and v.APP_ID=p_appid and exists(select 1 from jc_org_relat f where f.org_id=p_orgid and f.org_id_child=v.SQXXID1)
             )and a.status='0';
   commit;
   --解锁(初步锁定)
   update zs_xqf_lock a set a.status='2',a.statusmc='已解锁',a.gxr=czr,a.gxsj=sysdate,a.bz='初步锁定解锁' 
   where exists(select 1 from zs_xqflock_js b where a.lock_id=b.lock_id)
         and exists(select 1 from v_zs_xsxx v where a.xsid=v.xsid and a.fwid=v.fwid and a.lock_id=v.LOCKID 
              and v.APP_ID=p_appid and exists(select 1 from jc_org_relat f where f.org_id=p_orgid and f.org_id_child=v.SQXXID1)
             ) and a.status='0';
   commit;
    select to_number(nvl(nums,0))+1 into nums from dual;
end PRO_XQFZSSD;
/

