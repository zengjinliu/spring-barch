create PROCEDURE PRO_JC_WJDC_TJ authid current_user IS
BEGIN
    execute immediate 'truncate table jc_wjdc_mb_djtj';
    execute immediate 'drop table jc_wjdc_mb_djtj';
    execute immediate 'create table jc_wjdc_mb_djtj as select a.wj_id,b.wj_title,d.org_id,d.org_dm,d.org_mc,count(*) cnt from jc_wjdc_dj a left join jc_wjdc b on b.wj_id=a.wj_id left join jc_wjdc_mb c on c.wj_id=a.wj_id and c.wo_id=a.wo_id left join jc_org d on d.org_id=c.org_id where b.wj_yxzt=''1'' group by a.wj_id,b.wj_title,d.org_id,d.org_dm,d.org_mc';

    execute immediate 'truncate table jc_wjdc_mb_yz_djtj';
    execute immediate 'drop table jc_wjdc_mb_yz_djtj';
    execute immediate 'create table jc_wjdc_mb_yz_djtj as select a.wj_id,b.wj_title,d.org_dm,d.org_mc,e.xxmc,count(*) cnt from jc_wjdc_dj a left join jc_wjdc b on b.wj_id=a.wj_id left join jc_wjdc_mb c on c.wj_id=a.wj_id and c.wo_id=a.wo_id left join jc_org d on d.org_id=c.org_id left join jc_wjdc_yzxx2 e on e.wj_id=a.wj_id and e.yzxx=a.yzxx where b.wj_yxzt=''1'' group by a.wj_id,b.wj_title,d.org_dm,d.org_mc,e.xxmc';
END PRO_JC_WJDC_TJ;
/

