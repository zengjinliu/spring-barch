create view V_JK_JKXX as
select
  T.JKID,T.JKDM,T.JKMC,T.JKLX,D.DMMX_MC JKLXMC,T.JKBZ,T.JKXX,T.XZR,T.XZSJ,T.GXR,T.GXSJ,T.JKZT,T.SYZT,
  case T.SYZT when '1' then '启用' when '2' then '维护' when '3' then '弃用' end SYZTMC
from JK_JKXX T LEFT JOIN JC_DMMX D ON T.JKLX=D.DMMX_CODE WHERE D.DM_CODE ='DM_JKLX' AND T.JKZT='1'
/

