create view V_XQF_FW as
select a.FWID,a.FWBM,a.FWDZ,a.JDID,a.LDID,a.ORG_ID,a.YXZT,a.XZR,a.XZSJ,a.GXR,a.GXSJ,
A.JDMC,A.LDMC,A.LDMC2,a.BZ,A.LDDM
from xqf_fw a
where a.yxzt='1'
/

