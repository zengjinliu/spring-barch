create procedure procedure_jsdyxx -- 创建存储过程 待遇信息
  as
  tbsj date;
  begin
  select max(time_bz) into tbsj from gz_sjjh.JS_TB_BIZ_JZGJBDYXX;
  delete from JC_JS_DY b where exists   (select 1 from  gz_sjjh.JS_TB_BIZ_JZGJBDYXX a where a.id=b.jsdy_id and a.TIME_BZ> ( select c.updatetime from JC_DATA_TIME c  where c.model_type = 'JC_JS_DY'));
  insert into JC_JS_DY b (JSDY_ID,JS_ID,DYND,NDGZ,YDJBGZ,YDJXGZ,YDQTBT,YDTJBT,STATUS,XZR,XZSJ)
  select j.id,
      JB.JSJB_ID,
      j.ND DYND,
      j.NGZSR NDGZ,
      j.JBGZ YDJBGZ,
      j.JXGZ YDJXGZ,
      j.JTBT YDQTBT,
      j.TJJTBT YDTJBT,
      '1',
      'SJTB',
      sysdate
  from gz_sjjh.JS_TB_BIZ_JZGJBDYXX j
  join JC_JS_JB JB
  on j.JSID = JB.JSJB_ID
  where  j.SFSC = '0' and j.shzt='2' and j.TIME_BZ>(  select c.updatetime from JC_DATA_TIME c  where c.model_type = 'JC_JS_DY');
  update JC_DATA_TIME set updatetime = tbsj where model_type = 'JC_JS_DY';

   exception when others then
  dbms_output.put_line(sqlcode||'>>>>>>' || sqlerrm);
  commit;
end procedure_jsdyxx;
/

