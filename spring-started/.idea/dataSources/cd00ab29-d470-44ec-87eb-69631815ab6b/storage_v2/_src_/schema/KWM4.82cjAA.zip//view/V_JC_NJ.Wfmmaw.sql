create view V_JC_NJ as
SELECT b.NJID,b.njmc,b.rxnf,b.njjzxm,
a.orgid org_id,c.org_mc,a.jyjd,d.dmmx_mc jyjd_n,a.xjnjdm,e.dmmx_mc xjnjdm_n,c.org_orderid org_orderid,
c.org_dm,a.xz,c.org_mc||'('||b.njmc||')' njmc_n,a.xx_org_id xxorg_id,f.org_dm xxorg_dm,f.org_mc xxorg_mc,
f.org_orderid xxorg_orderid
FROM JC_NJ b
inner join jc_org_nj a on b.orgid=a.orgid
inner join jc_org c on c.org_id=a.orgid and c.org_state='1'
left join jc_org f on f.ORG_ID=a.xx_org_id and f.org_state='1'
left join jc_dmmx d on d.dm_code='DM_BXCC' and a.jyjd=d.dmmx_code and d.dmmx_state='1'
left join jc_dmmx e on e.dm_code='DM_NJDM' and a.xjnjdm=e.dmmx_code and e.dmmx_state='1'
WHERE b.NJZT='1'
/

