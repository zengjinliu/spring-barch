create view V_ORG_XX as
SELECT
o.ORG_ID,
o.ORG_DM xxdm,
o.ORG_DM,
o.ORG_MC,
o.ORG_MC xxmc,
o.ORG_ORDERID,
o.ORG_DJ,
o.ORG_STATE,
o.ORG_STATE AS STATE,
o.XZR,
o.XZSJ,
o.GXR,
o.GXSJ,
d.org_id as XXID,
o.ORG_ID as ORGID,
d.XXDM XXDM2,
d.XXMC XXMC2,
d.XXYWMC,
d.XXDZ,
d.XXYZBM,
d.XZQHM,
d.JXNY,
d.XQR,
d.XXBXLXM,
d.XXJBZM,
d.XXZGBMM,
d.FDDBRH,
d.FRZSH,
d.XZGH,
d.XZXM,
d.DWFZRH,
d.ZZJGM,
d.LXDH,
d.CZDH,
d.DZXX,
d.ZYDZ,
d.LSYG,
d.ORDERID,
d.XZQH,
d.XXLXM,
d.BE,
d.XD,
d.ZSLBM,
E1.DMMX_MC    AS XXLXM_MC
FROM
JC_ORG o
left JOIN JC_XX d ON o.ORG_ID = d.org_id
left join JC_DMMX E1    ON d.XXLXM = E1.DMMX_CODE   and E1.DM_CODE = 'DM_XX_XXLXM' and e1.dmmx_state='1'
WHERE
o.ORG_STATE = 1 and o.ORG_DJ=(select nvl(z.CON_VALUE,'80') from jc_const z where z.CON_KEY='JC_XXDJDM')
/

