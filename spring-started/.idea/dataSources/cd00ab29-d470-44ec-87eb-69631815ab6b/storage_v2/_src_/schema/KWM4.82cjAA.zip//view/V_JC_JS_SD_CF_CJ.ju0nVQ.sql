create view V_JC_JS_SD_CF_CJ as
SELECT zs.jssd_id as zsid,t1.op_id,t1.jssd_id,t1.js_id,t1.xzr,t1.xzsj,t1.gxr,t1.gxsj,t1.status,t1."CFLB",t1."CFYY",to_char(t1.CFFSRQ,'YYYY-MM-DD')as CFFSRQ,t1."CFJL",t1."CFDW",to_char(t1.CFRQ,'YYYY-MM-DD')as CFRQ,to_char(t1.CFCXRQ,'YYYY-MM-DD')as CFCXRQ,t1."CFCXYY",t2.dmmx_mc dmmx_CFLB_mc
FROM JC_JS_SD_CF_CJ T1
LEFT JOIN jc_js_sd_cf zs ON T1.JSSD_ID = zs.jssd_id
LEFT JOIN JC_DMMX T2 ON T1.CFLB = T2.DMMX_CODE AND T2.DM_CODE = 'DM_CFLB'
/

