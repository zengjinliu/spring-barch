create view V_DZ_POINT as
SELECT
p.pid,
p.xh,
p.content,
p.parentid,
p.rootid,
p.zbfz,
p.expression,
p.plevel,
p.type,
dmmx.dmmx_mc as typemc,
p.status,
p.xzr,
p.xzsj,
p.gxr,
p.gxsj,
p.org_id,
o.org_mc,
p.app_id,
p.pfxz

 FROM dz_point p
 left join jc_org o on o.org_id=p.org_id
 left join jc_dmmx dmmx on dmmx.dm_code='DM_GCDLBM' and p.type=dmmx.dmmx_code and dmmx.dmmx_state='1'
 left join JC_DMTAB dmt on dmt.dm_code='DM_GCDLBM' and  dmt.dm_state='1'
 where p.status!='0'
/

