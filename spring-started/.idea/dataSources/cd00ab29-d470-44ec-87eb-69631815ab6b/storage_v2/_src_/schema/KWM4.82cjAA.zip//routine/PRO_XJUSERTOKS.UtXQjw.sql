create PROCEDURE PRO_XJUSERTOKS IS --学籍用户同步至考试系统
BEGIN
  --更新帐号
  insert into jc_user(u_id,u_userid,u_pwd,u_mmxg_flag,xzr,org_id,u_username,xm,sfzjh,u_orderid,jk_uuid)
  select
  fn_uuid(),'ks_'||seq_jc_user_userid.nextval,fn_md5('a1234567'),'Y','ks_sys','0bdbf3382c574d9190f39b7b3e2b8d79',c.xxname,
  a.name,a.sfzh,1,fn_md5(a.sfzh)
  from
  emis.s_user_sgz a
  inner join emis.a_school c on c.xxcode=a.xxcode
  where not exists (select 1 from jc_user b where b.jk_uuid=a.jmsfzh);
  commit;

  --自动将新增的帐号分配到考试设置去
  insert into ks_sj_user(su_id,sj_id,u_id,xzr,xzsj)
  select fn_uuid(),'906201f3792b48e8a89bfb23d19dcfd3',t.u_id,'ks_sys',sysdate
  from JC_USER t
  where t.org_id='0bdbf3382c574d9190f39b7b3e2b8d79' and not exists (select 1 from ks_sj_user x where x.u_id=t.u_id);
  commit;

  --更新姓名
  update jc_user a
  set a.xm=(select b.name from emis.s_user_sgz b where b.jmsfzh=a.jk_uuid)
  where
  exists (select 1 from emis.s_user_sgz b where b.jmsfzh=a.jk_uuid and nvl(a.xm,'A')<>nvl(b.name,'A'));
  commit;

  update ks_xxsc a
  set a.xm=(select b.name from emis.s_user_sgz b where b.jmsfzh=(select c.jk_uuid from jc_user c where c.u_id=a.u_id))
  where
  exists (select 1 from emis.s_user_sgz b where b.jmsfzh=(select c.jk_uuid from jc_user c where c.u_id=a.u_id)
  and nvl(a.xm,'A')<>nvl(b.name,'A')
  and a.xm is not null
  );
  commit;

  --更新成绩
  update emis.s_user_sgz x
  set (x.sgz,x.kscj,x.kssj)=
  (
  select
  case when a.df>=c.sj_jgf then 'Y' else 'N' end,
  a.df,
  a.kssj
  from ks_sj_user a
  inner join jc_user b on b.u_id=a.u_id
  inner join ks_sj c on c.sj_id=a.sj_id
  where c.sj_zt='1' and a.sj_id='906201f3792b48e8a89bfb23d19dcfd3'
  and b.jk_uuid=x.jmsfzh
  )
  where nvl(x.sgz,'N')<>'Y';
  commit;

  --更新是否申请继续教育学分
  update emis.s_user_sgz x
  set x.sqjxjyxf=(
  select
  decode(a.sqjxjyxf,'1','Y','N')
  from ks_xxsc a
  inner join jc_user b on b.u_id=a.u_id
  where b.jk_uuid=x.jmsfzh
  )
  where nvl(x.sqjxjyxf,'N')<>'Y';
  commit;
end PRO_XJUSERTOKS;
/

