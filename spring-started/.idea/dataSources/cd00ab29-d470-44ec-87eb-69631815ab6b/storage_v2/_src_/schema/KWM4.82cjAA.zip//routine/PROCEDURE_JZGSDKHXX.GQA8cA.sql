create procedure procedure_jzgsdkhxx -- 创建存储过程 教职工师德考核信息
  as
  tbsj date;
  begin
  select max(time_bz) into tbsj from gz_sjjh.JS_TB_BIZ_JZGSDKHXX;
  delete from JC_JS_SD_KH b where exists   (select 1 from  gz_sjjh.JS_TB_BIZ_JZGSDKHXX a where a.id=b.jssd_id and a.TIME_BZ> ( select c.updatetime from JC_DATA_TIME c  where c.model_type = 'JC_JS_SD_KH'));
  insert into JC_JS_SD_KH b (jssd_id,JS_ID,SDKHSJ,SDKHJL,SDKHDW,STATUS,XZR,XZSJ)
  select j.id,
      JB.JSJB_ID,
      case is_date_ymd(j.Sdkhny) when 1 then  to_date(j.Sdkhny, 'yyyy-mm-dd hh24:mi:ss') else null end,
      (select d1.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d1 where d1.zdbs='SDKHJL' and d1.zdxbs = j.SDKHJL)SDKHJL,
      j.Sdkhdwmc,
      '1',
      'SJTB',
      sysdate
  from gz_sjjh.JS_TB_BIZ_JZGSDKHXX j
  join JC_JS_JB JB
  on j.JSID = JB.JSJB_ID
  where  j.SFSC = '0' and j.shzt='2' and j.TIME_BZ>(  select c.updatetime from JC_DATA_TIME c  where c.model_type = 'JC_JS_SD_KH');
  update JC_DATA_TIME set updatetime = tbsj where model_type = 'JC_JS_SD_KH';

   exception when others then
  dbms_output.put_line(sqlcode||'>>>>>>' || sqlerrm);
  commit;
end procedure_jzgsdkhxx;
/

