create view V_ZPMS_YPXX as
select jo.pydw_ID as ORG_ID ,
case jo.sfbs
when '0'
then trunc(nvl(jo.mscj,0))
else trunc(nvl(jo.bscj,0)*0.3)+trunc(nvl(jo.mscj,0)*0.7)  end as zf,
jo."BKXX_ID",jo."KS_ID",jo."ZPJH_ID",jo."PYDW_ID",jo."PYDWMC",jo."BKZW",jo."ZWDM",jo."SFBS",jo."XCZGHCJG",jo."XCZGHCZG",jo."ZKZH",jo."BSKM",jo."BSCJ",jo."BSPM",jo."BSBZ",jo."MSCJ",jo."MSBZ",jo."XZR",jo."XZSJ",jo."GXR",jo."GXSJ",jo."STATUS",jo."KCDM",jo."KQDM",jo."KQMC",jo."KSBH",jo."ZWH",jo."KSSJ",jo."BKZWMC",jo."DX_XCZGSH",jo."DX_MSAP",jo."TJZG",jo."TJJG" from ZPMS_YPXX jo
/

