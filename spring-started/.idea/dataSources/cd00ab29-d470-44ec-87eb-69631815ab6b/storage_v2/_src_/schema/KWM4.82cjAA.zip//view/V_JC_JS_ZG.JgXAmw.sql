create view V_JC_JS_ZG as
SELECT t1.jszg_id,t1.js_id,t1.xzr,t1.xzsj,t1.gxr,t1.gxsj,t1.status,t1."ZGZZL",t1."ZGZHM",t1."RJXK",to_char(t1.BZRQ,'YYYY-MM-DD')as BZRQ,t1."BZJG",t2.dmmx_mc dmmx_ZGZZL_mc FROM JC_JS_ZG T1
LEFT JOIN JC_DMMX T2 ON T1.ZGZZL = T2.DMMX_CODE AND T2.DM_CODE = 'DM_JSZGZZL'
/

