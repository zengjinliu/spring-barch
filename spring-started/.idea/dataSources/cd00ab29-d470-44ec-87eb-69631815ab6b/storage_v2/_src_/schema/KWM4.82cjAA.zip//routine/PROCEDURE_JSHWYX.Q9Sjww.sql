create procedure procedure_jshwyx -- 创建存储过程 海外研修
  as
   tbsj date;
  begin
  select max(time_bz) into tbsj from gz_sjjh.JS_TB_BIZ_JZGHWYXXX;
  delete from JC_JS_YX b where exists   (select 1 from  gz_sjjh.JS_TB_BIZ_JZGHWYXXX a where a.id=b.jsyx_id and a.TIME_BZ> ( select c.updatetime from JC_DATA_TIME c  where c.model_type = 'JC_JS_YX'));
  insert into JC_JS_YX b (JSYX_ID,JS_ID,YXKSRQ,YXJSRQ,YXGJ,YXJGMC,YXXMMC,YXXMDW,STATUS,XZR,XZSJ)
  select j.id,
       JB.JSJB_ID,
       case is_date_ymd(j.KSRQ) when 1 then  to_date(j.KSRQ, 'yyyy-mm-dd hh24:mi:ss') else null end,
       case is_date_ymd(j.JSRQ) when 1 then  to_date(j.JSRQ, 'yyyy-mm-dd hh24:mi:ss') else null end,
      (select d1.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d1 where d1.zdbs='GJDQ' and d1.zdxbs = j.GJDQ) YXGJ,
      j.PXJGMC YXJGMC,
      j.PXXMMC YXXMMC,
      j.PCDWMC YXXMDW,
      '1',
      'SJTB',
      sysdate
  from gz_sjjh.JS_TB_BIZ_JZGHWYXXX j
  join JC_JS_JB JB
  on j.JSID = JB.JSJB_ID
  where  j.SFSC = '0' and j.shzt='2' and j.TIME_BZ>(  select c.updatetime from JC_DATA_TIME c  where c.model_type = 'JC_JS_YX');
  update JC_DATA_TIME set updatetime = tbsj where model_type = 'JC_JS_YX';

   exception when others then
  dbms_output.put_line(sqlcode||'>>>>>>' || sqlerrm);
  commit;
end procedure_jshwyx;
/

