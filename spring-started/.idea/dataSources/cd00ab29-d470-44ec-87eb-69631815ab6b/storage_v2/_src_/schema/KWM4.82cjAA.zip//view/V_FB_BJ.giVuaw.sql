create view V_FB_BJ as
select a.bjid, a.bh, a.mc, a.rs, a.app_id, a.org_id, a.xzr, a.xzsj, a.gxr, a.gxsj,c.jszid,c.mc as jszmc,
decode(c.bzr,null,'','（'||'班主任：'||c.bzr||'；')||decode(c.yuwen,null,'','语文：'||c.yuwen||'；')||decode(c.shuxue,null,'','数学：'||c.shuxue||'；')
||decode(c.yingyu,null,'','英语：'||c.yingyu||'；')||decode(c.wuli,null,'','物理：'||c.wuli||'；')||decode(c.huaxue,null,'','化学：'||c.huaxue||'；')
||decode(c.shengwu,null,'','生物：'||c.shengwu||'；')||decode(c.lishi,null,'','历史：'||c.lishi||'；')||decode(c.dili,null,'','地理：'||c.dili||'；')
||decode(c.zhengzhi,null,'','政治：'||c.zhengzhi||'；')||decode(c.bzr,null,'','）')
as jszmclink,
c.bzr,c.yuwen,c.shuxue,c.yingyu,c.wuli,c.huaxue,c.shengwu,c.lishi,c.dili,c.zhengzhi,e.org_mc from fb_bj a
left join fb_bj_jsz b on a.bjid=b.bjid
left join fb_jsz c on c.jszid=b.jszid
left join jc_org e on e.org_id=a.org_id
/

