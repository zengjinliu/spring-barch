create view V_SMBD_SHJG as
select a.jgid,a.xsid,a.bmdm,a.shjg,a.shjgmx,a.shr,a.shsj,b.bmid,b.bmmc,b.cols,b.tj,b.colmcs,
decode(a.shjg,'2','审核不通过','1','审核通过','未审核') shjg_n
from smbd_shjg a
left join smbd_bmsz b on a.bmdm=b.bmdm and b.status='1'
/

