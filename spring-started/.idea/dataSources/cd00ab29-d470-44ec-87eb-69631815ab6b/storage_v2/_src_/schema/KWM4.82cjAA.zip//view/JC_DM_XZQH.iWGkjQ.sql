create view JC_DM_XZQH as
    select
a.dmmx_id xzqh_uuid,
'' xzqh_dm,
a.dmmx_mc xzqh_mc,
'' xzqh_qc,
'1' xzqh_dj,
a.dmmx_code xzqh_sjdm,
'00' xzqh_csdm,
'00' xzqh_qxdm,
'00' xzqh_jddm
from jc_dmmx a where a.dm_code='DM_SHENG'
union all
select
a.dmmx_id xzqh_uuid,
'' xzqh_dm,
a.dmmx_mc xzqh_mc,
'' xzqh_qc,
'2' xzqh_dj,
a1.dmmx_code xzqh_sjdm,
a.dmmx_code xzqh_csdm,
'00' xzqh_qxdm,
'00' xzqh_jddm
from jc_dmmx a
left join jc_dmmx a1 on a1.dmmx_id=a.p_dm_id
where a.dm_code='DM_SHI'
union all
select
a.dmmx_id xzqh_uuid,
'' xzqh_dm,
a.dmmx_mc xzqh_mc,
'' xzqh_qc,
'3' xzqh_dj,
(select a2.dmmx_code from jc_dmmx a2 where a2.dmmx_id=a1.p_dm_id) xzqh_sjdm,
a1.dmmx_code xzqh_csdm,
a.dmmx_code xzqh_qxdm,
'00' xzqh_jddm
from jc_dmmx a
left join jc_dmmx a1 on a1.dmmx_id=a.p_dm_id
where a.dm_code='DM_XIAN'
/

