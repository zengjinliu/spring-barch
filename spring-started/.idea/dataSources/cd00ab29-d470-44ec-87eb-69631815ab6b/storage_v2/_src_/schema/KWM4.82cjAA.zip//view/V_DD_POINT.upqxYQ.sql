create view V_DD_POINT as
SELECT
p.pid,
p.xh,
p.content,
p.parentid,
p.rootid,
p.zbfz,
p.expression,
p.plevel,
p.type,
(CASE WHEN P.TYPE > 1 THEN '定量评价' WHEN P.TYPE = 1 THEN '定性评价' ELSE dmmx.dmmx_mc END) typemc,
p.status,
p.xzr,
p.xzsj,
p.gxr,
p.gxsj,
p.org_id,
o.org_mc,
p.app_id,
p.pfxz,
p.ywlx,
p.jfxmid

 FROM dD_point p
 left join jc_org o on o.org_id=p.org_id
 left join jc_dmmx dmmx on dmmx.dm_code='DM_GCDLBM' and p.type=dmmx.dmmx_code and dmmx.dmmx_state='1'
 left join JC_DMTAB dmt on dmt.dm_code='DM_GCDLBM' and  dmt.dm_state='1'
 where p.status!='0'
/

