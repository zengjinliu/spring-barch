create view V_JC_JS_KY_LW_CJ as
SELECT zs.jsky_id as zsid,t1.jsky_id,t1.js_id,t1.xzr,t1.xzsj,t1.gxr,t1.gxsj,t1.status,t1."LWMC",t1."BRJS",t1."FBKWMC",t1."FBFBNY",t1."LWJH",t1."LWQH",t1."QSYM",t1."JSYM",t1."XKLY",t1."SLQK",t2.dmmx_mc dmmx_BRJS_mc,t3.dmmx_mc dmmx_SLQK_mc FROM JC_JS_KY_LW_CJ T1
LEFT JOIN jc_js_ky_lw zs ON T1.JSKY_ID = zs.jsky_id
LEFT JOIN JC_DMMX T2 ON T1.BRJS = T2.DMMX_CODE AND T2.DM_CODE = 'DM_BRJS'
LEFT JOIN JC_DMMX T3 ON T1.SLQK = T3.DMMX_CODE AND T3.DM_CODE = 'DM_LWSLQK'
/

