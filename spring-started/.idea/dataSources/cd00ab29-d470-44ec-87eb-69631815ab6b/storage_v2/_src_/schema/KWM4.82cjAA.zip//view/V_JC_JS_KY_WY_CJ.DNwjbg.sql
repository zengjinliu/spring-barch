create view V_JC_JS_KY_WY_CJ as
SELECT zs.jsky_id as zsid,t1.jsky_id,t1.js_id,t1.xzr,t1.xzsj,t1.gxr,t1.gxsj,t1.status,t1."WYLB",t1."BRJS",t1."HJNY",t1."WYMC",to_char(t1."WCSJ",'YYYY-MM-DD')as WCSJ,t1."WCDD",t1."BRGZ",t2.dmmx_mc dmmx_BRJS_mc,t3.dmmx_mc dmmx_WYLB_mc FROM JC_JS_KY_WY_CJ T1
LEFT JOIN jc_js_ky_wy zs ON T1.JSKY_ID = zs.jsky_id
LEFT JOIN JC_DMMX T2 ON T1.BRJS = T2.DMMX_CODE AND T2.DM_CODE = 'DM_BRJS'
LEFT JOIN JC_DMMX T3 ON T1.WYLB = T3.DMMX_CODE AND T3.DM_CODE = 'DM_WYLB'
/

