create view V_JC_JS_SHJL as
select t.op_log,t."OP_ID",t."JS_ID",t."OP_ZT",t."OP_LX",t."STATUS",t."XZR",t."GXR",t."XZSJ",t."GXSJ",t2.dmmx_mc dmmx_lx
from  jc_js_op t
LEFT JOIN JC_DMMX T2 ON t.op_lx = T2.DMMX_CODE AND T2.DM_CODE = 'DM_JSXXMULB'
 Order By t.xzsj desc
/

