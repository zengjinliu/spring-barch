create view V_JC_JS_SD_RY as
SELECT t1.jssd_id,t1.js_id,t1.xzr,t1.xzsj,t1.gxr,t1.gxsj,t1.status,t1."RYJB",t1."RYCH",to_char(t1.RYFSRQ,'YYYY-MM-DD')as RYFSRQ,t1."RYJL",t1."RYSYDW",t2.dmmx_mc dmmx_RYJB_mc,t3.dmmx_mc DMMX_RYCH_MC FROM JC_JS_SD_RY T1
LEFT JOIN JC_DMMX T2 ON T1.RYJB = T2.DMMX_CODE AND T2.DM_CODE = 'DM_RYJB'
LEFT JOIN JC_DMMX T3 ON T1.RYCH = T3.DMMX_CODE AND T3.DM_CODE = 'DM_RYCH'
/

