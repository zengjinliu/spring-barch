create view V_DZ_CLSH as
select DZ.SID SID,DZ.MXID MXID,dp.pid PID,dp.z_fz,dpb.MBORG_ID MBORG_ID, dpt.content,dpt.xh,DPT.PFXZ,
jo.org_mc ORG_MC,PC.S_STARTTIME,PC.S_ENDTIME,PC.PCID PCID,pc.pcmc pcmc,
DZ.SHORG_ID SHORG_ID,o.org_mc SHORG_MC,dz.status STATUS,DZ.S_LEVEL S_LEVEL,DZ.S_FZ S_FZ,DZ.SHYJ SHYJ,DPT.TYPE TYPE,
dpt.Expression Expression,DP.MBID,dpt.zbfz,dmmx.dmmx_mc as typemc,dp.zpyj,dp.zpyj_text,dp.z_level,dz.czwt,jo.org_orderid,dz.qzzb,jo.org_id,dz.gxsj,
pc.pcnf,pc.app_id,o.org_orderid shorg_orderid


 from dz_clsh dz
 left join dz_pgmx dp on dz.mxid = dp.mxid
 left join dz_point dpt on dpt.pid = dp.pid
 left join dz_pgmb dpb on dpb.mbid = dp.mbid


  left join DZ_PC PC ON PC.PCID=dpb.pcid
 left join jc_org jo on dpb.mborg_id = jo.org_id
 left join jc_org o on o.org_id = DZ.SHORG_ID
 left join jc_dmmx dmmx on dmmx.dm_code='DM_GCDLBM' and dpt.type=dmmx.dmmx_code and dmmx.dmmx_state='1'
 where dpb.status >= 2
/

