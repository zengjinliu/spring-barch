create view V_JC_ORG_BJ as
select b.org_id,b.org_mc,nvl(a.orgid,'0') ishave,b.org_dm,b.org_orderid,
a.jhs,a.xx_org_id,a.nj_org_id
from jc_org b
left join jc_org_bj a on b.org_id=a.orgid
where b.org_state='1' and b.org_dj=(select nvl(z.con_value,'105') from jc_const z where z.con_key='JC_BJDJDM')
/

