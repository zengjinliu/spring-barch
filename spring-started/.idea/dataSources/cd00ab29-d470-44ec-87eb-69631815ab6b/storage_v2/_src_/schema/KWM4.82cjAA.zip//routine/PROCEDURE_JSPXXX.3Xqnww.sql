create procedure procedure_jspxxx -- 创建存储过程 培训信息
  as
   tbsj date;
  begin
  select max(time_bz) into tbsj from gz_sjjh.JS_TB_BIZ_JZGGNPXXX;
  delete from jc_js_px b where exists   (select 1 from  gz_sjjh.JS_TB_BIZ_JZGGNPXXX a where a.id=b.jspx_id and a.TIME_BZ> ( select c.updatetime from JC_DATA_TIME c  where c.model_type = 'JC_JS_PX'));
  insert into jc_js_px b (JSPX_ID,JS_ID,PXND,PXLB,PXMC,PXJGMC,PXFS,PXXS,PXXF,STATUS,XZR,XZSJ)
      select j.id,
       JB.JSJB_ID,
      j.PXND PXND,
      (select d1.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d1 where d1.zdbs='PXJB' and d1.zdxbs = j.PXJB) PXLB,
      j.PXXMMC PXMC,
      j.PXJGMC PXJGMC,
      (select d2.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d2 where d2.zdbs='PXXS' and d2.zdxbs = j.PXXS) PXFS,
      case is_number(j.PXXS2) when 1 then to_number(j.PXXS2) else 0 end,
      case is_number(j.PXHDXF) when 1 then to_number(j.PXHDXF) else 0 end,
      '1',
      'SJTB',
      sysdate
  from gz_sjjh.JS_TB_BIZ_JZGGNPXXX j
  join JC_JS_JB JB
  on j.JSID = JB.JSJB_ID
 where  j.SFSC = '0' and j.shzt='2' and j.TIME_BZ>(  select c.updatetime from JC_DATA_TIME c  where c.model_type = 'JC_JS_PX');
  update JC_DATA_TIME set updatetime = tbsj where model_type = 'JC_JS_PX';

   exception when others then
  dbms_output.put_line(sqlcode||'>>>>>>' || sqlerrm);
  commit;
end procedure_jspxxx;
/

