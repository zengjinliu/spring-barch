create view V_JC_PGBZ as
select
m.bzid,m.ywlx,decode(m.ywlx,'SJTB','报表上报','DDPG','督导评估','XTSZ','系统设置','SJZD','数据字典','DMB','代码表','ZSSZ','招生设置','CMS','CMS','DDPGBZ','督导评估标准','TKJL','听课记录','TCPGBZ','体测评估标准') ywlxmc,
m.bzbh,m.bzmc,m.bzbz,m.gid,m.bzszfs,m.bzpath,m.org_id,m.app_id,m.yxzt,decode(m.yxzt,'1','有效','2','已删除') yxztmc,m.xzsj,m.gxsj,m.jspath,m.mblx,c.content_id,c.content_type,c.title,c.txt,
case when exists(select 1 from jc_batch s where s.mbid=m.bzid ) then '1' else '0' end isuse,
case when exists(select 1 from tc_jfxm_pgbz x where x.bzid=m.bzid ) then '1' else '0' end tc_jfxm_isuse,
case when exists(select 1 from tc_zbfz y where y.bzid=m.bzid ) then '1' else '0' end tc_zbfz_isuse,
case when exists(select 1 from jc_pgbz_jfxm y where y.bzid=m.bzid ) then '1' else '0' end pgbz_jfxm_isuse,
o.org_mc,m.xh,jpg.gmc
from jc_pgbz m
left join jc_content c on m.content_id=c.content_id
left join jc_org o on o.org_id = m.org_id
left join jc_pgbz_grade jpg on jpg.gid = m.gid
where m.yxzt='1'
/

