create view V_ZZXT_ZZDX as
select
z.cz_id,z.xmid,z.czlxm,E.DMMX_MC AS "CZLXMC",z.hjm,E1.DMMX_MC AS "HJMC"
from zzxt_zzdx z
 LEFT JOIN JC_DMMX E
    ON z.czlxm = E.DMMX_CODE
   AND E.DM_CODE = 'DM_CZLX'
    LEFT JOIN JC_DMMX E1
    ON z.hjm = E1.DMMX_CODE
   AND E1.DM_CODE = 'DM_HJ'
/

