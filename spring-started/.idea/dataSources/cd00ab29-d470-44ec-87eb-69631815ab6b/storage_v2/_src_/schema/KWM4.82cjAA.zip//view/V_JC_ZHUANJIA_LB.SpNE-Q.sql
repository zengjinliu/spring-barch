create view V_JC_ZHUANJIA_LB as
select t."UUID",t."ZJ_ID",t."LB_ID",t."STATUS",t."XZR",t."XZSJ",t."GXR",t."GXSJ" from jc_zhuanjia_lb t
/

