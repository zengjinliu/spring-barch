create procedure PRO_TC_XSZCJ(
xs_id in varchar2,--学生ID
pc_id in varchar2--批次ID
)
is
  --游标：根据学生ID和批次ID找出相关的计分项目
  cursor jfxms is select * from tc_jf_result a 
  where a.pcid=pc_id and a.xsid=xs_id;
  
  jfxm jfxms%rowtype ;--单个计分项目
  is_hmxs integer  default 0;--是否属于缓免学生
  v_zf number default 0;--总分
  v_bzf number default 0;--标准分
  v_fjf number default 0;--附加分
  v_bzfzf number(8,1) default 0;--标准分总分
  v_fjfzf number default 0;--附加分总分
  v_njdm varchar2(100);--年级代码
  v_bzid varchar2(100);--标准ID
  v_qz  number default 0;--权重
  v_djid varchar2(100);--等级ID
  v_djmc varchar2(100);--等级名称
  v_orgid varchar2(100);--orgid
  v_appid varchar2(100);--appid
  is_exisit_jfjg integer  default 0;--检查计分结果是否存在
  is_exisit_zf integer  default 0;--检查总分是否存在
  
begin  
      --缓免学生直接过滤掉
      select count(*) into is_hmxs from TC_HMXS th where th.xsid=xs_id;
      if(is_hmxs = 0)  
      then 
        --先检查学生是否有计分结果，没结果则退出
        select count(*) into is_exisit_jfjg from TC_JF_RESULT e where e.XSID=xs_id and e.PCID=pc_id;
        if(is_exisit_jfjg = 0)
        then
          return;
        end if;  
            
        open jfxms;
        loop
          fetch jfxms into jfxm;
          exit when jfxms%notfound;           
            
                --根据计分项目ID查出单项标准分和附加分
                select b.bzf,b.fjf,b.orgid,b.appid into v_bzf,v_fjf,v_orgid,v_appid from tc_jf_result b where b.jfid=jfxm.jfid and b.pcid=pc_id and b.xsid=xs_id;
                
                --根据学生ID查询年级代码
                select m.njdm into v_njdm from TC_XS m where m.XSID=xs_id;
                EXIT WHEN v_njdm IS NULL;  
                --根据批次ID找出标准ID
                select n.mbid into v_bzid from Jc_Batch n where n.bid=pc_id;
                EXIT WHEN v_bzid IS NULL; 
                
                --根据标准ID和年级代码找出权重
                select d.qz into v_qz from  tc_jfxm c 
                inner join tc_jfxm_pgbz d on d.jfid=c.jfid
                where c.jfid=jfxm.jfid and d.bzid=v_bzid and d.njdm=v_njdm;
                EXIT WHEN v_qz IS NULL;
                
                --标准分大于100，取100来计算标准总分
                --if(v_bzf>100)
                --then
                  --v_bzf :=100;
                --end if;
                                   
                v_bzfzf := v_bzfzf + v_bzf*v_qz/100;--标准分总分=原标准分+现标准分（现标准分=单项标准分*权重/100）
                v_fjfzf := v_fjfzf+v_fjf;--附加分总分=原附加分+现附加分
                v_zf := v_bzfzf+v_fjfzf;--总分=标准分总分+附加分总分
                
                --根据标准ID、标准分找出对应的等级
                select  q.gmxid,q.gmxmc into v_djid,v_djmc from jc_pgbz o 
                inner join jc_pgbz_grade p on p.gid = o.gid
                inner join jc_pgbz_grade_mx q on q.gid=p.gid
                where o.bzid=v_bzid and q.max>v_zf and v_zf>=q.min and rownum = 1;   
                EXIT WHEN v_djid IS NULL or v_djmc IS NULL; 
                
                --先根据学生ID、批次ID删除存在的数据，然后再新增
                select count(zfid) into is_exisit_zf from TC_ZF where XSID=xs_id and PCID=pc_id;
                if(is_exisit_zf>0)
                then   
                  delete from TC_ZF where XSID=xs_id and PCID=pc_id; 
                end if;        
                insert into TC_ZF(ZFID,PCID,XSID,ZF,BZF,FJF,DJID,DJMC,ORGID,APPID,xzsj,Status) 
                values(FN_UUID(),pc_id,xs_id,v_zf,v_bzfzf,v_fjfzf,v_djid,v_djmc,v_orgid,v_appid,sysdate,'1');  
                                      
          commit;        
        end loop;
      close jfxms;   
      update tc_jsfs set state='2',etime=sysdate where pcid=pc_id and xxid=v_orgid;
      end if;  
end PRO_TC_XSZCJ;
/

