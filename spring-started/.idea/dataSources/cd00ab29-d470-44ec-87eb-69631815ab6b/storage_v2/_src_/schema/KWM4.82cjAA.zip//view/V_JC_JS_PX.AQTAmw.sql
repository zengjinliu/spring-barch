create view V_JC_JS_PX as
SELECT t1.jspx_id,t1.js_id,t1.xzr,t1.xzsj,t1.gxr,t1.gxsj,t1.status,t1."PXND",t1."PXLB",t1."PXMC",t1."PXJGMC",t1."PXFS",t1."PXXS",t1."PXXF",t2.dmmx_mc dmmx_PXLB_mc,t3.dmmx_mc dmmx_PXFS_mc FROM JC_JS_PX T1
LEFT JOIN JC_DMMX T2 ON T1.PXLB = T2.DMMX_CODE AND T2.DM_CODE = 'DM_PXLB'
LEFT JOIN JC_DMMX T3 ON T1.PXFS = T3.DMMX_CODE AND T3.DM_CODE = 'DM_PXFS'
/

