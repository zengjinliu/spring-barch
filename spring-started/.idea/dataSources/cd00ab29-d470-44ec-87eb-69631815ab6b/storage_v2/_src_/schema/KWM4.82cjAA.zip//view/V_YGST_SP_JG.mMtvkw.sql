create view V_YGST_SP_JG as
select jo.bm,jo.mc,a.jgid,a.spid,a.jg,a.ny,a.jgly,a.xzsj,jo.org_id,jo.app_id,jo.gg,jo.dw,jo.bz
from ygst_sp jo right join ygst_sp_jg a on jo.spid=a.spid and jo.yxzt='1'
/

