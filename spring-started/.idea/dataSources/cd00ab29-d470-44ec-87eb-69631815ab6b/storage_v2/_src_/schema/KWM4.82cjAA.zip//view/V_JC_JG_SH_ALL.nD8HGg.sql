create view V_JC_JG_SH_ALL as
select z.JGID,z.GH,z.XM,z.YWXM,z.XMPY,z.CYM,z.XBM,to_char(z.CSRQ,'YYYY-MM-DD')as CSRQ,z.CSDM,z.JG,z.MZM,z.GJDQM,z.SFZJLXM,z.SFZJH,z.xzr,z.xzsj,z.gxr,z.gxsj,
z.STATE,z.GZDW,z.org_id,z.user_id,p.op_lx,p.OP_ID,j.title,j.state p_state,j.systemtype,j.businessid,j.userid,t2.dmmx_mc dmmx_xb_mc,
t3.dmmx_mc dmmx_sfzjlx_mc,t4.dmmx_mc dmmx_lx_mc,o.org_mc
from  jc_pending j
left join jc_js_op p ON J.BUSINESSID = p.op_id
left join jc_jg_CJ z on p.js_id=z.jgid
left join jc_org o on o.org_id=z.org_id
LEFT JOIN JC_DMMX T2 ON z.xbm = T2.DMMX_CODE AND T2.DM_CODE = 'DM_XB'
LEFT JOIN JC_DMMX T3 ON z.SFZJLXM = T3.DMMX_CODE AND T3.DM_CODE = 'DM_SFZJLX'
LEFT JOIN JC_DMMX T4 ON p.op_lx = T4.DMMX_CODE AND T4.DM_CODE = 'DM_JSXXMULB'
where z.state!='4' order by j.createtime desc
/

