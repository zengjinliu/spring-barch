create view V_ZS_XJ_BAK as
select
a.name XM,
a.sfzh SFZJH,
C.XXID xj_xxid,
C.XXNAME xj_xxmc,
DECODE(B.ZXZK,'是','1','0') XJ_ZXZK,
f.NJDM XJ_NJDM,
DECODE(a.sex,'男','1','2') XB,
to_char(a.birthday,'yyyy-MM-dd') CSRQ,
b.xcode xjh,
(select d.xxname from emis.a_school d where d.xxcode=substr(c.xxcode,0,6)) bydq,
e.org_id,
decode(c.xxcode,'440200000101','440201000555',c.xxcode) xj_xxdm,
c.bxms_c gmb,g.org_mc zs_orgmc
from
emis.x_jbqk a
inner join emis.x_zxqk b on b.jbqk_id=a.jbqk_id
inner join emis.a_school c on c.xxcode=b.xxcode
left join zs_xj_org e on e.xj_org_id=c.xxid
left join jc_org g on g.org_id=e.org_id and g.org_state='1'
left join zs_xj_nj f on f.xj_njdm=b.nj_c
/

