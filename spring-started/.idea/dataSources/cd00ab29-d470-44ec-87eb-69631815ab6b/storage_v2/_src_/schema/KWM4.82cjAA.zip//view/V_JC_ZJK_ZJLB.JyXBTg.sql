create view V_JC_ZJK_ZJLB as
select
  B.ZJLB_ID AS "id",
  B.P_UUID AS "pId",
  B.LBMC AS "name",
  B.LBDM AS "val"
    from JC_ZJK_ZJLB B
   where
       B.STATUS = 1
/

