create view V_JC_ZJK as
select "ZJK_ID","ZJKMC","ZJKMS","ORG_ID","STATUS","XZR","XZSJ","GXR","GXSJ" from jc_zjk
/

