create procedure procedure_jzgkygbhb -- 创建存储过程 教职工科研国标行标
  as
  tbsj date;
  begin
  select max(time_bz) into tbsj from gz_sjjh.js_tb_biz_jzggjbzhhybzxx;
  delete from JC_JS_KY_BZ b where exists   (select 1 from  gz_sjjh.js_tb_biz_jzggjbzhhybzxx a where a.id=b.jsky_id and a.TIME_BZ> ( select c.updatetime from JC_DATA_TIME c  where c.model_type = 'JC_JS_KY_BZ'));
  insert into JC_JS_KY_BZ b (JSKY_ID,JS_ID,BZH,SFCGDB,BRJS,FBRQ,FBDW,STATUS,XZR,XZSJ)
  select j.id,
      JB.JSJB_ID,
      j.bzh,
      (select d1.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d1 where d1.zdbs='SFSDBXCGHXM' and d1.zdxbs = j.SFSDBXCGHXM)SFSDBXCGHXM,
      (select d2.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d2 where d2.zdbs='BZZBRJS' and d2.zdxbs = j.bzzbrjs)bzzbrjs,
      case is_date(j.fbrq) when 1 then  to_date(j.fbrq , 'yyyy-mm-dd hh24:mi:ss') else to_date('1900/01/01','yyyy/mm/dd') end,
      j.fbdw,
      '1',
      'SJTB',
      sysdate
  from gz_sjjh.js_tb_biz_jzggjbzhhybzxx j
  join JC_JS_JB JB
  on j.JSID = JB.JSJB_ID
  where  j.SFSC = '0' and j.shzt='2' and j.TIME_BZ>(  select c.updatetime from JC_DATA_TIME c  where c.model_type = 'JC_JS_KY_BZ');
  update JC_DATA_TIME set updatetime = tbsj where model_type = 'JC_JS_KY_BZ';

   exception when others then
  dbms_output.put_line(sqlcode||'>>>>>>' || sqlerrm);
  commit;
end procedure_jzgkygbhb;
/

