create view V_YGST_GYS_ZK as
select a.zkid,a.org_id,a.app_id,to_char(a.KSRQ,'yyyy-mm-dd') KSRQ,to_char(a.JSRQ,'yyyy-mm-dd') JSRQ,a.scdlid,(a.ZK||'%') ZKMC,a.ZK ZK,b.gysmc,c.scdlmc from ygst_gys_zk a
left join ygst_gys b on a.ORG_ID=b.gysid
left join ygst_scdl c on c.scdlid=a.scdlid
/

