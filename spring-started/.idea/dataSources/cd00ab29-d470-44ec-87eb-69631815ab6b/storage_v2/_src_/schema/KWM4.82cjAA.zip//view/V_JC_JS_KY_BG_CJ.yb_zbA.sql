create view V_JC_JS_KY_BG_CJ as
SELECT zs.jsky_id as zsid,t1.jsky_id,t1.js_id,t1.xzr,t1.xzsj,t1.gxr,t1.gxsj,t1.status,t1."BGMC",t1."BRJS",to_char(t1."BGSJ",'YYYY-MM-DD')as BGSJ,t1."WTF",t2.dmmx_mc dmmx_BRJS_mc FROM JC_JS_KY_BG_CJ T1
LEFT JOIN JC_DMMX T2 ON T1.BRJS = T2.DMMX_CODE AND T2.DM_CODE = 'DM_BRJS'
LEFT JOIN jc_js_ky_bg zs ON T1.JSKY_ID = zs.jsky_id
/

