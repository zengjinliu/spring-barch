create view V_SMBD_GBMJG as
select A.XSID,A.XM,A.SFZJLXM,A.SFZJH,A.PWD,A.LSH,A.JT_SFZJH1,A.JT_SFZJH2,A.JT_LXDH1,A.JT_LXDH2,A.HKXZM,A.HJLXM,
A.CSRQ,A.JT_YLBXYS1,A.JT_YLBXYS2,A.JT_YILBXYS1,A.JT_YILBXYS2,A.JT_SBLJYS1,A.JT_SBLJYS2,A.ZF_ISSFZH2,A.CQRGX,A.JT_QRSZSJ1,A.JT_QRSZSJ2,
A.ZF_CHZRGX,A.ZF_ZLYT,A.ZF_ISXQ,A.ZF_ISWFZM,A.ZF_ZLLJYS,A.ZF_JHTBAH,A.ZF_JHTBARQ,A.ZF_JHTCHZR,ZF_HJISQR,
A.FWID,A.JT_SBFZDW1,A.JT_SBFZDW2,A.ZF_ISKFZM,A.ZF_KFZMYS,A.XZSJ,A.XZR,A.JFMX,A.XBM,A.JT_XM1,A.JT_XM2,A.YHXQJF,A.XQJF,
A.ZZZH,A.MZM,A.CSDM,A.CSD,A.JG,A.HKSZDM,A.HKSZD,A.XZZ,A.TXDZ,A.JTZZ,A.LXDH,A.JDFSM,A.SFYHDX,A.HKBHZ,
A.HKSSPCS,A.HKXXDZ,A.HZGX,A.YZBM,A.ZZMMM,A.GJDQM,A.JKZK,A.XWLB,A.SFDQ,A.SFLSETM,A.GATQWM,A.SFSQZNM,A.SFSGXQJYM,
A.SFGE,A.SFLSHYFZN,A.BYXXBZ,A.BYXXMC,A.SFFCTP,A.SFBL,A.BLYY,A.FCLB,A.CQR,A.CHZR,A.CQR_SFZJH,A.FCZH,A.FCFZDW,A.FCDZ,
A.DJBARQ,A.FZRQ,A.CZR,A.ZLKSRQ,A.ZLJSRQ,A.FCFE,A.ZLBADW,A.JT_RELAT1,
A.JT_SFZJLX1,A.JT_MZ1,A. JT_HKSZDM1,A.JT_HKSZD1,A.JT_GZDW1,A.JT_SBDNH1,A.JT_CBRQ1,
A.JT_RELAT2,A.JT_SFZJLX2,A.JT_MZ2,A.JT_HKSZDM2,A.JT_HKSZD2,A.JT_GZDW2,A.JT_SBDNH2,
A.JT_CBRQ2,A.JT_HJLXM1,A.JT_HJLXM2,A.DXQID,A.JT_ZSJZNX1,A.JT_ZSJZNX2,A.JT_JZZQFRQ1,A.JT_JZZQFRQ2,
A.JS_QK,A.JS_FZBSC,A.JS_FZDW,A.ZF_JTSSDWMC,A.NJDM,A.ZF_ZLMJ,A.JT_JYLX1,A.JT_JYLX2,
A.ZF_QRSZSJ,A.JT_CBRGX,A.JT_CBR,A.JT_CBRSFZJH,A.SQLB,A.JT_JZZH1,A.JT_JZZH2,
A.XQJF_JS,A.ZF_JHTJSRQ,A.ZF_OLDFCLB,A.FCDZ FWDZ,A.BYXXLB,A.JS_GZSH,
A.ZF_FCQBM,A.ZF_FCQMC,A.ZF_JDMC,A.ZF_LDMC,A.JT_ISJZZH1,A.JT_ISJZZH2,
A.LOCKID,A.ZF_HKSFYQ,A.XZSJ XZSJ2,A.TSBJ,A.ZF_BADWBSC,A.JT_CBRSFZJH2,A.JT_CBR2,
A.YHJFGXSJ,A.YHJFGXR,A.ZXTBLDID,A.HJLXMC,A.JT_HJLX1,A.JT_HJLX2,
JT_ZYZGDM1,JT_ZYZGBH1,JT_WHCDDM1,JT_WHCDBH1,JT_WHCDBGBH1,JT_BYSJ1,JT_BYXXMC1,
JT_ZYZGDM2,JT_ZYZGBH2,JT_WHCDDM2,JT_WHCDBH2,JT_WHCDBGBH2,JT_BYSJ2,JT_BYXXMC2,
A.JFXM,A.ZF_YWFC,A.JFX_JHR,A.JFX_JYORWH,A.JFX_JYORWH2,A.XB,
'' ORG_DM1,'' YDDXQJF1,'' YDDXQJF2,'' YDDXQJF3,'' YDDXQJF4,
A.SQXX_XH1 XH,A.SQXXID1,A.SQXXID1 ORG_ID,A.SQXXMC1,A.SQXX_XH1 ORG_ORGDERID1,
A.SQXX_XH2 XH2,A.SQXXID2,A.SQXXMC2,A.SQXX_XH2 ORG_ORGDERID2,
A.SQXX_XH3 XH3,A.SQXXID3,A.SQXXMC3,A.SQXX_XH3 ORG_ORGDERID3,
A.SQXX_XH4 XH4,A.SQXXID4,A.SQXXMC4,A.SQXX_XH4 ORG_ORGDERID4,
A.SQXX_XH5 XH5,A.SQXXID5,A.SQXXMC5,A.SQXX_XH5 ORG_ORGDERID5,
A.SQXX_XH6 XH6,A.SQXXID6,A.SQXXMC6,A.SQXX_XH6 ORG_ORGDERID6,
A.SQXX_XH7 XH7,A.SQXXID7,A.SQXXMC7,A.SQXX_XH7 ORG_ORGDERID7,
A.SQXX_XH8 XH8,A.SQXXID8,A.SQXXMC8,A.SQXX_XH8 ORG_ORGDERID8,
A.SQXX_XH9 XH9,A.SQXXID9,A.SQXXMC9,A.SQXX_XH9 ORG_ORGDERID9,
A.SQXX_XH10 XH10,A.SQXXID10,A.SQXXMC10,A.SQXX_XH10 ORG_ORGDERID10,
A.SHZT,A.SHXX,A.SHR,A.SHSJ,A.SHZTMC,A.SFCSSJ,nvl(ZJG,'0') ZJG,nvl(A.ZJGMC,'未审核') ZJGMC,A.HKXZMC,A.SFZJLXMC,
A.LQZT,A.LQ_ORGID LQXXID,A.LQSJ,A.LQZTMC,A.LQXX,A.YLQZT,A.YLQZTMC,A.YLQXX,A.YLQ_ORGID YLQXXID,
A.ZCZTMC,A.ZCZT,A.ZCR,A.ZCSJ,A.DXQ_MC,
decode(a.njdm,'11','小学一年级','12','小学二年级','13','小学三年级','14','小学四年级','15','小学五年级','16','小学六年级','21','初中一年级','22','初中二年级','23','初中三年级','31','高中一年级','32','高中二年级','33','高中三年级','41','大学一年级','42','大学二年级','43','大学三年级','44','大学四年级','01','小班','02','中班','03','大班','04','大大班') NJMC,
A.HZGXMC,A.JT_RELATMC1,A.JT_RELATMC2,FCFEMC,A.FCLBMC,A.GJDQMC,A.MZMC,
A.JT_HJLXMC1,A.JT_HJLXMC2,A.JT_MZMC1,A.JT_MZMC2,A.JT_SFZJLXMC1,A.JT_SFZJLXMC2,
A.ZF_OLDFCLBMC,A.JDFSMC,'' ZHXWLB,ZF_ISSFZH2 SFCXJFJS,A.JT_ZYZGMC1,A.JT_WHCDMC1,A.JT_ZYZGMC2,A.JT_WHCDMC2,
A.ZCDQ,A.YJDXX,A.YJDNJ,A.XCODE,A.YJDQX,A.YJDXXID,A.YJDQXMC,A.YJDNJMC,A.JT_JZZHLJYS,A.APP_ID,A.YHDXM,
A.YHDXZSHM,A.YHDXZSFZDW,A.SFECBM,A.DQCL,A.SXXJTJL,A.SFCZXC,A.SXXJTFS,A.SXXJTFSMC,A.TC,A.SFDSZN,
A.SFSQZZ,A.SFXSYB,A.CJLX,A.CJLXMC,A.SBJD,A.SBJDMC,A.SFYZFGMXW,A.SFZXS,A.RXFS,A.RXFSMC,A.JT_ZW1,A.JT_ZW2,
A.LQMX,A.YLQMX,A.SFTZLQ,A.SFCZXCMC,A.JKZKMC,A.SFLSETMC,A.SFSGXQJYMC,A.GATQWMC,A.SFSQZNMC,A.SFGEMC,A.SFDSZNMC,
A.SFSQZZMC,A.SFXSYBMC,A.SFYZFGMXWMC,A.SFLSHYFZNMC,A.SFZXSMC,A.SFDQMC,A.RXLBMC,A.RXLBDM,
A.ZF_QDDX,A.ZF_CQR1,A.ZF_CQR_SFZJH1,A.RXZMBH,A.YHDXBH,A.YHDXFZDW,A.DDM,A.FCLB_OTHER,
A.HJDZ_QU_ID,A.HJDZ_QU_MC,A.HJDZ_JD_ID,A.HJDZ_JD_MC,A.HJDZ_SQ_ID,A.HJDZ_SQ_MC,A.HJDZ_XXXX,A.HJDZ_SQXX,HJDZ_SQXX_MC,
A.HJDZ_QU_MC||A.HJDZ_JD_MC||A.HJDZ_SQ_MC HJDZ_QC,
A.JZDZ_QU_ID,A.JZDZ_QU_MC,A.JZDZ_JD_ID,A.JZDZ_JD_MC,A.JZDZ_SQ_ID,A.JZDZ_SQ_MC,A.JZDZ_XXXX,A.JZDZ_SQXX,JZDZ_SQXX_MC,
A.JZDZ_QU_MC||A.JZDZ_JD_MC||A.JZDZ_SQ_MC JZDZ_QC,
A.SFTCS,A.TCZT,A.QUSHZT,A.QUSHXX,A.QUSHR,A.QUSHSJ,A.DRXJZT,A.DRXJR,A.DRXJSJ,A.QUSHZTMC,A.DRXJZTMC,
decode(NJDM,'11','幼儿园','21','小学') BYXXDETAIL,case when DXQID is null then '否' else '是' end ISDXQ ,
decode(SFYHDX,'1','是','0','否','') SFYHDXMC,decode(ZF_ISWFZM,'1','是','0','否','') ZF_ISWFZMMC,
decode(ZF_ISXQ,'1','是','0','否','') ZF_ISXQMC,case when SFBL='1' then '补申请录入' else '正常录入' end SFBLMC,
decode(ZF_ISSFZH2,'Y','是','0','否','') SFCXJFJSMC,decode(JT_JYLX2,'1','社保','2','无','') JT_JYLXMC2,
decode(JT_JYLX1,'1','社保','2','无','') JT_JYLXMC1,decode(ZF_ISWFZM,'1','是','0','否','') ZF_ISWFZMC,
decode(ZF_ISKFZM,'1','是','0','否','') ZF_ISKFZMC,decode(ZF_HJISQR,'1','是','0','否','') ZF_HJISQRMC,decode(SFFCTP,'1','是','0','否','') SFFCTPMC,
A.SFZJCJ SFCJ,decode(A.SFZJCJ,'1','是','否') SFCJMC,BY1,BY2,BY3,BY4,BY5,BY6,BY7,BY8,BY9,BY10,
A.YYID,A.YYSJ_KSSJ,A.YYSJ_JSSJ,A.BMTJ,A.YDDJF1,A.YDDJF2,A.YDDJF3,A.YDDJF4,
A.JT_XZZ1,A.JT_XZZ2,A.ISSDXGJF,
decode(nvl(A.FWID,'00'),'00','自行填报','系统选择') DZLRFS,decode(nvl(A.FWID,'00'),'00','0','1') DZLRFSM,decode(fwid,'00','是','否') SFZXTBMC,
A.BY_SZDM,A.BY_SZD,A.BY_BJMC,A.BY_XSZW,A.GZ_XJCODE,A.QGXJH,A.SFSQZS,A.SFXYZZC,
A.JT_SFCYJZZ1,A.JT_SFCYJZZ2,A.ZF_BADWJWH,ZF_BADWBSCMC,
decode(A.SFSQZS,'0','否','1','是') SFSQZSMC,
decode(A.SFXYZZC,'0','否','1','是') SFXYZZCMC,
decode(A.JT_SFCYJZZ1,'0','否','1','是') JT_SFCYJZZMC1,
decode(A.JT_SFCYJZZ2,'0','否','1','是') JT_SFCYJZZMC2,
decode(A.JT_ISJZZH1,'0','否','1','是') JT_ISJZZHMC1,
decode(A.JT_ISJZZH2,'0','否','1','是') JT_ISJZZHMC2,
decode(A.ZF_YWFC,'02','否','01','是') ZF_YWFCMC,
A.XQJF+nvl(A.YDDJF1,0) XQJF1,A.XQJF+nvl(A.YDDJF2,0) XQJF2,A.XQJF+nvl(A.YDDJF3,0) XQJF3,A.XQJF+nvl(A.YDDJF4,0) XQJF4,
A.XQJF+nvl(A.YDDJF1,0) AS XQJFS,
case when A.SQXXID10 IS NOT NULL THEN '1' ELSE '0' END SFSBGYMB,to_char(a.ZLKSRQ,'yyyy-MM-dd')||'~'||to_char(a.ZLJSRQ,'yyyy-MM-dd') ZLQX,
case when a.FCLB in('10','11','12','13','14','25','32','34','35','36','37','38','99','51','07') then 'TSZF'
when a.FCLB in('18','19','20','21','26','27','28','29','30','31','43','49','50') then 'ANFBZF'
when a.FCLB in('15') then 'LZFGZF'
when a.FCLB in('16') then 'ZZF'
when a.FCLB in('08','09') then 'ZLBM'
when a.FCLB in('01','03','04','06','33','39','52','53','54','22','24') then 'GTBM'
when a.FCLB in('02','05','23') then 'GFHT'
when a.FCLB='17'  then 'GGZLF' else '' end FCSH,
case when a.FCLB in('04','05','06','99','10','11','12','13','14') then 'XQ' when a.FCLB='17' and a.ZF_QDDX='公司' then 'XQ' else 'NXQ' end LGISXQ,
case when a.Fclb in('04','05','06','08','09','17') and a.zf_iswfzm='1' then 'WFZM' else 'NWFZM' end LGWFZM,
case when a.Fclb in('04','05','06','08','09','14','15','16') and a.zf_iswfzm='1' then 'WFZM' else 'NWFZM' end NSWFZM,
case when a.Fclb in('04','05','06','07') and nvl(a.hjlxm,'A')<>'05' and a.zf_iswfzm='1' then 'WFZM'
     when a.fclb in('08','09','22','23','24') and a.zf_iswfzm='1' then 'WFZM' else 'NWFZM' end LUOHWFZM,
--福田无房证明
case when (a.fclb in('04','05','06','08','09','14','15') or a.cqrgx='05' or a.zf_hjisqr='0') and a.zf_iswfzm='1' then 'WFZM'
     when a.fclb in('04','05','06') and HJLXM in('01') and a.zf_hjisqr='0' and a.zf_iswfzm='1'then 'WFZM'
     when a.fclb in('04','05','06') and HJLXM not in ('01') and a.zf_iswfzm='1' then 'WFZM' else 'NFWZM' end FTWFZM,
--宝安无房证明
case when a.fclb in('08','11','12','13','14','17') and (HJLXM in('07','01','02','05') or a.sfyhdx='1') and a.zf_iswfzm='1' then 'WFZM' else 'NFWZM' end BAWFZM,
case when a.fclb in('08',09) then '1' else '0' end ZL,
decode(a.js_qk,'独生子女','独生子女','政策内或全面二孩','政策内或全面二孩',
     '政策外但已接受处理','有政策外出生但已接受处理','政策外未接受处理','有政策外出生子女未接受处理或数据有误','')js_qk_bd,

case when sh.shjg is not null then sh.shjg else '0' end shyj,sh.shjgmx shyjmx,
case when fsh.shjg is not null then fsh.shjg else '0' end fshyj,fsh.shjgmx fshyjmx,
case when sb.shjg is not null then sb.shjg else '0' end sbyj,sb.shjgmx sbyjmx,
case when js.shjg is not null then js.shjg else '0' end jsyj,js.shjgmx jsyjmx,
case when fc1.shjg is not null then fc1.shjg else '0' end fcyj,fc1.shjgmx fcyjmx,
case when fc2.shjg is not null then fc2.shjg else '0' end gfhtyj,fc2.shjgmx gfhtyjmx,
case when zl.shjg is not null then zl.shjg else nvl(zl.shjg,'0') end zlyj,zl.shjgmx zlyjmx,
case when wfzm.shjg is not null then wfzm.shjg else '0' end wfyj,wfzm.shjgmx wfyjmx,
case when bzxzf.shjg is not null then bzxzf.shjg else '0' end bzxzfyj,bzxzf.shjgmx bzxzfyjmx,
case when tf.shjg is not null then tf.shjg else '0' end tfyj,tf.shjgmx tfyjmx,
case when tw.shjg is not null then tw.shjg else '0' end twyj,tw.shjgmx twyjmx,
case when gzs.shjg is not null then gzs.shjg else '0' end gzsyj,gzs.shjgmx gzsyjmx,
case when yh.shjg is not null then yh.shjg else '0' end yhyj,yh.shjgmx yhyjmx,
--珠海资料审核结果
case when a.TSBJ='珠海户籍学生' or a.TSBJ='珠海户籍跨区报读学生' then 'ZH'
when a.TSBJ='政策性照顾生' or a.TSBJ='在珠海工作居住的港澳籍人员子女' or a.TSBJ='异地务工人员随迁子女积分入学'
     or a.TSBJ='父母有一方为珠户的非我市户籍子女' then 'FZH' else '0' end ISZH,
case when a.TSBJ='珠海户籍学生' or a.TSBJ='珠海户籍跨区报读学生' then 'ZH'
     when a.TSBJ='政策性照顾生' then 'YHDX'
     when a.TSBJ='在珠海工作居住的港澳籍人员子女' then 'GA'
     when a.TSBJ='异地务工人员随迁子女积分入学' or a.TSBJ='父母有一方为珠户的非我市户籍子女' then 'JFRX'
     else '0' end xslb,case when a.yhxqjf is null then '否' else '是' end SFYYHJF,
case when zh.shjg is not null then zh.shjg else '0' end zhyj,zh.shjgmx zhyjmx,
case when fzh.shjg is not null then fzh.shjg else '0' end fzhyj,fzh.shjgmx fzhyjmx,
case when hj1.shjg is not null then hj1.shjg else '0' end jhryj1,hj1.shjgmx jhryjmx1,
case when hj2.shjg is not null then hj2.shjg else '0' end jhryj2,hj2.shjgmx jhryjmx2,
case when sb1.shjg is not null then sb1.shjg else '0' end sbyj1,sb1.shjgmx sbyjmx1,
case when sb2.shjg is not null then sb2.shjg else '0' end sbyj2,sb2.shjgmx sbyjmx2,
case when yfc.shjg is not null then yfc.shjg else '0' end yfcyj,yfc.shjgmx yfcyjmx,
case when wfc.shjg is not null then wfc.shjg else '0' end wfcyj,wfc.shjgmx wfcyjmx,
case when zhjs.shjg is not null then zhjs.shjg else '0' end zhjsyj,zhjs.shjgmx zhjsyjmx
from zs_xsxx a
left join smbd_shjg sh on sh.xsid=a.xsid and sh.bmdm='SHGA'
left join smbd_shjg fsh on fsh.xsid=a.xsid and fsh.bmdm='FSHGA'
left join smbd_shjg sb on sb.xsid=a.xsid and sb.bmdm='SBBM'
left join smbd_shjg js on js.xsid=a.xsid and js.bmdm='JSBM'
left join smbd_shjg fc1 on fc1.xsid=a.xsid and fc1.bmdm='GTBM'
left join smbd_shjg fc2 on fc2.xsid=a.xsid and fc2.bmdm='GFHT'
left join smbd_shjg zl on zl.xsid=a.xsid and zl.bmdm='ZL'
left join smbd_shjg wfzm on wfzm.xsid=a.xsid and wfzm.bmdm='WFZM'
left join smbd_shjg bzxzf on bzxzf.xsid=a.xsid and bzxzf.bmdm='BZXZF'
left join smbd_shjg tf on tf.xsid=a.xsid and tf.bmdm='TSZF'
left join smbd_shjg tw on tw.xsid=a.xsid and tw.bmdm='TWXS'
left join smbd_shjg gzs on gzs.xsid=a.xsid and gzs.bmdm='GZS'
left join smbd_shjg yh on yh.xsid=a.xsid and yh.bmdm='YHDX'
left join smbd_shjg zh on zh.xsid=a.xsid and zh.bmdm='ZHHJ'
left join smbd_shjg fzh on fzh.xsid=a.xsid and fzh.bmdm='FZHHJ'
left join smbd_shjg hj1 on hj1.xsid=a.xsid and hj1.bmdm='JHR1HJ'
left join smbd_shjg hj2 on hj2.xsid=a.xsid and hj2.bmdm='JHR2HJ'
left join smbd_shjg sb1 on sb1.xsid=a.xsid and sb1.bmdm='ZHSBBM1'
left join smbd_shjg sb2 on sb2.xsid=a.xsid and sb2.bmdm='ZHSBBM2'
left join smbd_shjg yfc on yfc.xsid=a.xsid and yfc.bmdm='ZHYFCBM'
left join smbd_shjg wfc on wfc.xsid=a.xsid and wfc.bmdm='ZHWFCBM'
left join smbd_shjg zhjs on zhjs.xsid=a.xsid and zhjs.bmdm='ZHJSBM'
where nvl(a.shzt,'A')<>'0' and a.sqxxid1 is not null
/

