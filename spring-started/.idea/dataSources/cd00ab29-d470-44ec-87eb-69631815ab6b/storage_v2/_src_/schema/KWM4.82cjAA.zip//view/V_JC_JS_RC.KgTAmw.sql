create view V_JC_JS_RC as
SELECT t1.jsrc_id,t1.js_id,t1.xzr,t1.xzsj,t1.gxr,t1.gxsj,t1.status,t1.rcxmmc,t1.rxnf,T2.DMMX_MC DMMX_RCXMMC_MC
 FROM JC_JS_RC T1
 LEFT JOIN JC_DMMX T2 ON T1.RCXMMC = T2.DMMX_CODE AND T2.DM_CODE = 'DM_RCXMMC'
/

