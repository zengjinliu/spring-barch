create procedure procedure_jzgxxjlxx -- 创建存储过程 教职工学习经历信息
  as
  tbsj date;
  begin
  select max(time_bz) into tbsj from gz_sjjh.JS_TB_BIZ_JZGXXJLXX;
  delete from JC_JS_XX b where exists   (select 1 from  gz_sjjh.JS_TB_BIZ_JZGXXJLXX a where a.id=b.jsxx_id and a.TIME_BZ> ( select c.updatetime from JC_DATA_TIME c  where c.model_type = 'JC_JS_XX'));
  insert into JC_JS_XX b (jsxx_id,JS_ID,XLM,XLGJ,XLYX,SXZY,SFSF,RXNY,BYNY,XWCC,XWMC,XWGJ,XWYX,XWSYNY,XXFS,ZXDWLB,STATUS,XZR,XZSJ)
  select j.id,
      JB.JSJB_ID,
      (select d1.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d1 where d1.zdbs='XL' and d1.zdxbs = j.Hdxl)Hdxl,
      (select d2.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d2 where d2.zdbs='GJDQ' and d2.zdxbs = j.HDXLDGJDQ)HDXLDGJDQ,
      j.Hdxldyxhjg,
      j.Sxzy,
      (select d3.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d3 where d3.zdbs='SFSFLZY' and d3.zdxbs = j.SFSFLZY)SFSFLZY,
      j.Rxny,
      j.Byny,
      (select d4.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d4 where d4.zdbs='XW' and d4.zdxbs = j.XWCC)XWCC,
      (select d5.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d5 where d5.zdbs='XWMC' and d5.zdxbs = j.XWMC)XWMC,
      (select d6.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d6 where d6.zdbs='GJDQ' and d6.zdxbs = j.HDXWDGJDQ)HDXWDGJDQ,
      j.Hdxwdyxhjg,
      j.Xwsyny,
      (select d7.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d7 where d7.zdbs='XXFS' and d7.zdxbs = j.XXFS)XXFS,
      (select d8.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d8 where d8.zdbs='ZXDWLB' and d8.zdxbs = j.ZXDWLB)ZXDWLB,
      '1',
      'SJTB',
      sysdate
  from gz_sjjh.JS_TB_BIZ_JZGXXJLXX j
  join JC_JS_JB JB
  on j.JSID = JB.JSJB_ID
  where  j.SFSC = '0' and j.shzt='2' and j.TIME_BZ>(  select c.updatetime from JC_DATA_TIME c  where c.model_type = 'JC_JS_XX');
  update JC_DATA_TIME set updatetime = tbsj where model_type = 'JC_JS_XX';

   exception when others then
  dbms_output.put_line(sqlcode||'>>>>>>' || sqlerrm);
  commit;
end procedure_jzgxxjlxx;
/

