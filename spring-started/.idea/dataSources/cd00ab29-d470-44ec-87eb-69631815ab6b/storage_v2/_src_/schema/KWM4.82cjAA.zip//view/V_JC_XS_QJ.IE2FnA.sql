create view V_JC_XS_QJ as
SELECT JQ.QJID,
       JQ.XSID,
       JQ.BJID,
       JQ.SQLX,
       DECODE(JQ.SQLX, '1', '事假', '2', '病假') SQLXMC,
       JQ.QJYY,
       JQ.KSSJ,
       JQ.JSSJ,
       JQ.SHJG,
       DECODE(JQ.SHJG, '1', '审核通过', '2', '审批中', '0', '驳回') SHJGMC,
       JQ.SHYJ,
       JQ.STATE,
       JX.XM,
       JX.BNXH,
       JX.XBMC,
       JCL.BJMC
  FROM JC_XS_QJ JQ
  LEFT JOIN JC_XS JX
    ON JQ.XSID = JX.XSID
   AND JX.XSZT = '1'
  LEFT JOIN JC_CLASS JCL
    ON JQ.BJID = JCL.BJID
   AND JCL.BJZT = '1'
 WHERE JQ.STATE = '1'
/

