create view V_JC_WJDC_TPL as
select t1.TPL_ID,t1.TPL_TITLE,t1.TPL_DESC,t1.ORG_ID,t1.TPL_TYPE,t1.XZR,t1.XZSJ,t1.GXR,t1.GXSJ,t1.APP_ID,t1.TPL_YXZT,t1.ywlx,t2.ORG_MC,t3.APP_MC,t4.WJ_TPL_ID
from JC_WJDC_TPL t1
left join JC_ORG t2 on t1.ORG_ID = t2.ORG_ID
left join JC_APP t3 on t1.APP_ID = t3.APP_ID
left join (select distinct WJ_TPL_ID from JC_WJDC where WJ_YXZT = '1') t4 on t4.WJ_TPL_ID = t1.TPL_ID
where t1.TPL_YXZT = 1
/

