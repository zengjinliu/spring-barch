create view V_ZS_XQFXX as
select a.org_id,b.org_dm xxdm,b.org_mc xxmc,a.ISLOCK,a.ISNEW,
decode(a.ISLOCK,'1','是','否') ISLOCKMC,a.ISNEW ISNEWMC
from zs_xqf a
inner join jc_org b on a.org_id=b.org_id
/

