create view V_JC_ROLE_DJ as
select t.role_id,
t.role_mc,
t.role_desc,
t.role_state,
t.xzr,
t.xzsj,
t.gxr,
t.gxsj,
t.org_id,
t.role_yxqx_start,
t.role_yxqx_end,
t.is_visitor,
t.app_id,
t.role_orderid,
t.issys,
t.syfw,a.role_dj from jc_role t
left join jc_role_dj a on t.role_id=a.role_id
/

