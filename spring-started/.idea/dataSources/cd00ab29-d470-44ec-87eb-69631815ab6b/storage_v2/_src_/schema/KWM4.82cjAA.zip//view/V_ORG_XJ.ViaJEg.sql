create view V_ORG_XJ as
select a.xxcode,a.xxname,a.xxid,a.dwlx,a.xxlx_c,a.bxms_c,b.org_id
from emis.a_school a
left join zs_xj_org b on b.xj_org_id=a.xxid
where nvl(a.used,'Y')<>'N'
/

