create view V_JC_JS_XX as
SELECT t1.jsxx_id,
       t1.js_id,
       t1."STATUS",
       t1."XZR",
       t1."GXR",
       t1."XZSJ",
       t1."GXSJ",
       t1."XLM",
       t1."XLGJ",
       t1."SXZY",
       t1."SFSF",
       t1."RXNY",
       t1."BYNY",
       t1."XWCC",
       t1."XWMC",
       t2.dmmx_mc  dmmx_GJDQ_mc,
       t3.dmmx_mc  dmmx_SFST_mc,
       t4.dmmx_mc  dmmx_XWCC_mc,
       t5.dmmx_mc  dmmx_XWMC_mc,
       t6.dmmx_mc  dmmx_XLMC_mc
  FROM JC_JS_XX T1
  LEFT JOIN JC_DMMX T2
    ON T1.XLGJ = T2.DMMX_CODE
   AND T2.DM_CODE = 'DM_GJDQ'
  LEFT JOIN JC_DMMX T3
    ON T1.SFSF = T3.DMMX_CODE
   AND T3.DM_CODE = 'DM_SFBZ'
  LEFT JOIN JC_DMMX T4
    ON T1.XWCC = T4.DMMX_CODE
   AND T4.DM_CODE = 'DM_XWCC'
  LEFT JOIN JC_DMMX T5
    ON T1.XWMC = T5.DMMX_CODE
   AND T5.DM_CODE = 'DM_XWMC'
  LEFT JOIN JC_DMMX T6
    ON T1.XLM = T6.DMMX_CODE
   AND T6.DM_CODE = 'DM_XL'
/

