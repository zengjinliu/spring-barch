create view V_ZS_XQF_YHF as
select a.fwid,a.xzsj,b.fwbm,b.fwdz,b.ldid,b.ldmc,b.ldmc2,b.lddm,b.jdid,b.jdmc,b.org_id orgid,a.org_id,
e.org_mc xxmc,f.ORG_DM,f.ORG_MC,b.bz
from zs_xqf_hf a
inner join xqf_fw b on b.fwid=a.fwid and b.yxzt='1'
inner join jc_org e on a.org_id=e.org_id and e.org_state='1'
inner join jc_org f on f.org_id=b.org_id and f.org_state='1'
/

