create view V_JC_JS_KY_KT_CJ as
SELECT zs.jsky_id as zsid,t1.jsky_id,t1.js_id,t1.xzr,t1.xzsj,t1.gxr,t1.gxsj,t1.status,t1."XMLX",t1."XMMC",t1."XMPZH",t1."XKLY",t1."XMJFED",t1."KSNY",t1."JSNY",t1."BRJS",t1."BRPM",t1."XMWTDW",t1."XMLY",t2.dmmx_mc dmmx_XMLX_mc,t3.dmmx_mc dmmx_BRJS_mc,t4.dmmx_mc dmmx_XMLY_mc,t5.dmmx_mc dmmx_BRPM_mc FROM JC_JS_KY_KT_CJ T1
LEFT JOIN jc_js_ky_kt zs ON T1.JSKY_ID = zs.jsky_id
LEFT JOIN JC_DMMX T2 ON T1.XMLX = T2.DMMX_CODE AND T2.DM_CODE = 'DM_XMLX'
LEFT JOIN JC_DMMX T3 ON T1.BRJS = T3.DMMX_CODE AND T3.DM_CODE = 'DM_BRJS'
LEFT JOIN JC_DMMX T4 ON T1.XMLY = T4.DMMX_CODE AND T4.DM_CODE = 'DM_XMLY'
LEFT JOIN JC_DMMX T5 ON T1.BRPM = T5.DMMX_CODE AND T5.DM_CODE = 'DM_BRPM'
/

