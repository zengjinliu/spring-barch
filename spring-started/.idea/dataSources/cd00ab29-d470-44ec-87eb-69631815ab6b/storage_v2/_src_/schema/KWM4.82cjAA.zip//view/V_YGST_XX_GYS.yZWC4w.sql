create view V_YGST_XX_GYS as
select a."XXGYSID",a."XXID",a."GYSID",a."APP_ID",a."ZMWJ",a."KSRQ",a."JSRQ",
fn_date_tostrformat(a."KSRQ",'yyyy-MM-dd') KSSJ,
fn_date_tostrformat(a."JSRQ",'yyyy-MM-dd') JSSJ ,a."XZR",a."XZSJ",a."GXR",a."GXSJ",a."YXZT",
decode(sign(FN_TO_DATE(to_char(FN_SYSDATE(),'yyyy-mm-dd'))-a.JSRQ),1,'-1',0,'1',-1,
decode(sign(FN_TO_DATE(to_char(FN_SYSDATE(),'yyyy-mm-dd'))-a.KSRQ),1,'1',0,'1',-1,'-1'   ) ) state from ygst_xx_gys a
/

