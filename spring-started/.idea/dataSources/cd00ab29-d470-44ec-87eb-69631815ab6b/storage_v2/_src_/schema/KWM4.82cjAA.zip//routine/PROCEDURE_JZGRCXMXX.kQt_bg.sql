create procedure procedure_jzgrcxmxx -- 创建存储过程 教职工人才项目信息
  as
  tbsj date;
  begin
  select max(time_bz) into tbsj from gz_sjjh.JS_TB_BIZ_JZGRXRCXMXX;
  delete from JC_JS_RC b where exists   (select 1 from  gz_sjjh.JS_TB_BIZ_JZGRXRCXMXX a where a.id=b.jsrc_id and a.TIME_BZ> ( select c.updatetime from JC_DATA_TIME c  where c.model_type = 'JC_JS_RC'));
  insert into JC_JS_RC b (jsrc_id,JS_ID,RCXMMC,RXNF,STATUS,XZR,XZSJ)
  select j.id,
      JB.JSJB_ID,
      (select d1.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d1 where d1.zdbs='RXRCXMMC' and d1.zdxbs = j.RXRCXMMC)RXRCXMMC,
      j.rxny,
      '1',
      'SJTB',
      sysdate
  from gz_sjjh.JS_TB_BIZ_JZGRXRCXMXX j
  join JC_JS_JB JB
  on j.JSID = JB.JSJB_ID
  where  j.SFSC = '0' and j.shzt='2' and j.TIME_BZ>(  select c.updatetime from JC_DATA_TIME c  where c.model_type = 'JC_JS_RC');
  update JC_DATA_TIME set updatetime = tbsj where model_type = 'JC_JS_RC';

   exception when others then
  dbms_output.put_line(sqlcode||'>>>>>>' || sqlerrm);
  commit;
end procedure_jzgrcxmxx;
/

