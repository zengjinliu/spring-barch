create view V_SMBD_MAX_TIME as
select a.jgid,a.xsid,a.bmdm,a.shjg,a.shjgmx,a.shr,a.shsj,b.bmid,b.ORGID ORG_ID,
    (select APP_ID from ZS_XSXX where XSID = a.XSID) APP_ID
from smbd_shjg a
left join smbd_bmsz b on a.BMID=b.BMID
where b.status='1' AND b.ISZJGPD = '1' and exists(select 1 from ZS_XSXX where XSID = a.XSID)
/

