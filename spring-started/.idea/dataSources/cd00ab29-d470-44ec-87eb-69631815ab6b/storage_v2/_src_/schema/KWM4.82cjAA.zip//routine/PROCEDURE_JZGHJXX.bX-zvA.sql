create procedure procedure_jzghjxx -- 创建存储过程 教职工获奖信息
  as
  tbsj date;
  begin
  select max(time_bz) into tbsj from gz_sjjh.JS_TB_BIZ_JZGJXKYHJXX;
  delete from JC_JS_KY_JL b where exists   (select 1 from  gz_sjjh.JS_TB_BIZ_JZGJXKYHJXX a where a.id=b.jsky_id and a.TIME_BZ> ( select c.updatetime from JC_DATA_TIME c  where c.model_type = 'JC_JS_KY_JL'));
  insert into JC_JS_KY_JL b (JSKY_ID,JS_ID,HJNY,JLMC,JLDJ,JLQTDJ,BRPM,SJGJ,SJDW,JLLB,STATUS,XZR,XZSJ)
  select j.id,
      JB.JSJB_ID,
      j.hjny,
      j.jlmc,
      (select d1.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d1 where d1.zdbs='JLDJ' and d1.zdxbs = j.jldj)jldj,
      (select d2.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d2 where d2.zdbs='JLQTDJ' and d2.zdxbs = j.JLQTDJ)JLQTDJ,
      (select d3.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d3 where d3.zdbs='BRPM' and d3.zdxbs = j.BRPM)BRPM,
      (select d4.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d4 where d4.zdbs='SJGJDQ' and d4.zdxbs = j.SJGJDQ)SJGJDQ,
      j.Sjdw,
      (select d5.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d5 where d5.zdbs='JLLB' and d5.zdxbs = j.JLLB)JLLB,
      '1',
      'SJTB',
      sysdate
  from gz_sjjh.JS_TB_BIZ_JZGJXKYHJXX j
  join JC_JS_JB JB
  on j.JSID = JB.JSJB_ID
  where  j.SFSC = '0' and j.shzt='2' and j.TIME_BZ>(  select c.updatetime from JC_DATA_TIME c  where c.model_type = 'JC_JS_KY_JL');
  update JC_DATA_TIME set updatetime = tbsj where model_type = 'JC_JS_KY_JL';

   exception when others then
  dbms_output.put_line(sqlcode||'>>>>>>' || sqlerrm);
  commit;
end procedure_jzghjxx;
/

