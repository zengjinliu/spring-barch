create view V_JC_JG_NOSH as
SELECT "JGID","GH","XM","YWXM","XMPY","CYM","XBM","CSRQ","CSDM","JG","MZM","GJDQM","SFZJLXM","SFZJH","HYZKM","GATQWM","ZZMMM","JKZKM","XYZJM","XXM","ZP","SFZJYXQ","SFDSZN","YZBM","TXDZ","DH","YDDH","CZDH","DZXX","WLDZ","JSTXH","XZR","XZSJ","GXR","GXSJ","STATE","CSD","GZDW" from jc_jg_cj cj
where cj.state!='4' and EXISTS (SELECT 1 FROM jc_js_sh sh WHERE cj.jgid=sh.js_id and (sh.sh_zt=0 or sh.sh_zt=3))
/

