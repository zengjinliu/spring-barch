create view V_GDSJCJ_XJBL as
select a.xsid,a.xxbsm,a.xm,a.xb,a.csrq,a.sfzjlx,a.sfzjh,a.hkszdm,a.rxny,a.jtzz,a.xzsj,b.org_mc xxmc,a.org_id,
case when exists (select 1 from gdsjcj_xjbl_zz b where b.xsid=a.xsid) then 1 else 0 end iszz
from gdsjcj_xjbl a
inner join jc_org b on a.xxbsm=b.org_dm and b.org_state='1'
/

