create procedure pro_dz_tj_pgjd
is
begin
  INSERT INTO DZ_TJ_PGJD (CUR_DATE,STATU_DTX,STATU_YTXWSB,STATU_YSBWSH,STATU_SHZ,STATU_SHWC,PCID)
  --TO_DATE(TO_CHAR(CUR_DATE,'yyyy-MM-dd'),'yyyy-MM-dd'), 
  SELECT TO_DATE(TO_CHAR(sysdate-1,'yyyy-MM-dd'),'yyyy-MM-dd'),
  (select COUNT(MBID) from dz_pgmb dpb1 where dpb1.pcid = dpb.pcid and dpb1.status = 0),
  (select COUNT(MBID) from dz_pgmb dpb1 where dpb1.pcid = dpb.pcid and dpb1.status = 1),
  (select COUNT(MBID) from dz_pgmb dpb1 where dpb1.pcid = dpb.pcid and dpb1.status = 2),
  (select COUNT(MBID) from dz_pgmb dpb1 where dpb1.pcid = dpb.pcid and dpb1.status = 3),
  (select COUNT(MBID) from dz_pgmb dpb1 where dpb1.pcid = dpb.pcid and dpb1.status = 4),
  DPB.PCID  
  FROM DZ_PGMB dpb LEFT JOIN DZ_PC DPC ON DPC.PCID = DPB.PCID
  --自评开始到审核结束
  WHERE DPC.Z_STARTTIME <= SYSDATE AND DPC.S_ENDTIME >= SYSDATE 
  GROUP BY dpb.PCID;
end pro_dz_tj_pgjd;
/

