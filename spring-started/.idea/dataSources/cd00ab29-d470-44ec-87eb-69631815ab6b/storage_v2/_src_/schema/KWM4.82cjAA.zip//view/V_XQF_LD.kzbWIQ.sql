create view V_XQF_LD as
select LDID,LDDM,LDMC,LDMC2,a.JDID,A.ORG_ID,a.YXZT,a.xzr,a.xzsj,A.JDMC
JDMC
from xqf_ld a
where a.yxzt='1'
/

