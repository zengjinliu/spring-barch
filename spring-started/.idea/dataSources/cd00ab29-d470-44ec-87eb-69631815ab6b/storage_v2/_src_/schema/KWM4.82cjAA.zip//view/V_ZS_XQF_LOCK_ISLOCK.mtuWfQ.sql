create view V_ZS_XQF_LOCK_ISLOCK as
select a.ORG_ID hf_xxid,a.fwid,a.xzsj,b.fwbm,b.fwdz,c.ldid,c.ldmc,c.ldmc2,c.lddm,d.jdid,d.jdmc,d.jddm,b.ORG_ID orgid,a.org_id,
e.lock_id,to_char(e.locktime,'yyyy-mm-dd hh24:mi:ss') locktime,e.cqr,e.cqrsfzh,e.xm,e.sfzjh,e.xsid,
to_char(e.unlocktime,'yyyy-mm-dd hh24:mi:ss') unlocktime,nvl(e.status,'-1') status,e.xxid lock_xxid,e.xxmc,e.bz,
f.dmmx_mc status_n,g.org_mc hf_xxmc,h.GMB
 from zs_xqf_lock e
left join zs_xqf_hf a on e.fwid=a.fwid and e.xxid=a.org_id
inner join xqf_fw b on b.fwid=a.fwid and b.yxzt='1'
left join jc_org g on e.xxid=g.org_id and g.org_state='1'
left join zs_xxxx h on h.org_id=g.org_id
left join xqf_ld c on c.ldid=b.ldid and c.yxzt='1'
left join xqf_jd d on d.jdid=c.jdid and d.yxzt='1'
left join JC_DMMX f on nvl(e.status,'-1')=f.dmmx_code and f.dm_code='DM_LOCK' and f.dmmx_state='1'
/

