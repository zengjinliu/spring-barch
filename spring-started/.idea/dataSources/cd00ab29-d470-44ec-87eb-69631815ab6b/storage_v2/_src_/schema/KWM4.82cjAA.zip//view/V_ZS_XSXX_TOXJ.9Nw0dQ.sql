create view V_ZS_XSXX_TOXJ as
select
A.XSID,A.XM,A.SFZJLXM,A.SFZJH,A.PWD,A.LSH,A.JT_SFZJH1,A.JT_SFZJH2,A.JT_LXDH1,A.JT_LXDH2,A.HKXZM,A.HJLXM,
A.CSRQ,A.JT_YLBXYS1,A.JT_YLBXYS2,A.JT_YILBXYS1,A.JT_YILBXYS2,A.JT_SBLJYS1,A.JT_SBLJYS2,A.ZF_ISSFZH2,A.CQRGX,A.JT_QRSZSJ1,A.JT_QRSZSJ2,
A.ZF_CHZRGX,A.ZF_ZLYT,A.ZF_ISXQ,A.ZF_ISWFZM,A.ZF_ZLLJYS,A.ZF_JHTBAH,A.ZF_JHTBARQ,A.ZF_JHTCHZR,ZF_HJISQR,
A.FWID,A.JT_SBFZDW1,A.JT_SBFZDW2,A.ZF_ISKFZM,A.ZF_KFZMYS,A.XZSJ,A.XZR,A.JFMX,A.XBM,A.JT_XM1,A.JT_XM2,A.YHXQJF,A.XQJF,
A.ZZZH,A.MZM,A.CSD,A.JG,A.HKSZD,A.XZZ,A.TXDZ,A.JTZZ,A.LXDH,A.JDFSM,A.SFYHDX,A.HKBHZ,
A.HKSSPCS,A.HKXXDZ,A.HZGX,A.YZBM,A.ZZMMM,A.GJDQM,A.JKZK,A.XWLB,A.SFDQ,A.SFLSETM,A.GATQWM,A.SFSQZNM,A.SFSGXQJYM,
A.SFGE,A.SFLSHYFZN,A.BYXXBZ,A.BYXXMC,A.SFFCTP,A.SFBL,A.BLYY,A.FCLB,A.CQR,A.CHZR,A.CQR_SFZJH,A.FCZH,A.FCFZDW,A.CZR,A.ZLJSRQ,
A.FCFE,A.ZLBADW,A.JT_RELAT1,A.JT_SFZJLX1,A.JT_MZ1,A.JT_HKSZD1,A.JT_GZDW1,A.JT_SBDNH1,
A.JT_RELAT2,A.JT_SFZJLX2,A.JT_MZ2,A.JT_HKSZD2,A.JT_GZDW2,A.JT_SBDNH2,A.JT_HJLXM1,A.JT_HJLXM2,A.DXQID,
A.JT_ZSJZNX1,A.JT_ZSJZNX2,A.JS_QK,A.JS_FZBSC,A.JS_FZDW,A.ZF_JTSSDWMC,A.NJDM,A.ZF_ZLMJ,A.JT_JYLX1,A.JT_JYLX2,
A.JT_CBRGX,A.JT_CBR,A.JT_CBRSFZJH,A.SQLB,A.JT_JZZH1,A.JT_JZZH2,A.XQJF_JS,A.ZF_OLDFCLB,A.BYXXLB,A.JS_GZSH,
A.ZF_FCQBM,A.ZF_FCQMC,A.ZF_JDMC,A.ZF_LDMC,A.JT_ISJZZH1,A.JT_ISJZZH2,
A.LOCKID,A.ZF_HKSFYQ,A.XZSJ XZSJ2,A.TSBJ,A.ZF_BADWBSC,A.JT_CBRSFZJH2,A.JT_CBR2,
A.YHJFGXSJ,A.YHJFGXR,A.ZXTBLDID,A.HJLXMC,A.JT_HJLX1,A.JT_HJLX2,
JT_ZYZGDM1,JT_ZYZGBH1,JT_WHCDDM1,JT_WHCDBH1,JT_WHCDBGBH1,JT_BYSJ1,JT_BYXXMC1,
JT_ZYZGDM2,JT_ZYZGBH2,JT_WHCDDM2,JT_WHCDBH2,JT_WHCDBGBH2,JT_BYSJ2,JT_BYXXMC2,
A.JFXM,A.ZF_YWFC,A.JFX_JHR,A.JFX_JYORWH,A.JFX_JYORWH2,A.XB,
'' ORG_DM1,'' YDDXQJF1,'' YDDXQJF2,'' YDDXQJF3,'' YDDXQJF4,
A.SQXX_XH1 XH,A.SQXXID1,A.SQXXID1 ORG_ID,A.SQXXMC1,A.SQXX_XH1 ORG_ORGDERID1,
A.SQXX_XH2 XH2,A.SQXXID2,A.SQXXMC2,A.SQXX_XH2 ORG_ORGDERID2,
A.SQXX_XH3 XH3,A.SQXXID3,A.SQXXMC3,A.SQXX_XH3 ORG_ORGDERID3,
A.SQXX_XH4 XH4,A.SQXXID4,A.SQXXMC4,A.SQXX_XH4 ORG_ORGDERID4,
A.SQXX_XH5 XH5,A.SQXXID5,A.SQXXMC5,A.SQXX_XH5 ORG_ORGDERID5,
A.SQXX_XH6 XH6,A.SQXXID6,A.SQXXMC6,A.SQXX_XH6 ORG_ORGDERID6,
A.SQXX_XH7 XH7,A.SQXXID7,A.SQXXMC7,A.SQXX_XH7 ORG_ORGDERID7,
A.SQXX_XH8 XH8,A.SQXXID8,A.SQXXMC8,A.SQXX_XH8 ORG_ORGDERID8,
A.SQXX_XH9 XH9,A.SQXXID9,A.SQXXMC9,A.SQXX_XH9 ORG_ORGDERID9,
A.SQXX_XH10 XH10,A.SQXXID10,A.SQXXMC10,A.SQXX_XH10 ORG_ORGDERID10,
A.SHZT,A.SHXX,A.SHR,A.SHSJ,A.SHZTMC,A.SFCSSJ,nvl(ZJG,'0') ZJG,nvl(A.ZJGMC,'未审核') ZJGMC,A.HKXZMC,A.SFZJLXMC,
A.LQZT,A.LQ_ORGID LQXXID,A.LQSJ,A.LQZTMC,A.LQXX,A.YLQZT,A.YLQZTMC,A.YLQXX,A.YLQ_ORGID YLQXXID,
A.ZCZTMC,A.ZCZT,A.ZCR,A.ZCSJ,A.DXQ_MC,
decode(a.njdm,'11','小学一年级','12','小学二年级','13','小学三年级','14','小学四年级','15','小学五年级','16','小学六年级','21','初中一年级','22','初中二年级','23','初中三年级','31','高中一年级','32','高中二年级','33','高中三年级','41','大学一年级','42','大学二年级','43','大学三年级','44','大学四年级','01','小班','02','中班','03','大班','04','大大班') NJMC,
A.HZGXMC,A.JT_RELATMC1,A.JT_RELATMC2,FCFEMC,A.FCLBMC,A.GJDQMC,A.MZMC,
A.JT_HJLXMC1,A.JT_HJLXMC2,A.JT_MZMC1,A.JT_MZMC2,A.JT_SFZJLXMC1,A.JT_SFZJLXMC2,
A.ZF_OLDFCLBMC,A.JDFSMC,'' ZHXWLB,ZF_ISSFZH2 SFCXJFJS,A.JT_ZYZGMC1,A.JT_WHCDMC1,A.JT_ZYZGMC2,A.JT_WHCDMC2,
A.JT_JZZHLJYS,A.APP_ID,A.YHDXM,
A.YHDXZSHM,A.YHDXZSFZDW,A.SFECBM,A.DQCL,nvl(a.SXXJTJL,'3') SXXJTJL,nvl(a.SFCZXC,'0') SFCZXC,nvl(a.SXXJTFS,'1') SXXJTFS,A.SXXJTFSMC,A.TC,A.SFDSZN,
A.SFSQZZ,A.SFXSYB,A.CJLX,A.CJLXMC,A.SBJD,A.SBJDMC,A.SFYZFGMXW,A.SFZXS,A.RXFS,A.RXFSMC,A.JT_ZW1,A.JT_ZW2,
A.LQMX,A.YLQMX,A.SFTZLQ,A.SFCZXCMC,A.JKZKMC,A.SFLSETMC,A.SFSGXQJYMC,A.GATQWMC,A.SFSQZNMC,A.SFGEMC,A.SFDSZNMC,
A.SFSQZZMC,A.SFXSYBMC,A.SFYZFGMXWMC,A.SFLSHYFZNMC,A.SFZXSMC,A.SFDQMC,A.RXLBMC,A.RXLBDM,
A.ZF_QDDX,A.ZF_CQR1,A.ZF_CQR_SFZJH1,A.RXZMBH,A.YHDXBH,A.YHDXFZDW,A.DDM,A.FCLB_OTHER,
A.HJDZ_QU_ID,A.HJDZ_QU_MC,A.HJDZ_JD_ID,A.HJDZ_JD_MC,A.HJDZ_SQ_ID,A.HJDZ_SQ_MC,A.HJDZ_XXXX,A.HJDZ_SQXX,HJDZ_SQXX_MC,
A.HJDZ_QU_MC||A.HJDZ_JD_MC||A.HJDZ_SQ_MC HJDZ_QC,
A.JZDZ_QU_ID,A.JZDZ_QU_MC,A.JZDZ_JD_ID,A.JZDZ_JD_MC,A.JZDZ_SQ_ID,A.JZDZ_SQ_MC,A.JZDZ_XXXX,A.JZDZ_SQXX,JZDZ_SQXX_MC,
A.JZDZ_QU_MC||A.JZDZ_JD_MC||A.JZDZ_SQ_MC JZDZ_QC,
A.SFTCS,A.TCZT,A.QUSHZT,A.QUSHXX,A.QUSHR,A.QUSHSJ,A.DRXJZT,A.DRXJR,A.DRXJSJ,A.QUSHZTMC,A.DRXJZTMC,
decode(NJDM,'11','幼儿园','21','小学') BYXXDETAIL,case when DXQID is null then '否' else '是' end ISDXQ ,
decode(SFYHDX,'1','是','0','否','') SFYHDXMC,decode(ZF_ISWFZM,'1','是','0','否','') ZF_ISWFZMMC,
decode(ZF_ISXQ,'1','是','0','否','') ZF_ISXQMC,case when SFBL='1' then '补申请录入' else '正常录入' end SFBLMC,
decode(ZF_ISSFZH2,'Y','是','0','否','') SFCXJFJSMC,decode(JT_JYLX2,'1','社保','2','无','') JT_JYLXMC2,
decode(JT_JYLX1,'1','社保','2','无','') JT_JYLXMC1,decode(ZF_ISWFZM,'1','是','0','否','') ZF_ISWFZMC,
decode(ZF_ISKFZM,'1','是','0','否','') ZF_ISKFZMC,decode(ZF_HJISQR,'1','是','0','否','') ZF_HJISQRMC,decode(SFFCTP,'1','是','0','否','') SFFCTPMC,
A.SFZJCJ SFCJ,decode(A.SFZJCJ,'1','是','否') SFCJMC,BY1,BY2,BY3,BY4,BY5,BY6,BY7,BY8,BY9,BY10,
A.YYID,A.YYSJ_KSSJ,A.YYSJ_JSSJ,A.BMTJ,A.YDDJF1,A.YDDJF2,A.YDDJF3,A.YDDJF4,
A.JT_XZZ1,A.JT_XZZ2,A.ISSDXGJF,
decode(nvl(A.FWID,'00'),'00','自行填报','系统选择') DZLRFS,decode(nvl(A.FWID,'00'),'00','0','1') DZLRFSM,
A.BY_SZDM,A.BY_SZD,A.BY_BJMC,A.BY_XSZW,A.GZ_XJCODE,A.QGXJH,A.SFSQZS,A.SFXYZZC,
A.JT_SFCYJZZ1,A.JT_SFCYJZZ2,A.ZF_BADWJWH,ZF_BADWBSCMC,
decode(A.SFSQZS,'0','否','1','是') SFSQZSMC,
decode(A.SFXYZZC,'0','否','1','是') SFXYZZCMC,
decode(A.JT_SFCYJZZ1,'0','否','1','是') JT_SFCYJZZMC1,
decode(A.JT_SFCYJZZ2,'0','否','1','是') JT_SFCYJZZMC2,
decode(A.JT_ISJZZH1,'0','否','1','是') JT_ISJZZHMC1,
decode(A.JT_ISJZZH2,'0','否','1','是') JT_ISJZZHMC2,
decode(A.ZF_YWFC,'02','否','01','是') ZF_YWFCMC,
A.XQJF+nvl(A.YDDJF1,0) XQJF1,A.XQJF+nvl(A.YDDJF2,0) XQJF2,A.XQJF+nvl(A.YDDJF3,0) XQJF3,A.XQJF+nvl(A.YDDJF4,0) XQJF4,
B.EXT1,B.EXT2,B.EXT3,B.EXT4,B.EXT5,B.GA_FLAG,B.GA_CWBZ,B.ZF_FLAG,B.ZF_CWBZ,B.ZLS_FLAG,B.ZSL_CWBZ,B.JHRZF_FLAG,B.CJXX,case when A.SQXXID10 IS NOT NULL THEN '1' ELSE '0' END SFSBGYMB,
decode(a.YJDNJ,'11','小学一年级','12','小学二年级','13','小学三年级','14','小学四年级','15','小学五年级','16','小学六年级','21','初中一年级','22','初中二年级','23','初中三年级','31','高中一年级','32','高中二年级','33','高中三年级','41','大学一年级','42','大学二年级','43','大学三年级','44','大学四年级','01','小班','02','中班','03','大班','04','大大班') YJDNJMC,
ZCDQ,YJDXX,YJDNJ,XCODE,YJDQX,YJDXXID,YJDQXMC,decode(SFECBM,'1','是','否') SFECBMMC,--二次报名
--民办招生字段
--decode(a.RXFS,'04','就近入学','01','统一招生考试/普通入学','05','体育特招','06','艺术特招','07','外校转入','08','恢复入学资格','03','民族班','02','保送','99','其他') RXFSMC,
--decode(a.SXXJTFS,'1','步行','2','自行车(含摩托车、电动自行车)','3','公共交通(含城市公交、农村客运、地铁)','4','家长自行接送','5','校车','6','其他') SXXJTFSMC,
--decode(a.SBJD,'0','非随班就读','1','视力残疾随班就读','2','听力残疾随班就读','3','智力残疾随班就读','4','其他残疾随班就读') SBJDMC,
--decode(a.CJLX,'0','无残疾','1','视力残疾','2','听力残疾','3','智力残疾','4','言语残疾','5','肢体残疾','6','精神残疾','7','多重残疾','9','其他残疾') CJLXMC,
--decode(a.JKZK,'1','健康或良好','2','一般或较弱','3','有慢性病','6','残疾','10','视觉障碍','11','听觉障碍','12','智力障碍','13','肢体障碍','14','脑瘫','15','自闭症','16','严重情绪行为障碍','17','学习障碍','18','超常儿童','19','其他障碍') JKZKMC,
decode(a.GATQWM,'01','香港同胞','02','香港同胞亲属','03','澳门同胞','04','澳门同胞亲属','05','台湾同胞','06','台湾同胞亲属','11','华侨','12','侨眷','13','归侨','14','归侨子女','21','归国留学人员','31','非华裔中国人','41','外籍华裔人','51','外国人','99','其他','0','否') GATQWMMC,
--decode(a.SFXSYB,'0','否','1','是') SFXSYBMC,
--decode(a.SFSQZZ,'0','否','1','是') SFSQZZMC,
--decode(a.SFDSZN,'0','否','1','是') SFDSZNMC,
--decode(a.SFCZXC,'0','否','1','是') SFCZXCMC,
--decode(a.SFLSHYFZN,'0','否','1','是') SFLSHYFZNMC,
--decode(a.SFZXS,'0','否','1','是') SFZXSMC,
decode(a.SFLSETM,'0','否','1','是') SFLSETMMC,
decode(a.SFSQZNM,'0','否','1','是') SFSQZNMMC,
decode(a.SFSGXQJYM,'0','否','1','是') SFSGXQJYMMC,
--decode(a.SFGE,'0','否','1','是') SFGEMC,
--decode(a.SFYZFGMXW,'0','否','1','是') SFYZFGMXWMC,
DJBARQ,FZRQ,FZRQ FZRQ2,ZLKSRQ,JT_CBRQ1,JT_CBRQ2,JT_JZZQFRQ1,JT_JZZQFRQ2,ZF_QRSZSJ,ZF_JHTJSRQ,
--学籍数据
nvl((select xj_code from xj_cj_ssxzh where cj_code=a.CSDM),a.CSDM) CSDM,
nvl((select xj_code from xj_cj_ssxzh where cj_code=a.HKSZDM),a.HKSZDM) HKSZDM,
nvl((select xj_code from xj_cj_ssxzh where cj_code=a.JT_HKSZDM1),a.JT_HKSZDM1)JT_HKSZDM1,
nvl((select xj_code from xj_cj_ssxzh where cj_code=a.JT_HKSZDM2),a.JT_HKSZDM2)JT_HKSZDM2,
case when a.FCDZ is not null then a.FCDZ else nvl(a.XZZ,'无') end FCDZ,
case when a.FCDZ is not null then a.FCDZ else nvl(a.XZZ,'无') end FWDZ,
case when a.HJLXM in('01','02','07')
     then decode(a.HKSZDM,'440303','101','440304','102','440305','103','440306','105','440307','106','440308','104','440309','117','440310','118','440311','119','440312','120')
     when a.HJLXM='03' then decode(substr(c.org_dm,0,6),'440201','124','440202','125','440203','126','440204','122','440206','123','440207','127','440208','128','440209','129','440211','130','440212','131')
     when a.HJLXM in('04','05','06') then  decode(a.HJLXM,'04','41','05','42','06','43')
     else '' end X_SZHJ,
case when a.FCLB in('01','02','03','04','05','06','33','39') then '1'
     when a.FCLB in('08','09','17') then '2'
     when a.FCLB in('14','37','38') then '3'
     when a.FCLB in('13') then '4' when a.FCLB in('12') then '10' else '6' end as zfxz,
case when a.FCLB in('01') then '01'
     when a.FCLB in('02') then '02'
     when a.FCLB in('03') then '18' when a.FCLB in('08','09') then '03'
     when a.FCLB in('04') then '16' when a.FCLB in('05') then '17' when a.FCLB in('17') then '13'
     when a.FCLB in('18','29','30','31') then '14' when a.FCLB in('16','26','27','28') then '15' else '06' end as zfxz2,
case when a.js_qk='独生子女' then 'A'
     when (a.js_qk='政策内生育或全面二孩' or a.js_qk='政策内生育' or a.js_qk='政策内或全面二孩') then 'B'
     when (a.js_qk='政策外生育已处理' or a.js_qk='政策外(已征收社会抚养费)' or a.js_qk='政策外(已处理)'
           or a.js_qk='政策外但已接受处理' or a.js_qk='政策外子女（已处理）' or a.js_qk='政策外已接受处理'
           or a.js_qk='政策外生育（未处理）' or a.js_qk='政策外(未处理)'
           or a.js_qk='政策外未接受处理' or a.js_qk='其它情况' or a.js_qk='政策外没有接受处理'
           or a.js_qk='政策外子女（未处理）' or a.js_qk='政策外未接受处理') then 'C' else '' end zns,
case when a.js_qk='独生子女' then 'A'
     when (a.js_qk='政策内生育或全面二孩' or a.js_qk='政策内生育' or a.js_qk='政策内或全面二孩') then 'B'
     when (a.js_qk='政策外生育已处理' or a.js_qk='政策外(已征收社会抚养费)' or a.js_qk='政策外(已处理)'
           or a.js_qk='政策外但已接受处理' or a.js_qk='政策外子女（已处理）' or a.js_qk='政策外已接受处理') then 'C'
     when (a.js_qk='政策外生育（未处理）' or a.js_qk='政策外(未处理)'
           or a.js_qk='政策外未接受处理' or a.js_qk='其它情况' or a.js_qk='政策外没有接受处理'
           or a.js_qk='政策外子女（未处理）' or a.js_qk='政策外未接受处理') then 'D' else '' end djt,
case when a.hjlxm in('01','02','07') then '1' else '0' end xjhjlx,
case when a.jt_hjlxm1 in('01','02','07')
     then decode(a.JT_HKSZDM1,'440303','101','440304','102','440305','103','440306','105','440307','106','440308','104','440309','117','440310','118','440311','119','440312','120')
     when a.JT_HJLXM1='03' then decode(substr(c.org_dm,0,6),'440201','124','440202','125','440203','126','440204','122','440206','123','440207','127','440208','128','440209','129','440211','130','440212','131')
     when a.JT_HJLXM1 in('04','05','06') then  decode(a.JT_HJLXM1,'04','41','05','42','06','43')
     else '' end X_SZHJ1,
case when a.jt_hjlxm2 in('01','02','07')
     then decode(a.JT_HKSZDM2,'440303','101','440304','102','440305','103','440306','105','440307','106','440308','104','440309','117','440310','118','440311','119','440312','120')
     when a.JT_HJLXM2='03' then decode(substr(c.org_dm,0,6),'440201','124','440202','125','440203','126','440204','122','440206','123','440207','127','440208','128','440209','129','440211','130','440212','131')
     when a.JT_HJLXM2 in('04','05','06') then  decode(a.JT_HJLXM2,'04','41','05','42','06','43')
     else '' end X_SZHJ2,
decode(a.FCFE,'1','A','2','B','3','A','4','B','5','B','6','B') XJFCFE,
decode(a.NJDM,'11','X1','12','X2','13','X3','14','X4','15','X5','16','X6','21','C1','22','C2','23','C3','31','G1','32','G2','33','G3') XJNJMC,
decode(a.YJDNJ,'11','X1','12','X2','13','X3','14','X4','15','X5','16','X6','21','C1','22','C2','23','C3','31','G1','32','G2','33','G3') XJYJDNJMC,
decode(substr(a.NJDM,0,1),'1','X','C') XJXDLB,
case when substr(a.HKSZDM,0,2)='44' then decode(a.HKXZM,'1','02','2','01')
     when nvl(substr(a.HKSZDM,0,2),'1')!='44' then decode(a.HKXZM,'1','12','2','11') else '99' end XJHJSY,
decode(a.CJLX,'3','5','4','3','5','4','9','8',a.CJLX) XJCJLX,
decode(a.HKXZM,'1','01','2','02','99') XJHJ_C,
decode(a.JKZK,'1','10','2','20','3','30','6','50','40') XJJKZK,decode(a.ZCDQ,'市内','02','市外','01','') XJZCDQ,
(SELECT SSXDM FROM V_ZS_SSX_LINK SL WHERE SL.SSXMC=a.JG) JGDM
from zs_xsxx a
LEFT JOIN ZS_XSXX_EXT B ON A.XSID = B.XSID
left join jc_org c on a.sqxxid1=c.org_id and c.org_state='1'
/

