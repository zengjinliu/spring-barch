create view V_JCJK_LD_XXXX as
select
jo.org_mc as XXMC,
zx.org_id as XXBM,
zx.xqmc as LDMC,
p.dmmx_mc as XD,
jo2.org_dm as XZQBM
from zs_xq zx
left join zs_xxxx zs on zx.org_id=zs.org_id
left join jc_org jo on jo.org_id=zs.org_id
left join  jc_org_relat jor on zx.org_id = jor.org_id_child
left join jc_org jo2 on jor.org_id=jo2.org_id
left join jc_dmmx p on p.dm_code='DM_JYJD' and zs.xd=p.dmmx_code and p.dmmx_state='1'
where jo.org_state='1' and jo2.org_state='1' and jo2.org_dj='50'
/

