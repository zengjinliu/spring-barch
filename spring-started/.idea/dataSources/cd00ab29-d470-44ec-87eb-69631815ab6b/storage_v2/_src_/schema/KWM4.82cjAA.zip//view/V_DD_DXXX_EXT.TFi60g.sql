create view V_DD_DXXX_EXT as
select DXID,XM,XBM,AGE,XD,trim(XK) XK,XKOTHER,ZW,WORKUNIT,MZM,XW,BH,
       XL,ZY,ZYJSZC,fn_date_tostrformat(BIRTH,'yyyy-MM-dd') BIRTH,fn_date_tostrformat(WORKTIME,'yyyy-MM-dd') WORKTIME,CJNX,DH,EMAIL,JL,ISGZZG
       ,ISLDGLZB,ISKCJXZB,ISJSFZZB,ISXSFZZB,ISXXFZZB,ISBXTJZB,ISDWJSZB,
       ISWSBJZB,ISJYGZZB,ISJFGLZB,YXZT,IMAGE,SFZJH,SFZJLXM,U_ID,DXLXM,
       DECODE (XBM,'1','男','2','女') xbmc,mx1.dmmx_mc as mzmc, mx2.dmmx_mc as XLMC, mx3.dmmx_mc as ZYJSZCMC
    from
   DD_DXXX dx
   left join jc_dmmx mx1 on dx.mzm= mx1.dmmx_code and mx1.dm_code='DM_MZ' and mx1.dmmx_state='1'
   left join jc_dmmx mx2 on dx.XL= mx2.dmmx_code and mx2.dm_code='DM_XLCC' and mx2.dmmx_state='1'
   left join jc_dmmx mx3 on dx.ZYJSZC= mx3.dmmx_code and mx3.dm_code='DM_ZYJSDJ' and mx3.dmmx_state='1'
/

