create view V_ZS_ZSTC as
select a.id tcsq_id,c.before_tclc_id,a.new_tclc_id,a.stuid,
b.xm,b.sfzjlxm,b.sfzjh,to_char(b.csrq,'yyyy-mm-dd') csrq,
c.before_org_id,c.new_org_id,
d.org_mc before_org_id_n,e.org_mc new_org_id_n,c.reason,
c.xzr,c.xzsj,
f.dmmx_mc xb,
be.ga_flag,be.ga_cwbz,b.rxlbdm,b.rxlbmc,b.fclbmc,b.fclb,be.zf_flag,be.zf_cwbz,be.zls_flag,be.zsl_cwbz,be.jhrzf_flag,b.hjdz_xxxx,b.jzdz_xxxx,b.hkxxdz,b.fcdz,be.ext33,be.ext34
from zs_tcsq a
left join zs_xsxx b on a.stuid = b.xsid
left join zs_xsxx_ext be on b.xsid = be.xsid
inner join zs_tclc c on a.id = c.zs_tcsq_id and a.new_tclc_id = c.id
left join jc_org d on c.before_org_id = d.org_id
left join jc_org e on c.new_org_id = e.org_id
left join jc_dmmx f on f.dm_code='DM_XB' and f.dmmx_state = '1' and b.xbm = f.dmmx_code
where a.state = '1'
/

