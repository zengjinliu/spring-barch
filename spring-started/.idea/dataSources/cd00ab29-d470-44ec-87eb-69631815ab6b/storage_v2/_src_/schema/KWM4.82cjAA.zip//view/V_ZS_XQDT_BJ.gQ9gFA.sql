create view V_ZS_XQDT_BJ as
select bj."ORG_ID",bj."MAPDATA",bj."XZR",bj."XZSJ",bj."GXR",bj."GXSJ",bj."POINTX",bj."POINTY" from zs_xqdt_bj bj
/

