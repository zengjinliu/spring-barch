create view V_JC_BATCH as
select (case when A.Starttime>sysdate then '1' when sysdate>A.Endtime then '2' when A.Starttime<sysdate and sysdate<A.Endtime then '3' end)as zt,
 A.BID,A.BMC,A.REMARK,A.XZR,A.XZSJ,A.GXR,A.Org_Id,A.App_Id,
A.GXSJ,A.YWLX,A.MBID,A.STARTTIME,A.ENDTIME,A.BDM,B.Bzmc,A.TARGETTYPE,b.yxzt,
 case when exists(select 1 from jc_pgbz_mb s where s.bid=A.BID ) then '1' else '0' end pcgl_pgbz_mb,
 case when exists(select 1 from tc_hmxs ts where ts.pcid=A.BID ) then '1' else '0' end pcgl_tc_csxm,
 case when exists(select 1 from tc_batch_csxm tb where tb.pcid=A.BID ) then '1' else '0' end pcgl_tc_batch_csxm
 from jc_batch A
 left join jc_pgbz B on B.BZID=A.MBID and B.YXZT='1'
/

