create function FN_TO_DATE_FORMAT(input_string VARCHAR2,format varchar2) return date is kwdate date;
begin
  kwdate := to_date(input_string,format);
return kwdate;
end FN_TO_DATE_FORMAT;
/

