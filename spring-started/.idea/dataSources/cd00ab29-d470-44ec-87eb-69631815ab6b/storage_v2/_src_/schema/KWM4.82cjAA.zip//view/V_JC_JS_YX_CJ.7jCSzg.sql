create view V_JC_JS_YX_CJ as
SELECT zs.jsyx_id as zsid,t1.op_id,t1.jsyx_id,t1.js_id,t1.xzr,t1.xzsj,t1.gxr,t1.gxsj,t1.status,t1."SFYX",to_char(t1.YXKSRQ,'YYYY-MM-DD')as YXKSRQ,to_char(t1.YXJSRQ,'YYYY-MM-DD')as YXJSRQ,t1."YXGJ",t1."YXJGMC",t1."YXXMMC",t1."YXXMDW",t2.dmmx_mc dmmx_YXGJ_mc,t3.dmmx_mc dmmx_SFYX_mc
FROM JC_JS_YX_CJ T1
LEFT JOIN jc_js_yx zs ON T1.JSYX_ID = zs.jsyx_id
LEFT JOIN JC_DMMX T2 ON T1.YXGJ = T2.DMMX_CODE AND T2.DM_CODE = 'DM_GJDQ'
LEFT JOIN JC_DMMX T3 ON T1.SFYX = T3.DMMX_CODE AND T3.DM_CODE = 'DM_SFST'
/

