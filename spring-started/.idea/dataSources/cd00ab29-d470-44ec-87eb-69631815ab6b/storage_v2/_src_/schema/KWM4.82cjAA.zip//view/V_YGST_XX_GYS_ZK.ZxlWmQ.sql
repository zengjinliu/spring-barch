create view V_YGST_XX_GYS_ZK as
select JO.XXGYSZKID,(JO.ZK||'%') ZK ,d.org_mc XXMC,a.gysmc,to_char(b.KSRQ,'yyyy-mm-dd') KSRQ,to_char(b.JSRQ,'yyyy-mm-dd') JSRQ,
c.SCDLMC,jo.app_id,jo.XXID,jo.GYSID,jo.SCDLID,
decode(sign(FN_TO_DATE(to_char(FN_SYSDATE(),'yyyy-mm-dd'))-b.JSRQ),1,'-1',0,'1',-1,
decode(sign(FN_TO_DATE(to_char(FN_SYSDATE(),'yyyy-mm-dd'))-b.KSRQ),1,'1',0,'1',-1,'-1'   ) ) state

from ygst_xx_gys_zk jo left join ygst_gys a on a.GYSID=JO.GYSID
left join ygst_xx_gys b on b.XXGYSID=JO.XXGYSID
left join ygst_scdl c on c.SCDLID=JO.SCDLID AND c.YXZT='1'
left join JC_ORG d on d.ORG_ID=JO.XXID
/

