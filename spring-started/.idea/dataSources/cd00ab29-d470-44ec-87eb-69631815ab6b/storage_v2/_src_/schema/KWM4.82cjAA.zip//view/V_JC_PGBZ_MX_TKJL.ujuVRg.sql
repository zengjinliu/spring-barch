create view V_JC_PGBZ_MX_TKJL as
select m.MXID,m.YWLX,m.SJ,m.PGID,m.TBR,m.ZNZW,m.GRQZ,m.FZ,m.ORG_ID,m.APP_ID,m.XZR,m.XZSJ,m.GXR,m.GXSJ,m.ywsj,u1.u_username tbr_mc,mb.ptype,
mb.PGMC,mb.MB_ORG_ID,mb.U_ID,o1.org_mc MB_ORG_MC,u.u_username MB_USERNAME,b.BID,b.BMC,case when p.BZID is null then bz.bzid else p.BZID end BZID,p.BZMC,o.ORG_MC,
(case when b.Starttime>sysdate then '1' when sysdate>b.Endtime then '2' when b.Starttime<sysdate and sysdate<b.Endtime then '3' end)as ZT,u2.u_username XZRMC
from jc_pgbz_mx m
left join jc_pgbz_mb mb on mb.pgid=m.pgid
left join jc_org o on o.org_id=m.org_id
left join jc_org o1 on o1.org_id=mb.mb_org_id
left join jc_user u on u.u_id=mb.u_id
left join jc_batch b on b.bid=mb.bid
left join jc_pgbz p on p.bzid=b.mbid
left join jc_pgbz bz on bz.bzid=mb.bzid
left join jc_user u1 on u1.u_id=m.tbr
left join jc_user u2 on u2.u_id=m.xzr
where  m.yxzt='1' and mb.yxzt='1' and ( p.yxzt='1' or bz.yxzt='1' or (m.YWLX='TKJL' and mb.bzid is null))
/

