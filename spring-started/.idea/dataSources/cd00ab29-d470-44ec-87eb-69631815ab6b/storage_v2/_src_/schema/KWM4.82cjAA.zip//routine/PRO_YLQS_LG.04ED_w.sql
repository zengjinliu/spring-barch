create PROCEDURE PRO_YLQS_LG IS
  cursor c_list is select * from v_zs_lglq_data v
                  where 
                  nvl(lqzt,'1')<>'2'  
                  and nvl(v.YLQZT,'1')<>'2'
                  and v.lqxxid is null 
                  and v.ylqxxid is null
                  --同一志愿同一积分的，按优惠对象---优享学区---学区户籍---龙岗户籍---深圳市其他区户籍---莞惠户籍---国内非深非莞惠户籍顺序录取
                  order by
                  case when v.yddjf1 > 0 and v.sqxxid1 not in (select xxid from zs_lglq_dxqxx) then v.yddxqjf else v.xqjf end desc,
                  nvl(v.isyhdx,'N') desc,
                  case when v.yddjf1 > 0 and v.sqxxid1 not in (select xxid from zs_lglq_dxqxx) then v.yddjf1 else 0.0 end desc,
                  nvl(v.is_xq,'N') desc,v.x_szhj2,
                  --录取程序中，请去掉：莞惠户籍优先录取的条件；
                  --decode(substr(v.hkszdm,0,4),'4419',1,'4413',1,0) desc,
                  v.js_qk,
                  decode(v.hjlx,'1',v.zfdj),
                  decode(v.hjlx,'1',v.zf_fzdate,to_date('2025-01-01','yyyy-MM-dd')),v.jynx desc,v.zfjb,v.zf_fzdate,v.zf_fzdate2;
  xs c_list%rowtype; --定义变量类型
  TYPE array_contain IS TABLE OF varchar2(32) INDEX BY BINARY_INTEGER;--可变数组
  v_array array_contain;
  v_sqxxid1 varchar2(32);
  v_sqxxid2 varchar2(32);
  v_sqxxid3 varchar2(32);
  v_sqxxid4 varchar2(32);
  v_ylqs number;--已录取数
  v_jhs number;--学校计划数
  v_selxxid varchar2(32);--预录取查询学校id
  v_selxxmc varchar2(100);--预录取查询学校名称
  v_ylqxxid varchar2(32);--预录取学校id
  v_ylqxxmc varchar2(100);--预录取学校名称
  v_ylqzt varchar2(10);--预录取状态
  v_ylqztmc varchar2(10);--预录取状态名称
  i number;
  str_sql varchar2(2000);
  num number;
  v_ylq_dxqxxid varchar2(100);--预录取学校 已录取完成大学id
BEGIN
  --打开游标
  open c_list;
  loop fetch c_list into xs;
    exit when c_list%notfound;
      v_sqxxid1:=xs.sqxxid1;
      v_sqxxid2:=xs.sqxxid2;
      v_sqxxid3:=xs.sqxxid3;
      v_sqxxid4:=xs.sqxxid4;
      v_ylqxxid:='';
      v_ylqxxmc:='';
      v_ylqzt:='1';--预录取状态
      v_ylqztmc:='待录取';
     --可变数组
    if(xs.sqxxid1 is not null) then
        v_array(1):=v_sqxxid1;
    end if;
    if(xs.sqxxid2 is not null) then
        v_array(2):=v_sqxxid2;
    end if;
    if(xs.sqxxid3 is not null) then
        v_array(3):=v_sqxxid3;
    end if;
    if(xs.sqxxid4 is not null) then
        v_array(4):=v_sqxxid4;
    end if;
    i:=1;
    num:=v_array.COUNT;
    FOR i IN 1 .. v_array.COUNT LOOP
      v_ylq_dxqxxid:='';
      v_ylqs:=0;
      v_jhs:=0;
      str_sql:='select (select count(xsid) from v_zs_lglq2 where YLQXXID=a.sqxxid'||i||' and YLQZT=''2'' and sfzs=''0'') ylq,
                       (select nvl(jhs,0) from zs_xxxx where ORG_ID=a.sqxxid'||i||' and APP_ID='''||xs.app_id||''') jhs,
                       a.sqxxid'||i||',a.sqxxmc'||i||' from V_ZS_XSXX_YLQ a 
               where a.xsid='''||xs.xsid||'''';
      execute immediate str_sql into v_ylqs,v_jhs,v_selxxid,v_selxxmc;
      if(v_ylqs<v_jhs)then--录取数小于计划数
          v_ylqxxid:=v_selxxid;
          v_ylqxxmc:=v_selxxmc;
          v_ylqzt:='2';
          v_ylqztmc:='已录取';
          --select * from zs_dxq_mx b where exists (select 1 from zs_dxq a where a.dxq_id=b.dxq_id and a.org_id='b3c2fbca21a24a8e88d493fe3f5c781a');
          /*
          496FFFE16D0A5558E053BC09A8C0A5ED
          496FFFE16D2C5558E053BC09A8C0A5ED
          4de8828a16684f23a0f86a534cfa2549
          496FFFE16D2B5558E053BC09A8C0A5ED
          496FFFE16CEC5558E053BC09A8C0A5ED
          */
          if(v_ylqs+1=v_jhs and (v_ylqxxid='496FFFE16CEC5558E053BC09A8C0A5ED' or v_ylqxxid='496FFFE16D2B5558E053BC09A8C0A5ED' or v_ylqxxid='496FFFE16D0A5558E053BC09A8C0A5ED' or v_ylqxxid='496FFFE16D2C5558E053BC09A8C0A5ED' or v_ylqxxid='4de8828a16684f23a0f86a534cfa2549'))then
             v_ylq_dxqxxid:=v_ylqxxid;
          end if;
          EXIT;
      end if;
    END LOOP;
    UPDATE ZS_XSXX a SET YLQZT=v_ylqzt,YLQ_ORGID=v_ylqxxid, YLQXX=v_ylqxxmc,YLQR='SYS',YLQZTMC=v_ylqztmc,YLQSJ=FN_SYSDATE() WHERE a.XSID=xs.xsid;
    commit;
    if(v_ylq_dxqxxid is not null)then
        insert into zs_lglq_dxqxx(xxid) values(v_ylq_dxqxxid);
        commit;
        EXIT;
    end if;
    v_array.DELETE;
  end loop;
  close c_list;
  if(v_ylq_dxqxxid is not null)then
        PRO_YLQS_LG();
  end if;
end PRO_YLQS_LG;
/

