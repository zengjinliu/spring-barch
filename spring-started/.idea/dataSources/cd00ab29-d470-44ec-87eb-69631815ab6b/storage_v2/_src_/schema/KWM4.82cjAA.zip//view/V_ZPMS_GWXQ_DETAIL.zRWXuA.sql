create view V_ZPMS_GWXQ_DETAIL as
select t.bdwpw1_xm,
       t.bdwpw1_xk,
       t.BDWPW1_SJ,
       t.bdwpw2_xm,
       t.bdwpw2_xk,
       t.BDWPW2_SJ,
       t.bdwpw3_xm,
       t.bdwpw3_xk,
       t.BDWPW3_SJ,
       t.bdwpw4_xm,
       t.bdwpw4_xk,
       t.BDWPW4_SJ,
       t.WDWPW2,
       t.WDWPW3,
       t.WDWPW4,

       t.zpdw_ID as ORG_ID,
       p1.pw_xm     as xm1,
       p1.sxzy      as sxzy1,
       p1.sj        as sj1,
       p2.pw_xm     as xm2,
       p2.sxzy      as sxzy2,
       p2.sj        as sj2,
       p3.pw_xm     as xm3,
       p3.sxzy      as sxzy3,
       p3.sj        as sj3,
       p4.pw_xm     as xm4,
       p4.sxzy      as sxzy4,
       p4.sj        as sj4,
       t.bdwpw1,
       t.bdwpw2,
       t.bdwpw3,
       t.bdwpw4,
       t."RJXKHZY",
       t."GWXQ_ID",
       t."ZPJH_ID",
       t."ZPDW_ID",
       t."ZWDM",
       t."GWLX",
       t."GWDJ",
       t."GWMC",
       t."NPRS",
       t."ZPRYLX",
       t."YJS",
       t."BK",
       t."GZGZ",
       t."XLYQ",
       t."XWYQ",
       t."NLYQ",
       t."QTYQ",
       t."BZ",
       t."XZR",
       t."XZSJ",
       t."GXR",
       t."GXSJ",
       t."ZPDWMC",
       t."MSAPSQZT",
       t."MSSJ",
       t."MSDD",
       t."HKSJ",
       t."HKDD",
       t."MSXS"
  from zpms_gwxq t
  left join zpms_pwxx p1
    on p1.pwxx_id = t.WDWPW1
  left join zpms_pwxx p2
    on p2.pwxx_id = t.WDWPW2
  left join zpms_pwxx p3
    on p3.pwxx_id = t.WDWPW3
  left join zpms_pwxx p4
    on p4.pwxx_id = t.WDWPW4
/

