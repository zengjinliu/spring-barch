create view V_JC_JS_GZ_CJ as
SELECT zs.jsgz_id as zsid,t1.op_id,t1.jsgz_id,t1.js_id,t1.xzr,t1.xzsj,t1.gxr,t1.gxsj,t1.status,t1."RZDWMC",t1."RZKSNY",t1."RZJSNY",t1."DWXZLB",t1."RZGW",t2.dmmx_mc dmmx_DWXZLB_mc FROM JC_JS_GZ_CJ T1
LEFT JOIN jc_js_gz zs ON T1.JSGZ_ID = zs.jsgz_id
LEFT JOIN JC_DMMX T2 ON T1.DWXZLB = T2.DMMX_CODE AND T2.DM_CODE = 'DM_DWXZLB'
/

