create view V_ZS_XJ2 as
select
'' XM,
'' SFZJH,
'' xj_xxid,
'' xj_xxmc,
'' XJ_ZXZK,
'' XJ_NJDM,
'' XB,
'' CSRQ,
'' xjh,
'' bydq,
'' org_id,
'' xj_xxdm,
'' gmb,
'' zs_orgmc
from
dual
/

