create view V_JC_ROLE_READ_AUTH as
select "ROLE_ID","PRO_ID" from jc_role_read_auth
/

