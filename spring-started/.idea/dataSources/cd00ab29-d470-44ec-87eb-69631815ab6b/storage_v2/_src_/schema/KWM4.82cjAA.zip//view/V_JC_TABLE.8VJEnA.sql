create view V_JC_TABLE as
select t.table_id,t.table_name,t.table_desc,t.table_order
    from JC_TABLE t
/

