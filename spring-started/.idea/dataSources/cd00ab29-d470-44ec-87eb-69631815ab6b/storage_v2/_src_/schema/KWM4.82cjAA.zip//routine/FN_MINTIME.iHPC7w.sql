create function FN_MINTIME(input_date date,orgid char) return char is kwstr char(32);
begin
  select xq_id into kwstr from ( select xq_id,dateu from (select x.xq_id,abs(input_date-x.xq_startdate) as dateu from jc_xq x where x.org_id=orgid union select x.xq_id,abs(input_date-x.xq_enddate) as dateu from jc_xq x where x.org_id=orgid) a order by dateu )b where rownum=1;
return kwstr;
end FN_MINTIME;
/

