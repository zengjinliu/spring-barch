create procedure procedure_jzgyyzs -- 创建存储过程 教职工医药证书
  as
  tbsj date;
  begin
  select max(time_bz) into tbsj from gz_sjjh.JS_TB_BIZ_JZGGJYYZSXX;
  delete from JC_JS_KY_ZS b where exists   (select 1 from  gz_sjjh.JS_TB_BIZ_JZGGJYYZSXX a where a.id=b.jsky_id and a.TIME_BZ> ( select c.updatetime from JC_DATA_TIME c  where c.model_type = 'JC_JS_KY_ZS'));
  insert into JC_JS_KY_ZS b (JSKY_ID,JS_ID,YYZSMC,SFCGDB,ZSH,BRJS,PZSJ,YXQ,STATUS,XZR,XZSJ)
  select j.id,
      JB.JSJB_ID,
      j.gjyyzsmc,
      (select d1.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d1 where d1.zdbs='SFSDBXCGHXM' and d1.zdxbs = j.SFSDBXCGHXM)SFSDBXCGHXM,
      j.zspjh,
      (select d2.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d2 where d2.zdbs='ZSZBRJS' and d2.zdxbs = j.zszbrjs)zszbrjs,
      case is_date_ymd(j.bbhpzsj) when 1 then  to_date(j.bbhpzsj , 'yyyy-mm-dd hh24:mi:ss') else null end,
      case is_date_ymd(j.yxq) when 1 then  to_date(j.yxq , 'yyyy-mm-dd hh24:mi:ss') else null end,
      '1',
      'SJTB',
      sysdate
  from gz_sjjh.JS_TB_BIZ_JZGGJYYZSXX j
  join JC_JS_JB JB
  on j.JSID = JB.JSJB_ID
  where  j.SFSC = '0' and j.shzt='2' and j.TIME_BZ>(  select c.updatetime from JC_DATA_TIME c  where c.model_type = 'JC_JS_KY_ZS');
  update JC_DATA_TIME set updatetime = tbsj where model_type = 'JC_JS_KY_ZS';

   exception when others then
  dbms_output.put_line(sqlcode||'>>>>>>' || sqlerrm);
  commit;
end procedure_jzgyyzs;
/

