create view V_JC_APP as
select a.APP_ID,a.APP_DM,a.APP_MC,a.APP_BZ,a.APP_KZ,a.APP_ORDER,a.APP_YXZT,a.PRO_ID,a.XZR,to_char(a.XZSJ,'yyyy-mm-dd HH24:mi:ss') XZSJ,
   a.APP_PIC,b.PRO_MC,b.PRO_LEVEL,a.FLDM1,a.FLMC1,a.FLDM2,a.FLMC2
from jc_app a
left join jc_product b on b.pro_id=a.pro_id
where a.app_yxzt='1'
/

