create view V_JC_BJ as
SELECT a.BJID,a.BJMC,a.BH,a.BZRXM,a.BJZT,a.XZR,a.XZSJ,a.GXR,a.GXSJ,
b.orgid ORG_ID,e.ORG_MC,e.ORG_ORDERID,e.ORG_DM,b.JHS,
e.ORG_MC||'('||a.BJMC||')' BJMC_N,b.XX_ORG_ID,b.NJ_ORG_ID,
c.orgid NJORG_ID,f.ORG_MC NJORG_MC,f.ORG_DM NJORG_DM,f.ORG_ORDERID NJORG_ORDERID,
f.org_mc||'('||c.njmc||')' NJMC_N,c.NJID,g.JYJD,g.XJNJDM,
d.org_id XXORG_ID,d.ORG_DM XXORG_DM,d.ORG_MC XXORG_MC,d.ORG_ORDERID XXORG_ORDERID
from JC_BJ a
inner join jc_org_bj b on b.orgid=a.orgid
inner join jc_org e on b.orgid=e.org_id and e.org_state='1'
left join jc_nj c on c.orgid=b.nj_org_id and c.njzt='1'
inner join jc_org_nj g on c.orgid=g.orgid
inner join jc_org f on g.orgid=f.org_id and f.org_state='1'
left join jc_org d on d.ORG_ID=b.xx_org_id and d.org_state='1'
where a.BJZT='1'
/

