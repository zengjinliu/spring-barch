create view V_DZ_ZJZ_GZ as
select dzg.gz_id,dzg.u_id,dzg.mb_org_id,dzg.pcid,dzg.status,to_char(dzg.pgrq,'yyyy-MM-dd') pgrq,dzg.fz,dzg.xzr,dzg.xzsj,dzg.gxr,dzg.gxsj,dzg.org_id,dzg.app_id,
    ju.u_username,dp.pcmc,jo.org_mc mb_org_mc,dp.pid,dpb.mbid,jo.org_orderid,
    (case when(fn_sysdate >= dp.zj_endtime+1) then '3' else
      dzg.status
    end) pgzt
    from dz_zjz_gz dzg
    left join jc_user ju on ju.u_id = dzg.u_id
    left join dz_pc dp on dp.pcid = dzg.pcid
    left join dz_pgmb dpb on dpb.mborg_id = dzg.mb_org_id and dpb.pcid = dzg.pcid
    left join jc_org jo on jo.org_id = dzg.mb_org_id
    where dzg.status > 0
/

