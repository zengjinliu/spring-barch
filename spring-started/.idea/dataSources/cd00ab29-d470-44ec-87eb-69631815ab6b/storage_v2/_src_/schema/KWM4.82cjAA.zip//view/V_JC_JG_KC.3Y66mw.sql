create view V_JC_JG_KC as
select jk.u_id,ju.xm,jj.jgid,
to_char(wm_concat(JK.BJID||'-'||JK.KCDM||'@'||JC.BJMC||'-'||JK.KCMC)) bjkcs
        from jc_kc JK
JOIN JC_CLASS JC ON JC.BJID = JK.BJID and jc.bjzt='1'
left join jc_user ju on ju.u_id= jk.u_id
left join jc_jg jj on ju.u_id= jj.user_id

group by Jk.u_id,ju.xm,jj.jgid order by jk.u_id desc
/

