create view V_JC_XS_YDGL as
select t1.XSID,t1.XM,t1.XBM,t1.SFZJH,t1.XXID,t1.NJID,t1.BJID,t1.XJFH,t3.dmmx_mc dmmx_XB_mc,t4.org_mc "NJMC",t5.ORG_MC "BJMC",t6.xxmc from jc_xs t1
LEFT JOIN JC_DMMX T3 ON T1.XBM = T3.DMMX_CODE AND T3.DM_CODE = 'DM_XB'
left join v_JC_NJ t4 ON t1.NJID = T4.NJID
left join v_jc_bj t5 ON t1.BJID = T5.BJID
left join V_ORG_XX t6 ON t1.XXID = T6.XXID
/

