create FUNCTION CREATE_student_XCODE (
  v_year varchar2,--年份
  v_xd varchar2,--学段 小学3 初中4
  v_xz varchar2,--学制 小学6 初中3
  v_xxcode varchar2--学校代码
)
  return varchar2
is
  v_con varchar2(30);
  v_newxcode varchar2(10);
begin
  v_con:=v_year || v_xd || v_xz;
  select max(xcode) maxxcode into v_newxcode from emis.x_student where xxcode = v_xxcode and xcode like v_con || '%';
  if(v_newxcode is null) then
    v_newxcode:=v_con||'0001';
  else
    v_newxcode:=to_char(to_number(v_newxcode)+1);
  end if;
  return v_newxcode;
end;
/

