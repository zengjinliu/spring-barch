create PROCEDURE PRO_JC_ORG_RELAT_APP20190814(cztype in varchar2,nums out varchar2) authid current_user  is
  cursor dj_list is select * from jc_org_dj a order by a.dj_level;
  djs dj_list%rowtype;
  sql_create varchar2(2000);--创建表语句
  v_zds_tab varchar2(1000); --创建表字段集
  v_zds_ins varchar2(1000); --等级字段的动态集
  V_ISHAVE NUMBER;          --是否需要新增
  V_ISUPDATE NUMBER;        --是否需要修改
  V_ISDELETE NUMBER;        --是否需要删除
  v_insert_d varchar2(50);   --新增时间
  sql_update varchar2(1000); --修改JC_ORG_RELAT_APP语句
  sql_select varchar2(1000); --修改JC_ORG_RELAT_APP语句
begin
     v_zds_tab:='';
     v_zds_ins:='';
     if(cztype='1') then--重新创建表
        open dj_list;
        loop fetch dj_list into djs;
        exit when dj_list%notfound;
        v_zds_tab:=v_zds_tab||',dj'||djs.dj_dm||' varchar2(32)';
        v_zds_ins:=v_zds_ins||','||djs.dj_dm;
        end loop;
        close dj_list;
        --删除表
        execute immediate 'truncate table JC_ORG_RELAT_APP';  
        execute immediate 'drop table JC_ORG_RELAT_APP';
        --创建表
        sql_create:='create table jc_org_relat_app(org_id char(32),org_dj varchar2(3)'||v_zds_tab||',app_id char(32),xzsj date default sysdate)';
        execute immediate sql_create;
        --创建索引
        execute immediate 'create index i_jc_org_relat_app_orgid on jc_org_relat_app(org_id)';
        execute immediate 'create index i_jc_org_relat_app_appid on jc_org_relat_app(app_id)';
        execute immediate 'create index i_jc_org_relat_app_xzsj on jc_org_relat_app(xzsj)';
        open dj_list;
        loop fetch dj_list into djs;
        exit when dj_list%notfound;
             execute immediate 'create index i_jc_org_relat_app_dj'||djs.dj_dm||' on jc_org_relat_app(dj'||djs.dj_dm||')';  
        end loop;
        close dj_list;
     end if;
     
     --先删除有变化的数据 然后新增
     delete jc_org_relat_app e where 
      exists(select 1 from jc_org_relat d
           where exists(
             SELECT 1 FROM JC_APP_ORG A 
             WHERE NOT EXISTS(SELECT 1 FROM JC_ORG_RELAT_APP B WHERE A.APP_ID=B.APP_ID AND A.ORG_ID=B.ORG_ID)
             and exists(select 1 from jc_org c where c.org_id=a.org_id and c.org_state='1') and a.org_id=d.org_id
           )
           and d.org_id_child=e.org_id
      );

      delete jc_org_relat_app d where
      exists(
        select 1 from jc_org_relat c where
        exists(
               select 1 from jc_org_relat_app a where exists(select 1 from jc_org_relat b where b.org_id=a.org_id and a.xzsj<b.xzsj)
               and a.org_id=c.org_id
        )
        and c.org_id_child=d.org_id
      );

      delete jc_org_relat_app e where 
      exists(select 1 from jc_org_relat d
           where exists(
            SELECT 1 FROM JC_ORG_RELAT_APP A 
            WHERE NOT EXISTS(SELECT 1 FROM JC_APP_ORG B INNER JOIN JC_ORG C ON C.ORG_ID=B.ORG_ID WHERE A.ORG_ID=B.ORG_ID AND A.APP_ID=B.APP_ID AND C.ORG_STATE='1')
            and a.org_id=d.org_id
           )
           and d.org_id_child=e.org_id and d.org_id!=d.org_id_child
      );
     
     --新增数据
     SELECT COUNT(A.ORG_ID) INTO V_ISHAVE FROM JC_APP_ORG A 
     WHERE NOT EXISTS(SELECT 1 FROM JC_ORG_RELAT_APP B WHERE A.APP_ID=B.APP_ID AND A.ORG_ID=B.ORG_ID)
     and exists(select 1 from jc_org c where c.org_id=a.org_id and c.org_state='1');
     --查询需要修改的数据
     
     --查询需要删除的数据
     SELECT COUNT(ORG_ID) INTO V_ISDELETE FROM JC_ORG_RELAT_APP A 
     WHERE NOT EXISTS(SELECT 1 FROM JC_APP_ORG B INNER JOIN JC_ORG C ON C.ORG_ID=B.ORG_ID WHERE A.ORG_ID=B.ORG_ID AND A.APP_ID=B.APP_ID AND C.ORG_STATE='1');
          
     IF(V_ISHAVE>0)THEN--新增
          select to_char(sysdate,'yyyy-mm-dd HH24:mi:ss') into v_insert_d from dual;
          insert into jc_org_relat_app(org_id,org_dj,app_id,xzsj) 
          select a.org_id,(select org_dj from jc_org d where d.org_id=a.org_id),a.app_id,to_date(v_insert_d,'yyyy-mm-dd HH24:mi:ss') 
          from JC_APP_ORG A WHERE NOT EXISTS(SELECT 1 FROM JC_ORG_RELAT_APP B WHERE A.APP_ID=B.APP_ID AND A.ORG_ID=B.ORG_ID)
          and exists(select 1 from jc_org c where c.org_id=a.org_id and c.org_state='1');
          open dj_list;
          loop fetch dj_list into djs;
          exit when dj_list%notfound;
              sql_update:='update jc_org_relat_app d set (dj'||djs.dj_dm||')=
              (select b.org_id from jc_app_org a left join jc_org_relat b on b.org_id_child=a.org_id 
               left join jc_org c on c.org_id=b.org_id
               where c.org_state=''1'' and c.org_dj='''||djs.dj_dm||''' 
               and exists(select 1 from jc_app_org e where e.app_id=d.app_id and e.org_id=b.org_id)
               and d.org_id=b.org_id_child and d.app_id=a.app_id and rownum=1)
               where d.xzsj=to_date('''||v_insert_d||''',''yyyy-mm-dd HH24:mi:ss'')';
               execute immediate sql_update;
          end loop;
          close dj_list;	
     END IF;
     
     IF(V_ISDELETE>0) THEN--删除
           --删除不存在的当前应用的机构
           DELETE JC_ORG_RELAT_APP A WHERE NOT EXISTS(SELECT 1 FROM JC_APP_ORG B INNER JOIN JC_ORG C ON C.ORG_ID=B.ORG_ID WHERE A.ORG_ID=B.ORG_ID AND A.APP_ID=B.APP_ID AND C.ORG_STATE='1');
     END IF;
     commit;
     select to_number(nvl(nums,0))+1 into nums from dual;
end PRO_JC_ORG_RELAT_APP20190814;
/

