create function fn_xxlx(input_  char) return char is
  Result char(1);
  v_count int;
begin
   select count(*) into v_count from jc_xx where org_id=input_;
   if v_count>0 then
      select case  xxbxlxm WHEN '211' THEN '1' WHEN '311' THEN '2' WHEN '341' THEN '3' WHEN '345' THEN '3' WHEN '312' THEN '3' ELSE '4' END into Result from jc_xx a  where org_id=input_;
   else
       Result :=4;
   end if;
  return(Result);
end fn_xxlx;
/

