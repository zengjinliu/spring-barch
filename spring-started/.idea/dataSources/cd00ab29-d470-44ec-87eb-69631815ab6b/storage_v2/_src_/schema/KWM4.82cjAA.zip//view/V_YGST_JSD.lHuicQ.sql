create view V_YGST_JSD as
select jo.jsdid,jo.jsdbh,jo.xxgysid,jo.xxid,jo.gysid,a.gysmc, to_char( jo.JSRQ,'yyyy-mm-dd') jsrq,to_char( jo.JSRQ,'yyyy-MM') ny,
jo.zje,jo.zkzje,b.org_mc xxmc,decode(jo.jslx,1,'日结',2,'月结')  jslxmc,jo.jslx,to_char( jo.JSRQ,'yyyy-mm-dd (DAY)') jssj
,jo.bz,jo.xzsj,to_char(jo.xsyl) xsyl,to_char(jo.jssl) jssl,to_char(jo.jdsl) jdsl,jo.xsylje,jo.jsslje,jo.jdslje
from ygst_jsd jo left join ygst_gys a on jo.gysid=a.gysid
left join jc_org b on jo.xxid=b.org_id
/

