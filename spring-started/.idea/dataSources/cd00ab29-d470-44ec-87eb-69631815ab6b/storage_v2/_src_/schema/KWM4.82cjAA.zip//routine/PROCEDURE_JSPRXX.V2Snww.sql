create procedure procedure_jsprxx -- 创建存储过程 聘任信息
  as
   tbsj date;
  begin
  select max(time_bz) into tbsj from gz_sjjh.JS_TB_BIZ_JZGGWPRXX;
  delete from JC_JS_GW b where exists   (select 1 from  gz_sjjh.JS_TB_BIZ_JZGGWPRXX a where a.id=b.jsgw_id and a.TIME_BZ> ( select c.updatetime from JC_DATA_TIME c  where c.model_type = 'JC_JS_GW'));
  insert into JC_JS_GW b (JSGW_ID,JS_ID,GWLB,GWDJ,PRKSNY,SFJR,JRGWLB,JRGWDJ,RZKSNY,STATUS,XZR,XZSJ)
  select j.id,
       JB.JSJB_ID,
      (select d1.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d1 where d1.zdbs='GWLB' and d1.zdxbs = j.GWLB) GWLB,
      (select d2.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d2 where d2.zdbs='GWDJ' and d2.zdxbs = j.GWDJ) GWDJ,
      j.PRKSNY PRKSNY,
      (select d3.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d3 where d3.zdbs='SFJRQTGW' and d3.zdxbs = j.SFJRQTGW) SFJR,
      (select d4.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d4 where d4.zdbs='JRGWLB' and d4.zdxbs = j.JRGWLB) JRGWLB,
      (select d5.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d5 where d5.zdbs='JRGWDJ' and d5.zdxbs = j.JRGWDJ) JRGWDJ,
      j.RZKSNY RZKSNY,
      '1',
      'SJTB',
      sysdate
  from gz_sjjh.JS_TB_BIZ_JZGGWPRXX j
  join JC_JS_JB JB
  on j.JSID = JB.JSJB_ID
  where  j.SFSC = '0' and j.shzt='2' and j.TIME_BZ>(  select c.updatetime from JC_DATA_TIME c  where c.model_type = 'JC_JS_GW');
  update JC_DATA_TIME set updatetime = tbsj where model_type = 'JC_JS_GW';

   exception when others then
  dbms_output.put_line(sqlcode||'>>>>>>' || sqlerrm);
  commit;
end procedure_jsprxx;
/

