create PROCEDURE PRO_BDYH_GETHCBMJG_BY_XSID(p_xsid in char,p_czr in varchar2) IS--计算合成结果（根据学生id）
  cursor c_list is select * from v_smbd_bmshjg v where v.xsid=p_xsid;
  xs c_list%rowtype;
  --部门游标
  cursor c_bmlist(quorgid String) is select * from smbd_bmsz a where a.orgid=quorgid and a.ISHCBM='1' order by a.xh;
  bm c_bmlist%rowtype;
  v_quorgid char(32);--区机构id
  v_xsid char(32);  --获取符合部门审核的学生id
  v_xscount int;--查询学生是否符合的学生总数的into参数
  v_tj varchar2(10000);--各部门条件
  v_selsql varchar2(10000);--查询学生是否符合合成部门的学生信息
  v_ztj varchar2(10000);--子部门条件
  v_zbmid char(32);--子部门id
  v_zbmzt varchar2(2);--子部门状态
  v_selsqlcount2 varchar2(10000);--查询学生符合部门的数量
  v_xscount2 int;--查询学生是否符合的学生总数的into参数
  v_selsql2 varchar2(10000);--查询学生符合部门的学生信息
  v_zlbasjsql varchar2(10000);--查询学生符合部门的学生信息
  v_zlbasj varchar2(20);--租赁登记备案日期
  v_yscode varchar2(100);--原始结果表里面的返回状态
  v_shjgmx1 varchar2(10000);--审核结果明细1
  v_shjgmx2 varchar2(10000);--审核结果明细2
  v_shjgmx3 varchar2(10000);--审核结果明细3
  v_shjgmx  varchar2(10000);--审核结果明细
  v_zlstate varchar2(2);--新租赁是否合格（3月31号之前合格、3月31号之后不合格）
  v_jzlstate varchar2(2);--旧租赁是否合格
  v_jzz1 varchar2(2);--居住证是否合格（其中一个居住证合格则合格）
  v_jzz2 varchar2(2);--居住证是否合格（其中一个居住证合格则合格）
  v_bzxzf1 varchar2(2);--保障性住房是否合格
  v_bzxzf2 varchar2(2);--保障性住房是否合格
  v_wfzm1 varchar2(2);--无房证明是否合格
  v_wfzm2 varchar2(2);--无房证明是否合格
  v_wfzm3 varchar2(2);--无房证明是否合格
  v_shjg varchar2(2);--各个部门审核结果
  v_jg varchar2(2);--合成结果
BEGIN
  open c_list;
  loop fetch c_list into xs;
    exit when c_list%notfound;
      --获取区机构id
      select org_id into v_quorgid from jc_org a where exists(select 1 from jc_org_relat b where b.org_id_child=xs.sqxxid1 and b.org_id=a.org_id) and exists(select 1 from jc_app_org c where c.org_id=a.org_id and c.app_id=xs.app_id) and a.org_dj='50';
      open c_bmlist(v_quorgid);
      loop fetch c_bmlist into bm;
      exit when c_bmlist%notfound;
           v_xscount:=0;
           v_xscount2:=0;
           v_xsid:='1';
           v_tj:='''';
           v_ztj:='''';
           v_zbmid:='''';
           v_zbmzt:='''';
           v_shjg:='''';
           v_jg:='9';
           v_zlbasj:='''';--租赁登记备案日期
           v_yscode:='''';
           v_zlstate:='-1';
           v_jzlstate:='-1';
           v_jzz1:='-1';
           v_jzz2:='-1';
           v_bzxzf1:='-1';
           v_bzxzf2:='-1';
           v_wfzm1:='-1';--无房证明是否合格
           v_wfzm2:='-1';--无房证明是否合格
           v_wfzm3:='-1';
           v_shjgmx1:='''';--审核结果明细1
           v_shjgmx2:='''';--审核结果明细2
           v_shjgmx3:='''';--审核结果明细3
           v_shjgmx:='''';
           if(bm.tj is not null)then
                v_tj:=''' and '||bm.tj;
           end if;
           v_selsql := 'select count(*) cnt from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||bm.bmid||'''where jo.xsid='''||xs.xsid||v_tj;
           execute immediate v_selsql into v_xscount;
           if(v_xscount>0) then
               if(bm.bmdm='ZL')then--租赁
                 select a.tj,a.bmid,a.status into v_ztj,v_zbmid,v_zbmzt  from smbd_bmsz a where a.orgid=v_quorgid and a.bmdm='ZLBM';
                 if(v_zbmzt='1')then
                   if(v_ztj is not null)then
                      v_ztj:=''' and '||v_ztj;
                   end if;
                   v_xscount2:=0;
                   v_selsqlcount2:='select count(*) cnt from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj;
                   execute immediate v_selsqlcount2 into v_xscount2;
                   if(v_xscount2>0)then
                      v_selsql2:= 'select * from (select nvl(jo.xsid,''1'') xsid,nvl(b.shjg,''0'') shjg,nvl(b.shjgmx,'''') from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj||') where ROWNUM=1';
                      execute immediate v_selsql2 into v_xsid,v_shjg,v_shjgmx1;
                   else
                      v_xsid:='1';
                   end if;
                 else
                      v_xsid:='1';
                 end if;
                 if(v_xsid!='1') then
                     if(v_quorgid='606d6d7ba0c04f79b880d61c31214190') then--罗湖租赁合格特殊判断
                          if(v_shjg='2' and (xs.hjlxm='03' or xs.hjlxm='04' or xs.hjlxm='06')) then--租赁部门已经处理了结果才可对租赁部门进行判断
                            v_zlbasjsql:='select nvl(a.rsj3,''0'') rsj3,a.rsj1  from smbd_sj a where a.bmid='''||v_zbmid||''' and a.sjid='''||xs.xsid||'''';
                            execute immediate v_zlbasjsql into v_zlbasj,v_yscode;
                            if(v_zlbasj!='0' and v_yscode='1')then
                               select case when to_date(to_char(to_date(v_zlbasj,'yyyy-mm-dd HH24:mi:SS'),'yyyy-mm-dd'),'yyyy-mm-dd')<to_date(to_number(to_char(sysdate,'yyyy'))-1||'-05'||'-01','yyyy-mm-dd')
                                      then '3' else '4' end state into v_zlstate from dual;
                            else
                              v_zlstate:=v_shjg;
                            end if;
                          else
                            v_zlstate:=v_shjg;
                          end if;
                     elsif(v_quorgid='54a9072368e34ce98bcc87454cb238ff')then--福田租赁特殊判断
                      if(v_shjg='2') then--租赁部门已经处理了结果才可对租赁部门进行判断
                        v_zlbasjsql:='select nvl(a.rsj3,''0'') rsj3,a.rsj1  from smbd_sj a where a.bmid='''||v_zbmid||''' and a.sjid='''||xs.xsid||'''';
                        execute immediate v_zlbasjsql into v_zlbasj,v_yscode;
                        if(v_zlbasj!='0' and v_yscode='1')then
                           select case when (select c.islock from zs_xqf c where c.org_id=xs.sqxxid1)='1'
                                             and to_date(to_char(to_date(v_zlbasj,'yyyy-mm-dd HH24:mi:SS'),'yyyy-mm-dd'),'yyyy-mm-dd')<
                                             to_date(to_number(to_char(sysdate,'yyyy'))-1||'-09'||'-30','yyyy-mm-dd') then '3'
                                       when (select c.islock from zs_xqf c where c.org_id=xs.sqxxid1)='1'
                                             and to_date(to_char(to_date(v_zlbasj,'yyyy-mm-dd HH24:mi:SS'),'yyyy-mm-dd'),'yyyy-mm-dd')>to_date(to_number(to_char(sysdate,'yyyy'))-1||'-09'||'-30','yyyy-mm-dd')
                                             then '4'
                                       when xs.HJLXM in('01','02','07','05') then '3'
                                       when xs.njdm='11' and xs.HJLXM in('03','04','06') and to_date(to_char(to_date(v_zlbasj,'yyyy-mm-dd HH24:mi:SS'),'yyyy-mm-dd'),'yyyy-mm-dd')<to_date(to_number(to_char(sysdate,'yyyy'))-1||'-12'||'-31','yyyy-mm-dd')
                                      then '3'
                                      when xs.njdm='21' and xs.HJLXM in('03','04','06')  then '3' else '4' end state into v_zlstate from dual;
                        else
                          v_zlstate:=v_shjg;
                        end if;
                      else
                        v_zlstate:=v_shjg;
                      end if;
                     else
                        v_zlstate:=v_shjg;
                     end if;
                 end if;
                 --旧租赁合同
                 select a.tj,a.bmid,a.status into v_ztj,v_zbmid,v_zbmzt from smbd_bmsz a where a.orgid=v_quorgid and a.bmdm='JZLHT';
                 if(v_zbmzt='1')then
                   if(v_ztj is not null)then
                      v_ztj:=''' and '||v_ztj;
                   end if;
                   v_xscount2:=0;
                   v_selsqlcount2:='select count(*) cnt from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj;
                   execute immediate v_selsqlcount2 into v_xscount2;
                   if(v_xscount2>0)then
                      v_selsql2:= 'select * from (select nvl(jo.xsid,''1'') xsid,nvl(b.shjg,''0'') shjg,nvl(b.shjgmx,'''') from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj||') where ROWNUM=1';
                      execute immediate v_selsql2 into v_xsid,v_shjg,v_shjgmx2;
                   else
                      v_xsid:='1';
                   end if;
                 else
                      v_xsid:='1';
                   end if;
                 if(v_xsid!='1') then
                     v_jzlstate:=v_shjg;
                 end if;

                 if(v_zlstate='0')then
                    v_jg:='0';
                    v_shjgmx:='租赁部门:未审核';
                 elsif(v_jzlstate='0')then
                     v_jg:='0';
                    v_shjgmx:='旧租赁部门:未审核';
                 elsif(v_zlstate='2') then
                    v_jg:='2';
                    v_shjgmx:='租赁部门:'||v_shjgmx1;
                 elsif(v_zlstate='4' and (v_jzlstate='2' or v_jzlstate='-1')) then
                    v_jg:='2';
                    if(v_jzlstate='-1')then
                       v_shjgmx:='租赁部门:'||v_shjgmx1;
                    else
                      v_shjgmx:='租赁部门:'||v_shjgmx1||'; 旧租赁部门:'||v_shjgmx2;
                    end if;
                 elsif(v_zlstate='1' or v_zlstate='3' or (v_zlstate='4' and v_jzlstate='1'))then
                    v_jg:='1';
                    if(v_jzlstate='-1')then
                       v_shjgmx:='匹配成功！租赁部门:'||v_shjgmx1;
                    else
                      v_shjgmx:='匹配成功！租赁部门:'||v_shjgmx1||'; 旧租赁部门:'||v_shjgmx2;
                    end if;
                 end if;
               elsif(bm.bmdm='FSHGA')then--非深户
                 --居住证1
                   select a.tj,a.bmid,a.status into v_ztj,v_zbmid,v_zbmzt from smbd_bmsz a where a.orgid=v_quorgid and a.bmdm='JZZH1';
                   if(v_ztj is not null)then
                      v_ztj:=''' and '||v_ztj;
                   end if;
                   v_xscount2:=0;
                   v_selsqlcount2:='select count(*) cnt from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj;
                   execute immediate v_selsqlcount2 into v_xscount2;
                   if(v_xscount2>0)then
                      v_selsql2:= 'select * from (select nvl(jo.xsid,''1'') xsid,nvl(b.shjg,''0'') shjg,nvl(b.shjgmx,'''') from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj||') where ROWNUM=1';
                      execute immediate v_selsql2 into v_xsid,v_shjg,v_shjgmx1;
                   else
                      v_xsid:='1';
                   end if;
                   if(v_xsid!='1') then
                      v_jzz1:=v_shjg;
                   end if;
                   --居住证2
                   select a.tj,a.bmid,a.status into v_ztj,v_zbmid,v_zbmzt from smbd_bmsz a where a.orgid=v_quorgid and a.bmdm='JZZH2';
                   if(v_ztj is not null)then
                      v_ztj:=''' and '||v_ztj;
                   end if;
                   v_xscount2:=0;
                   v_selsqlcount2:='select count(*) cnt from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj;
                   execute immediate v_selsqlcount2 into v_xscount2;
                   if(v_xscount2>0)then
                      v_selsql2:= 'select * from (select nvl(jo.xsid,''1'') xsid,nvl(b.shjg,''0'') shjg,nvl(b.shjgmx,'''') from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj||') where ROWNUM=1';
                      execute immediate v_selsql2 into v_xsid,v_shjg,v_shjgmx2;
                   else
                      v_xsid:='1';
                   end if;
                   if(v_xsid!='1') then
                      v_jzz2:=v_shjg;
                   end if;
                   --监护人深户1
                   select a.tj,a.bmid,a.status into v_ztj,v_zbmid,v_zbmzt from smbd_bmsz a where a.orgid=v_quorgid and a.bmdm='JHRSH1';
                   if(v_ztj is not null)then
                      v_ztj:=''' and '||v_ztj;
                   end if;
                   v_xscount2:=0;
                   v_selsqlcount2:='select count(*) cnt from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj;
                   execute immediate v_selsqlcount2 into v_xscount2;
                   if(v_xscount2>0)then
                      v_selsql2:= 'select * from (select nvl(jo.xsid,''1'') xsid,nvl(b.shjg,''0'') shjg,nvl(b.shjgmx,'''') from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj||') where ROWNUM=1';
                      execute immediate v_selsql2 into v_xsid,v_shjg,v_shjgmx1;
                   else
                      v_xsid:='1';
                   end if;
                   if(v_xsid!='1') then
                      v_jzz1:=v_shjg;
                   end if;
                   --监护人深户2
                   select a.tj,a.bmid into v_ztj,v_zbmid  from smbd_bmsz a where a.orgid=v_quorgid and a.bmdm='JHRSH2';
                   if(v_ztj is not null)then
                      v_ztj:=''' and '||v_ztj;
                   end if;
                   v_xscount2:=0;
                   v_selsqlcount2:='select count(*) cnt from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj;
                   execute immediate v_selsqlcount2 into v_xscount2;
                   if(v_xscount2>0)then
                      v_selsql2:= 'select * from (select nvl(jo.xsid,''1'') xsid,nvl(b.shjg,''0'') shjg,nvl(b.shjgmx,'''') from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj||') where ROWNUM=1';
                      execute immediate v_selsql2 into v_xsid,v_shjg,v_shjgmx2;
                   else
                      v_xsid:='1';
                   end if;
                   if(v_xsid!='1') then
                      v_jzz2:=v_shjg;
                   end if;
                 --if(v_quorgid!='b8f9aa1578734cf0ba3b75bedd0c9743') then--除开南山
                    if(v_jzz1='0') then--居住证的个性化验证
                       v_jg:='0';
                       v_shjgmx:='监护人1:未审核';
                    elsif(v_jzz2='0') then
                       v_jg:='0';
                       v_shjgmx:='监护人2:未审核';
                    elsif(v_jzz1='2' and (v_jzz2='2' or v_jzz2='-1'))then
                       v_jg:='2';
                        if(v_jzz2='-1')then
                          v_shjgmx:='监护人1:'||v_shjgmx1;
                        else
                          v_shjgmx:='监护人1:'||v_shjgmx1||'; 监护人2:'||v_shjgmx2;
                        end if;
                    elsif(v_jzz2='2' and (v_jzz1='2' or v_jzz1='-1'))then
                       v_jg:='2';
                       if(v_jzz1='-1')then
                         v_shjgmx:='监护人2:'||v_shjgmx2;
                       else
                         v_shjgmx:='监护人1:'||v_shjgmx1||'; 监护人2:'||v_shjgmx2;
                       end if;
                    elsif(v_jzz1='1' or v_jzz2='1')then
                       v_jg:='1';
                       if(v_jzz1='-1')then
                         v_shjgmx:='匹配成功！监护人2:'||v_shjgmx2;
                       else
                         v_shjgmx:='匹配成功！监护人1:'||v_shjgmx1||'; 监护人2:'||v_shjgmx2;
                       end if;
                    end if;
                 /*elsif(v_quorgid='b8f9aa1578734cf0ba3b75bedd0c9743')then--南山
                    if(v_jzz1='0') then--居住证的个性化验证
                       v_jg:='0';
                       v_shjgmx:='监护人1:未审核';
                    elsif(v_jzz2='0') then
                       v_jg:='0';
                       v_shjgmx:='监护人2:未审核';
                    elsif(v_jzz1='2' and v_jzz2='2')then
                      v_jg:='2';
                      v_shjgmx:='监护人1:'||v_shjgmx1||'; 监护人2:'||v_shjgmx2;
                    elsif(v_jzz1='2')then
                      v_jg:='2';
                      v_shjgmx:='监护人1:'||v_shjgmx1;
                    elsif(v_jzz2='2')then
                      v_jg:='2';
                      v_shjgmx:='监护人2:'||v_shjgmx1;
                    elsif((v_jzz1='1' and v_jzz2='1') or (v_jzz1='1' and v_jzz2='-1') or (v_jzz1='-1' and v_jzz2='1'))then
                      v_jg:='1';
                      if(v_jzz1='-1')then
                         v_shjgmx:='匹配成功！监护人2:'||v_shjgmx2;
                      else
                         v_shjgmx:='匹配成功！监护人1:'||v_shjgmx1||'; 监护人2:'||v_shjgmx2;
                      end if;
                    end if;
                 end if;*/
               elsif(bm.bmdm='BZXZF')then--保障性住房
                    --保障性住房
                    --安居房保障房1
                   select a.tj,a.bmid into v_ztj,v_zbmid  from smbd_bmsz a where a.orgid=v_quorgid and a.bmdm='ANFBZF1';
                   if(v_ztj is not null)then
                      v_ztj:=''' and '||v_ztj;
                   end if;
                   v_xscount2:=0;
                   v_selsqlcount2:='select count(*) cnt from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj;
                   execute immediate v_selsqlcount2 into v_xscount2;
                   if(v_xscount2>0)then
                      v_selsql2:= 'select * from (select nvl(jo.xsid,''1'') xsid,nvl(b.shjg,''0'') shjg,nvl(b.shjgmx,'''') from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj||') where ROWNUM=1';
                      execute immediate v_selsql2 into v_xsid,v_shjg,v_shjgmx1;
                   else
                      v_xsid:='1';
                   end if;
                   if(v_xsid!='1') then
                      v_bzxzf1:=v_shjg;
                   end if;
                   --安居房保障房2
                   select a.tj,a.bmid into v_ztj,v_zbmid  from smbd_bmsz a where a.orgid=v_quorgid and a.bmdm='ANFBZF2';
                   if(v_ztj is not null)then
                      v_ztj:=''' and '||v_ztj;
                   end if;
                   v_xscount2:=0;
                   v_selsqlcount2:='select count(*) cnt from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj;
                   execute immediate v_selsqlcount2 into v_xscount2;
                   if(v_xscount2>0)then
                      v_selsql2:= 'select * from (select nvl(jo.xsid,''1'') xsid,nvl(b.shjg,''0'') shjg,nvl(b.shjgmx,'''') from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj||') where ROWNUM=1';
                      execute immediate v_selsql2 into v_xsid,v_shjg,v_shjgmx2;
                   else
                      v_xsid:='1';
                   end if;
                   if(v_xsid!='1') then
                      v_bzxzf2:=v_shjg;
                   end if;

                   --周转房1
                   select a.tj,a.bmid into v_ztj,v_zbmid  from smbd_bmsz a where a.orgid=v_quorgid and a.bmdm='ZZF1';
                   if(v_ztj is not null)then
                      v_ztj:=''' and '||v_ztj;
                   end if;
                   v_xscount2:=0;
                   v_selsqlcount2:='select count(*) cnt from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj;
                   execute immediate v_selsqlcount2 into v_xscount2;
                   if(v_xscount2>0)then
                      v_selsql2:= 'select * from (select nvl(jo.xsid,''1'') xsid,nvl(b.shjg,''0'') shjg,nvl(b.shjgmx,'''') from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj||') where ROWNUM=1';
                      execute immediate v_selsql2 into v_xsid,v_shjg,v_shjgmx1;
                   else
                      v_xsid:='1';
                   end if;
                   if(v_xsid!='1') then
                      v_bzxzf1:=v_shjg;
                   end if;
                   select a.tj,a.bmid into v_ztj,v_zbmid  from smbd_bmsz a where a.orgid=v_quorgid and a.bmdm='ZZF2';
                   if(v_ztj is not null)then
                      v_ztj:=''' and '||v_ztj;
                   end if;
                   v_xscount2:=0;
                   v_selsqlcount2:='select count(*) cnt from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj;
                   execute immediate v_selsqlcount2 into v_xscount2;
                   if(v_xscount2>0)then
                      v_selsql2:= 'select * from (select nvl(jo.xsid,''1'') xsid,nvl(b.shjg,''0'') shjg,nvl(b.shjgmx,'''') from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj||') where ROWNUM=1';
                      execute immediate v_selsql2 into v_xsid,v_shjg,v_shjgmx2;
                   else
                      v_xsid:='1';
                   end if;
                   if(v_xsid!='1') then
                      v_bzxzf2:=v_shjg;
                   end if;

                   --公共租赁房
                   select a.tj,a.bmid into v_ztj,v_zbmid  from smbd_bmsz a where a.orgid=v_quorgid and a.bmdm='GGZLF1';
                   if(v_ztj is not null)then
                      v_ztj:=''' and '||v_ztj;
                   end if;
                   v_xscount2:=0;
                   v_selsqlcount2:='select count(*) cnt from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj;
                   execute immediate v_selsqlcount2 into v_xscount2;
                   if(v_xscount2>0)then
                      v_selsql2:= 'select * from (select nvl(jo.xsid,''1'') xsid,nvl(b.shjg,''0'') shjg,nvl(b.shjgmx,'''') from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj||') where ROWNUM=1';
                      execute immediate v_selsql2 into v_xsid,v_shjg,v_shjgmx1;
                   else
                      v_xsid:='1';
                   end if;
                   if(v_xsid!='1') then
                      v_bzxzf1:=v_shjg;
                   end if;
                   select a.tj,a.bmid into v_ztj,v_zbmid  from smbd_bmsz a where a.orgid=v_quorgid and a.bmdm='GGZLF2';
                   if(v_ztj is not null)then
                      v_ztj:=''' and '||v_ztj;
                   end if;
                   v_xscount2:=0;
                   v_selsqlcount2:='select count(*) cnt from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj;
                   execute immediate v_selsqlcount2 into v_xscount2;
                   if(v_xscount2>0)then
                      v_selsql2:= 'select * from (select nvl(jo.xsid,''1'') xsid,nvl(b.shjg,''0'') shjg,nvl(b.shjgmx,'''') from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj||') where ROWNUM=1';
                      execute immediate v_selsql2 into v_xsid,v_shjg,v_shjgmx2;
                   else
                      v_xsid:='1';
                   end if;
                   if(v_xsid!='1') then
                      v_bzxzf2:=v_shjg;
                   end if;

                   --廉租房公租房
                    select a.tj,a.bmid into v_ztj,v_zbmid  from smbd_bmsz a where a.orgid=v_quorgid and a.bmdm='LZFGZF1';
                   if(v_ztj is not null)then
                      v_ztj:=''' and '||v_ztj;
                   end if;
                   v_xscount2:=0;
                   v_selsqlcount2:='select count(*) cnt from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj;
                   execute immediate v_selsqlcount2 into v_xscount2;
                   if(v_xscount2>0)then
                      v_selsql2:= 'select * from (select nvl(jo.xsid,''1'') xsid,nvl(b.shjg,''0'') shjg,nvl(b.shjgmx,'''') from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj||') where ROWNUM=1';
                      execute immediate v_selsql2 into v_xsid,v_shjg,v_shjgmx1;
                   else
                      v_xsid:='1';
                   end if;
                   if(v_xsid!='1') then
                      v_bzxzf1:=v_shjg;
                   end if;
                   select a.tj,a.bmid into v_ztj,v_zbmid  from smbd_bmsz a where a.orgid=v_quorgid and a.bmdm='LZFGZF2';
                   if(v_ztj is not null)then
                      v_ztj:=''' and '||v_ztj;
                   end if;
                   v_xscount2:=0;
                   v_selsqlcount2:='select count(*) cnt from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj;
                   execute immediate v_selsqlcount2 into v_xscount2;
                   if(v_xscount2>0)then
                      v_selsql2:= 'select * from (select nvl(jo.xsid,''1'') xsid,nvl(b.shjg,''0'') shjg,nvl(b.shjgmx,'''') from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj||') where ROWNUM=1';
                      execute immediate v_selsql2 into v_xsid,v_shjg,v_shjgmx2;
                   else
                      v_xsid:='1';
                   end if;
                   if(v_xsid!='1') then
                      v_bzxzf2:=v_shjg;
                   end if;

                   if(v_bzxzf1='0') then--居住证的个性化验证
                       v_jg:='0';
                       v_shjgmx:='监护人1保障性住房:未审核';
                   elsif(v_bzxzf2='0') then
                       v_jg:='0';
                       v_shjgmx:='监护人2保障性住房:未审核';
                   elsif(v_bzxzf1='2' and (v_bzxzf2='2' or v_bzxzf2='-1')) then
                      v_jg:='2';
                      if(v_bzxzf2='-1')then
                         v_shjgmx:='监护人1保障性住房:'||v_shjgmx1;
                      else
                         v_shjgmx:='监护人1保障性住房:'||v_shjgmx1||'; 监护人2保障性住房:'||v_shjgmx2;
                      end if;
                   elsif(v_bzxzf1='1' or v_bzxzf2='1') then
                      v_jg:='1';
                      if(v_bzxzf2='-1')then
                         v_shjgmx:='匹配成功！监护人1保障性住房:'||v_shjgmx1;
                      else
                         v_shjgmx:='匹配成功！监护人1保障性住房:'||v_shjgmx1||'; 监护人2保障性住房:'||v_shjgmx2;
                      end if;
                   end if;
                 elsif(bm.bmdm='WFZM')then--无房证明
                   select a.tj,a.bmid into v_ztj,v_zbmid  from smbd_bmsz a where a.orgid=v_quorgid and a.bmdm='XSWFZM';
                   if(v_ztj is not null)then
                      v_ztj:=''' and '||v_ztj;
                   end if;
                   v_xscount2:=0;
                   v_selsqlcount2:='select count(*) cnt from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj;
                   execute immediate v_selsqlcount2 into v_xscount2;
                   if(v_xscount2>0)then
                      v_selsql2:= 'select * from (select nvl(jo.xsid,''1'') xsid,nvl(b.shjg,''0'') shjg,nvl(b.shjgmx,'''') from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj||') where ROWNUM=1';
                      execute immediate v_selsql2 into v_xsid,v_shjg,v_shjgmx1;
                   else
                      v_xsid:='1';
                   end if;
                   if(v_xsid!='1') then
                      v_wfzm1:=v_shjg;
                   end if;
                   select a.tj,a.bmid into v_ztj,v_zbmid  from smbd_bmsz a where a.orgid=v_quorgid and a.bmdm='JHR1WFZM';
                   if(v_ztj is not null)then
                      v_ztj:=''' and '||v_ztj;
                   end if;
                   v_xscount2:=0;
                   v_selsqlcount2:='select count(*) cnt from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj;
                   execute immediate v_selsqlcount2 into v_xscount2;
                   if(v_xscount2>0)then
                      v_selsql2:= 'select * from (select nvl(jo.xsid,''1'') xsid,nvl(b.shjg,''0'') shjg,nvl(b.shjgmx,'''') from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj||') where ROWNUM=1';
                      execute immediate v_selsql2 into v_xsid,v_shjg,v_shjgmx2;
                   else
                      v_xsid:='1';
                   end if;
                   if(v_xsid!='1') then
                      v_wfzm2:=v_shjg;
                   end if;
                   select a.tj,a.bmid into v_ztj,v_zbmid  from smbd_bmsz a where a.orgid=v_quorgid and a.bmdm='JHR2WFZM';
                   if(v_ztj is not null)then
                      v_ztj:=''' and '||v_ztj;
                   end if;
                   v_xscount2:=0;
                   v_selsqlcount2:='select count(*) cnt from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj;
                   execute immediate v_selsqlcount2 into v_xscount2;
                   if(v_xscount2>0)then
                      v_selsql2:= 'select * from (select nvl(jo.xsid,''1'') xsid,nvl(b.shjg,''0'') shjg,nvl(b.shjgmx,'''') from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj||') where ROWNUM=1';
                      execute immediate v_selsql2 into v_xsid,v_shjg,v_shjgmx3;
                   else
                      v_xsid:='1';
                   end if;
                   if(v_xsid!='1') then
                      v_wfzm3:=v_shjg;
                   end if;
                   if(v_wfzm1='0') then--居住证的个性化验证
                       v_jg:='0';
                       v_shjgmx:='新生无房证明:未审核';
                    elsif(v_wfzm2='0') then
                       v_jg:='0';
                       v_shjgmx:='监护人1无房证明:未审核';
                    elsif(v_wfzm3='0') then
                       v_jg:='0';
                       v_shjgmx:='监护人2无房证明:未审核';
                    elsif(v_wfzm1='2')then
                      v_jg:='2';
                      v_shjgmx:='新生无房证明:'||v_shjgmx1;
                    elsif(v_wfzm2='2')then
                      v_jg:='2';
                      v_shjgmx:='监护人1无房证明:'||v_shjgmx2;
                    elsif(v_wfzm3='2')then
                      v_jg:='2';
                      v_shjgmx:='监护人无房证明2:'||v_shjgmx3;
                    elsif(v_wfzm1='1' and v_wfzm2='1' and (v_wfzm3='1' or v_wfzm3='-1'))then
                      v_jg:='1';
                      v_shjgmx:='匹配成功！';
                    end if;
                 elsif(bm.bmdm='JTSSWFZM')then--福田：集体宿舍无房证明
                   select a.tj,a.bmid into v_ztj,v_zbmid  from smbd_bmsz a where a.orgid=v_quorgid and a.bmdm='JTSSXSWFZM';
                   if(v_ztj is not null)then
                      v_ztj:=''' and '||v_ztj;
                   end if;
                   v_xscount2:=0;
                   v_selsqlcount2:='select count(*) cnt from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj;
                   execute immediate v_selsqlcount2 into v_xscount2;
                   if(v_xscount2>0)then
                      v_selsql2:= 'select * from (select nvl(jo.xsid,''1'') xsid,nvl(b.shjg,''0'') shjg,nvl(b.shjgmx,'''') from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj||') where ROWNUM=1';
                      execute immediate v_selsql2 into v_xsid,v_shjg,v_shjgmx1;
                   else
                      v_xsid:='1';
                   end if;
                   if(v_xsid!='1') then
                      v_wfzm1:=v_shjg;
                   end if;
                   select a.tj,a.bmid into v_ztj,v_zbmid  from smbd_bmsz a where a.orgid=v_quorgid and a.bmdm='JTSSJHR1WFZM';
                   if(v_ztj is not null)then
                      v_ztj:=''' and '||v_ztj;
                   end if;
                   v_xscount2:=0;
                   v_selsqlcount2:='select count(*) cnt from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj;
                   execute immediate v_selsqlcount2 into v_xscount2;
                   if(v_xscount2>0)then
                      v_selsql2:= 'select * from (select nvl(jo.xsid,''1'') xsid,nvl(b.shjg,''0'') shjg,nvl(b.shjgmx,'''') from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj||') where ROWNUM=1';
                      execute immediate v_selsql2 into v_xsid,v_shjg,v_shjgmx2;
                   else
                      v_xsid:='1';
                   end if;
                   if(v_xsid!='1') then
                      v_wfzm2:=v_shjg;
                   end if;
                   select a.tj,a.bmid into v_ztj,v_zbmid  from smbd_bmsz a where a.orgid=v_quorgid and a.bmdm='JTSSJHR2WFZM';
                   if(v_ztj is not null)then
                      v_ztj:=''' and '||v_ztj;
                   end if;
                   v_xscount2:=0;
                   v_selsqlcount2:='select count(*) cnt from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj;
                   execute immediate v_selsqlcount2 into v_xscount2;
                   if(v_xscount2>0)then
                      v_selsql2:= 'select * from (select nvl(jo.xsid,''1'') xsid,nvl(b.shjg,''0'') shjg,nvl(b.shjgmx,'''') from v_smbd_bmshjg jo left join smbd_shjg b on b.xsid=jo.xsid and b.bmid='''||v_zbmid||'''where jo.xsid='''||xs.xsid||v_ztj||') where ROWNUM=1';
                      execute immediate v_selsql2 into v_xsid,v_shjg,v_shjgmx3;
                   else
                      v_xsid:='1';
                   end if;
                   if(v_xsid!='1') then
                      v_wfzm3:=v_shjg;
                   end if;
                   if(v_wfzm1='0') then--居住证的个性化验证
                       v_jg:='0';
                       v_shjgmx:='新生集体宿舍无房证明:未审核';
                    elsif(v_wfzm2='0') then
                       v_jg:='0';
                       v_shjgmx:='监护人1集体宿舍无房证明:未审核';
                    elsif(v_wfzm3='0') then
                       v_jg:='0';
                       v_shjgmx:='监护人2集体宿舍无房证明:未审核';
                    elsif(v_wfzm1='2')then
                      v_jg:='2';
                      v_shjgmx:='新生集体宿舍无房证明:'||v_shjgmx1;
                    elsif(v_wfzm2='2')then
                      v_jg:='2';
                      v_shjgmx:='监护人1集体宿舍无房证明:'||v_shjgmx2;
                    elsif(v_wfzm3='2')then
                      v_jg:='2';
                      v_shjgmx:='监护人2集体宿舍无房证明:'||v_shjgmx3;
                    elsif(v_wfzm1='1' and v_wfzm2='1' and (v_wfzm3='1' or v_wfzm3='-1'))then
                      v_jg:='1';
                      v_shjgmx:='匹配成功！';
                    end if;
               end if;
               if(v_jg='-1')then
                   dbms_output.put_line('======================xsid:'||xs.xsid);
               end if;
               delete smbd_shjg WHERE bmdm=bm.bmdm and  xsid=xs.xsid;
               insert into smbd_shjg(jgid,xsid,bmdm,shjg,shjgmx,shr,shsj,ssbmdm,bmid) select fn_uuid(),xs.xsid,bm.bmdm,v_jg,v_shjgmx,p_czr,fn_sysdate(),bm.ssbmdm,bm.bmid from dual;
               commit;
           end if;
      end loop;
      close c_bmlist;
  end loop;
  close c_list;
end PRO_BDYH_GETHCBMJG_BY_XSID;
/

