create view V_ZS_LGLQ2 as
select
a.xsid,a.ylqzt,a.ylqxx,a.lqzt,a.app_id,a.shzt,a.sfcssj,a.zjg,a.ylq_orgid ylqxxid,a.lq_orgid lqxxid,
case when a.sqxxid1='263a9db9fc434cb78e2b67ce656e415d' and a.ylq_orgid='263a9db9fc434cb78e2b67ce656e415d'
and exists (select 1 from zs_lglq_zssj b where b.sfzh=a.sfzjh)
then '1' else '0' end sfzs
from
zs_xsxx a
where
exists (select 1 from jc_org_relat b where b.org_id_child=a.sqxxid1 and b.org_id='b3c2fbca21a24a8e88d493fe3f5c781a')
--61DBC3F71A377A99E0530100007FBE2D	SZLGGBXYZS	深圳市龙岗区公办小一招生管理系统
--61DBC3F71A387A99E0530100007FBE2D	SZLGGBCYZS	深圳市龙岗区公办初一招生管理系统
and a.app_id='61DBC3F71A377A99E0530100007FBE2D'
and a.sfcssj='0'
and a.shzt='2'
and a.zjg='1'
and nvl(a.lqzt,'1')<>'2'
/

