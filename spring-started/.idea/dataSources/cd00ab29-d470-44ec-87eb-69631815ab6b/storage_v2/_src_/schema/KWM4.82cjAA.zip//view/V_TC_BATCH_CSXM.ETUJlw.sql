create view V_TC_BATCH_CSXM as
select jbc.cbid,jbc.pcid,jbc.csid,jbc.njdm,jbc.xbdm,jb.bmc,tc.csxmmc,E.DMMX_MC NJ,D.DMMX_MC XB,tc.xsws,tc.dw_code
from tc_batch_csxm jbc
left join jc_batch jb on jb.bid = jbc.pcid
left join TC_CSXM tc on tc.csid = jbc.csid
LEFT JOIN JC_DMMX E ON jbc.njdm=E.DMMX_CODE AND E.DM_CODE='DM_NJDM'
LEFT JOIN JC_DMMX D ON jbc.xbdm=D.DMMX_CODE AND D.DM_CODE='DM_XB'
/

