create PROCEDURE PRO_BDYH_GETHCBMJG_BY_TIME(p_appid in varchar2,p_orgid in varchar2) IS --递增计算合成结果（全部数据根据app_id和org_id 以及时间循环计算学生）
  cursor c_list is select distinct xsid from smbd_shjg a
  where a.shsj > (select max_time from  SMBD_HCBMJG_TIME where app_id =p_appid and org_id = p_orgid )
  and exists (select 1 from smbd_bmsz b where nvl(b.ishcbm,'0')<>'1' and a.bmid = b.bmid and b.orgid = p_orgid )
  and exists(select 1 from zs_xsxx c where c.shzt='2' and c.xsid = a.xsid and exists(select 1 from jc_org_relat d where d.org_id=p_orgid and d.org_id_child=c.sqxxid1) AND c.APP_ID =p_appid)
  and a.bmdm not in('JSBM');
  xs c_list%rowtype;
  v_max_shsj date;
  v_xsid varchar(32);
  v_ishave varchar2(100);
BEGIN
  select max(shsj) into v_max_shsj from  v_smbd_shjg_ao where app_id = p_appid and org_id = p_orgid  and nvl(ishcbm,'0')<>'1';
  open c_list;
  loop fetch c_list into xs;
    exit when c_list%notfound;
    v_ishave:='Y';
    v_xsid := xs.xsid;
    pro_bdyh_gethcbmjg_by_xsid(v_xsid,'sys');
  end loop;
  close c_list;
  if(v_ishave='Y')then
     update SMBD_HCBMJG_TIME set max_time = v_max_shsj where app_id = p_appid and org_id = p_orgid;
     commit;
  end if;
end PRO_BDYH_GETHCBMJG_BY_TIME;
/

