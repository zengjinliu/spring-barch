create function FN_TO_DATE(input_string VARCHAR2) return date is kwdate date;
begin
  kwdate := to_date(input_string,'yyyy-mm-dd hh24:mi:ss');
return kwdate;
end FN_TO_DATE;
/

