create view V_JC_ZJLB as
select "LB_ID","LBMC","LBDM","DJ","P_UUID","ORDERBY","ZJK_ID","STATUS","XZR","XZSJ","GXR","GXSJ" from jc_zjlb
/

