create view V_ZS_SSX_LINK as
select ed.DMMX_MC||sd.DMMX_MC||xd.DMMX_MC SSXMC,ed.DMMX_CODE||sd.DMMX_CODE||xd.DMMX_CODE SSXDM
from jc_dmmx xd
left join jc_dmmx sd on sd.dmmx_id=xd.p_dm_id and sd.dm_code='DM_SHI' and sd.dmmx_state='1'
left join jc_dmmx ed on ed.dmmx_id=sd.p_dm_id and ed.dm_code='DM_SHENG' and ed.dmmx_state='1'
where xd.dm_code='DM_XIAN' and xd.dmmx_state='1'
/

