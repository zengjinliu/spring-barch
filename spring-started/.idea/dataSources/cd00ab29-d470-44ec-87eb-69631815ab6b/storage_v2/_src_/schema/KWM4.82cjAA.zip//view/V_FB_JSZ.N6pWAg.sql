create view V_FB_JSZ as
SELECT T1.JSZID,T1.MC,T1.BZR,T1.YUWEN,T1.SHUXUE,T1.YINGyU,T1.WULI,T1.SHENGWU,T1.LISHI,T1.DILI,T1.ZHENGZHI,
T1.ORG_ID,T1.HUAXUE,T1.APP_ID,T1.XZR,T1.GXR,T1.XZSJ,T1.GXSJ,
decode(T1.bzr,null,'','（'||'班主任：'||T1.bzr||'；')||decode(T1.yuwen,null,'','语文：'||T1.yuwen||'；')||decode(T1.shuxue,null,'','数学：'||T1.shuxue||'；')
||decode(T1.yingyu,null,'','英语：'||T1.yingyu||'；')||decode(T1.wuli,null,'','物理：'||T1.wuli||'；')||decode(T1.huaxue,null,'','化学：'||T1.huaxue||'；')
||decode(T1.shengwu,null,'','生物：'||T1.shengwu||'；')||decode(T1.lishi,null,'','历史：'||T1.lishi||'；')||decode(T1.dili,null,'','地理：'||T1.dili||'；')
||decode(T1.zhengzhi,null,'','政治：'||T1.zhengzhi||'；')||decode(T1.bzr,null,'','）')
as jszmclink
FROM FB_JSZ T1
/

