create PROCEDURE PRO_BDYH_GETHCBMJG_BY_APP_ORG(p_appid in varchar2,p_orgid in varchar2) IS --计算合成结果（全部数据根据app_id和org_id循环计算学生）
  cursor c_list is select * from v_smbd_bmshjg v where v.shzt='2'
  and exists(select 1 from jc_org_relat c where c.org_id=p_orgid and c.org_id_child=v.sqxxid1)AND v.APP_ID =p_appid
  and exists(select 1 from smbd_shjg a where a.xsid=v.xsid);
  xs c_list%rowtype;
  v_xsid varchar(32);
BEGIN
  open c_list;
  loop fetch c_list into xs;
    exit when c_list%notfound;
    v_xsid := xs.xsid;
    pro_bdyh_gethcbmjg_by_xsid(v_xsid,'sys');
  end loop;
  close c_list;
  commit;
end PRO_BDYH_GETHCBMJG_BY_APP_ORG;
/

