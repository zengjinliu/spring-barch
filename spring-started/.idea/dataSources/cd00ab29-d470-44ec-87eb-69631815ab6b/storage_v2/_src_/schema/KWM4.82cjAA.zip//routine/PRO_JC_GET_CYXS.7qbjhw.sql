create procedure PRO_JC_GET_CYXS is

     cursor up_orgs is SELECT JO.org_id,JO.org_mc from Jc_Org JO, jc_jfxm_dxjf JJD  
            left join Jc_Collect_Group_Batch_Org JBO on JBO.PZLID=JJD.PZLID
            WHERE EXISTS (SELECT 1 FROM  JC_ORG_RELAT JOR  WHERE JOR.ORG_ID_CHILD=JBO.Org_Id AND JOR.ORG_ID=JO.ORG_ID AND JO.ORG_DJ='50')
            GROUP BY JO.org_id,JO.org_mc ;
   
     org Jc_Org%ROWTYPE;
     item jc_jfxm_dxjf%ROWTYPE;
     iteamSql varchar2(1000);
     xx_average number;
     zx_average number;
     sx_sum number;
     sc_sum number;
   
     CV_XX number;
     CV_ZX number;
     molecule_xx number;
     molecule_zx number;
   
     jxxm_id_xx jc_collect_bar.cid%type;
     jxxm_id_zx jc_collect_bar.cid%type;
     --jxxm_id_gz jc_collect_bar.cid%type;
begin
     execute immediate ('select cid from jc_collect_bar JB WHERE JB.cname like('''||'小学学生数'||''') and rownum=1')into jxxm_id_xx;
     execute immediate ('select cid from jc_collect_bar JB WHERE JB.cname like('''||'中学学生数'||''') and rownum=1')into jxxm_id_zx;
     --execute immediate ('select cid from jc_collect_bar JB WHERE JB.cname like('''||'高中学生数'||''') and rownum=1')into jxxm_id_gz;
     
     execute immediate ('truncate table jc_JFXM_CYXS');
     --遍历区--
     for org in up_orgs loop
         -- 区批次--
         for batch  in (select jb.bid from Jc_Collect_Group_Batch jb, JC_ORG JO, jc_jfxm_dxjf jd,Jc_Collect_Group_Batch_Org JBO 
             where jb.pzid=jbo.pzid and jd.pzlid=jbo.pzlid AND JO.org_id=JBO.ORG_ID  AND
             EXISTS (SELECT 1 FROM  JC_ORG_RELAT JOR  WHERE JOR.ORG_ID= org.org_id  AND JOR.ORG_ID_CHILD=JO.ORG_ID)
             group by jb.bid) loop 
             --求区计分项目--
             for item in (SELECT JFB.JID FROM JC_ORG JO, Jc_Collect_Group_Batch_Org JBO JOIN jc_jfxm_dxjf JFB ON JFB.PZLID=JBO.PZLID
                 WHERE JO.org_id=JBO.ORG_ID AND EXISTS (SELECT 1 FROM  JC_ORG_RELAT JOR  WHERE JOR.ORG_ID= org.org_id AND 
                 JOR.ORG_ID_CHILD=JO.ORG_ID)GROUP BY JFB.JID) loop
                 
              begin
                  --区小学积分项平均值--
                  iteamSql:='SELECT DECODE(AVG(JFB.JFZ),NULL,0,AVG(JFB.JFZ))  FROM JC_ORG JO, Jc_Collect_Group_Batch_Org JBO 
                          JOIN jc_jfxm_dxjf JFB ON JFB.PZLID=JBO.PZLID AND JFB.JID='''|| item.JID ||''' 
                          JOIN Jc_Collect_Group_Batch JGB ON JGB.PZID=JBO.PZID  AND JGB.BID='''|| batch.BID ||'''
                          JOIN jc_collect_value JV ON JV.ORG_ID=JBO.ORG_ID AND JV.CID='''|| jxxm_id_xx ||'''   
                          WHERE JO.org_id=JBO.ORG_ID AND 
                          EXISTS (SELECT 1 FROM  JC_ORG_RELAT JOR  WHERE JOR.ORG_ID='''|| org.org_id ||''' AND JOR.ORG_ID_CHILD=JO.ORG_ID)';            
                  execute immediate iteamSql INTO xx_average; 
                  
                  --区小学学生数--
                  iteamSql:='SELECT DECODE(SUM(JV.CONTENT),NULL,0,SUM(JV.CONTENT)) FROM JC_ORG JO, jc_collect_value JV 
                           WHERE JO.org_id=JV.ORG_ID AND JV.CID='''|| jxxm_id_xx ||''' AND
                           EXISTS (SELECT 1 FROM  JC_ORG_RELAT JOR  WHERE JOR.ORG_ID='''|| org.org_id ||''' AND JOR.ORG_ID_CHILD=JO.ORG_ID)';
                  execute immediate iteamSql INTO sx_sum; 
                  
                   ---差异系数分子---
                  iteamSql:='SELECT SUM( POWER(JFB.JFZ-'|| xx_average ||',2)*JV.CONTENT )FROM JC_ORG JO, Jc_Collect_Group_Batch_Org JBO 
                        JOIN jc_jfxm_dxjf JFB ON JFB.PZLID=JBO.PZLID AND JFB.JID='''|| item.JID ||''' 
                        JOIN jc_collect_value JV ON JV.ORG_ID=JBO.ORG_ID AND JV.CID='''|| jxxm_id_xx ||'''
                        JOIN Jc_Collect_Group_Batch JGB ON JGB.PZID=JBO.PZID AND  JGB.BID='''|| batch.BID ||'''
                        WHERE JO.ORG_ID=JBO.ORG_ID  AND  EXISTS 
                        (SELECT 1 FROM  JC_ORG_RELAT JOR  WHERE JOR.ORG_ID='''|| org.org_id ||''' AND JOR.ORG_ID_CHILD=JO.ORG_ID)';
                   execute immediate iteamSql INTO molecule_xx;
                   
                   IF(molecule_xx IS NULL) THEN molecule_xx:=0;END IF;
                   IF(sx_sum >0) THEN
                       --小学差异系数--
                       CV_XX:= sqrt(molecule_xx/sx_sum);
                       dbms_output.put_line('当前CV_XX值为===================='||CV_XX);
                       
                       iteamSql:='insert into jc_JFXM_CYXS (CYID, ORG_ID, BZID, BID, JID, CYXS, XZSJ, BXLXM, BXLX, PJZ)
                           values('''||sys_guid()||''' ,'''||org.org_id ||''','''||'jj'||''','''|| batch.BID||''','''||item.JID||''','''||CV_XX||''', '''||sysdate||''', '''||'小学'||''',
                            '''||'JJ'||''','''||xx_average||''' )'; 
                       dbms_output.put_line(iteamSql);
                       execute immediate iteamSql;
                       commit;                           
                   END IF;
              end;
              begin    
                  --中学积分项平均值--
                  iteamSql:='SELECT DECODE(AVG(JFB.JFZ),NULL,0,AVG(JFB.JFZ))  FROM JC_ORG JO, Jc_Collect_Group_Batch_Org JBO 
                          JOIN jc_jfxm_dxjf JFB ON JFB.PZLID=JBO.PZLID AND JFB.JID='''|| item.JID ||''' 
                          JOIN Jc_Collect_Group_Batch JGB ON JGB.PZID=JBO.PZID  AND JGB.BID='''|| batch.BID ||'''
                          JOIN jc_collect_value JV ON JV.ORG_ID=JBO.ORG_ID AND JV.CID='''|| jxxm_id_zx ||'''   
                          WHERE JO.org_id=JBO.ORG_ID AND 
                          EXISTS (SELECT 1 FROM  JC_ORG_RELAT JOR  WHERE JOR.ORG_ID='''|| org.org_id ||''' AND JOR.ORG_ID_CHILD=JO.ORG_ID)';           
                  execute immediate iteamSql INTO zx_average; 
                        
                  --区初中学生数-- 
                  iteamSql:='SELECT DECODE(SUM(JV.CONTENT),NULL,0,SUM(JV.CONTENT)) FROM JC_ORG JO, jc_collect_value JV 
                           WHERE JO.org_id=JV.ORG_ID AND JV.CID='''|| jxxm_id_zx ||''' AND
                           EXISTS (SELECT 1 FROM  JC_ORG_RELAT JOR  WHERE JOR.ORG_ID='''|| org.org_id ||''' AND JOR.ORG_ID_CHILD=JO.ORG_ID)';
                  execute immediate iteamSql INTO sc_sum;
                  ---差异系数分子---
                  iteamSql:='SELECT SUM( POWER(JFB.JFZ-'||zx_average||',2)*JV.CONTENT*1.1 )FROM JC_ORG JO, Jc_Collect_Group_Batch_Org JBO 
                        JOIN jc_jfxm_dxjf JFB ON JFB.PZLID=JBO.PZLID AND JFB.JID='''|| item.JID ||''' 
                        JOIN jc_collect_value JV ON JV.ORG_ID=JBO.ORG_ID AND JV.CID='''|| jxxm_id_zx ||'''
                        JOIN Jc_Collect_Group_Batch JGB ON JGB.PZID=JBO.PZID AND  JGB.BID='''|| batch.BID ||'''
                        WHERE JO.ORG_ID=JBO.ORG_ID  AND  EXISTS 
                        (SELECT 1 FROM  JC_ORG_RELAT JOR  WHERE JOR.ORG_ID='''|| org.org_id ||''' AND JOR.ORG_ID_CHILD=JO.ORG_ID)';
                   execute immediate iteamSql INTO molecule_zx;
                     
                   IF(molecule_zx IS NULL) THEN molecule_zx:=0;END IF;
                         
                   IF(sc_sum >0) THEN
                   --中学差异系数--
                   CV_ZX:= sqrt(molecule_zx/sc_sum);
                   dbms_output.put_line('当前CV_ZX值为===================='||CV_ZX);
                   iteamSql:='insert into jc_JFXM_CYXS (CYID, ORG_ID, BZID, BID, JID, CYXS, XZSJ, BXLXM, BXLX, PJZ)
                       values('''||sys_guid()||''' ,'''||org.org_id ||''','''||'jj'||''','''|| batch.BID||''','''||item.JID||''','''||CV_XX||''', '''||sysdate||''', '''||'中学'||''',
                        '''||'JJ'||''','''||xx_average||''' )'; 
                   dbms_output.put_line(iteamSql);
                   execute immediate iteamSql;
                   commit;                          
                   END IF;
             end;
             end loop;
         end loop;
    end loop;     
end PRO_JC_GET_CYXS;
/

