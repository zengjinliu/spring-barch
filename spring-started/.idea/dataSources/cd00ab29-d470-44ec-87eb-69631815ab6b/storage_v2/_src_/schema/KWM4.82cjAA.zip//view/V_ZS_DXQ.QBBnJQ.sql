create view V_ZS_DXQ as
select a.APP_ID,a.dxq_id,a.dxq_mc,a.ZYS,a.XH,a.DXQ_YXZT,a.org_id,b.org_id AS xx_id,b.dxq_mxid,c.org_mc xxmc,d.org_mc,a.xzsj,e.GMB
from zs_dxq a
left join zs_dxq_mx b on a.dxq_id=b.dxq_id
left join jc_org c on b.org_id=c.org_id and c.org_state='1'
inner join jc_org d on a.org_id=d.org_id and d.org_state='1'
left join zs_xxxx e on e.org_id=b.org_id and e.app_id=a.app_id
WHERE a.DXQ_YXZT='1'
/

