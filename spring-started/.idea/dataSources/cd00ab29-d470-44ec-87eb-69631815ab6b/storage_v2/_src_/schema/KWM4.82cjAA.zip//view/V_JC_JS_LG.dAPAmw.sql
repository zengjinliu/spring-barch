create view V_JC_JS_LG as
SELECT t1.jslg_id,t1.js_id,t1.xzr,t1.xzsj,t1.gxr,t1.gxsj,t1.status,t1.jllglx,t1.sfddrsgx,t1.start_time,t1.end_time,t1.ydwmc,t1.jllgdwmc,
t2.dmmx_mc dmmx_jllglx_mc,t3.dmmx_mc dmmx_SFST_mc
 FROM JC_JS_LG T1
 LEFT JOIN JC_DMMX T2 ON T1.JLLGLX = T2.DMMX_CODE AND T2.DM_CODE = 'DM_JLLGLX'
 LEFT JOIN JC_DMMX T3 ON T1.Sfddrsgx = T3.DMMX_CODE AND T3.DM_CODE = 'DM_SFBZ'
/

