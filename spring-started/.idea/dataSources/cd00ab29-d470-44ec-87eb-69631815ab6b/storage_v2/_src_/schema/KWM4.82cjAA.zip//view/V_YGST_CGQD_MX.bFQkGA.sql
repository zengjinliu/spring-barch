create view V_YGST_CGQD_MX as
SELECT dd.spid ,sp.mc,sp.bm,dl.scdlmc,sp.dw,sp.cd,sp.gg,dd.CGQDID,dd.CGQDMXID FROM YGST_CGQD_MX DD
    left join ygst_sp sp on dd.spid = sp.spid
    left join ygst_scdl dl on dl.scdlid = sp.dlid
/

