create view V_JC_XX_XQTJ as
SELECT
X.ORG_ID as XXID,X.ORG_ID, X.XXYWMC,X.XXBXLXM,d.dmmx_mc AS XXBXLX,X.XXJBZM,x.xxjbzmc AS XXJBZMC,x.xxzgbmmc AS XXZGBMMC,''AS XXHBZ,'1' STATE,
n.dmmx_mc AS XXBBMC,DECODE(X.XXZDCXLXDM,'1','城区','2','镇区','3','乡村') AS XXZDCXLXDMC,DECODE(X.XXDJ,'0','其他','1','市一级','2','省一级','3','区县级') XXDJMC,
X.XXZGBMM,X.XD,X.ORDERID,'' AS JYJD,X.XZQH,X.LSYG,X.DZXX,X.CZDH,X.ZZJGM,X.DWFZRH,X.XZXM,X.XZGH,x.jszxsmc,x.xxbxlxmc,x.xxbbm,
X.XQR,X.FDDBRH,X.FRZSH,X.JXNY,X.XZQHM,X.XXYZBM,X.SFFSY,X.SSJD,
X.BE,X.JGZDCXLB,X.JGDZDM,X.XXKBXSM,X.XXKBXSMC,X.GBYHDBZZS,X.SFXZZXXQJYJG,
DECODE(X.SFXZZXXQJYJG,'0','否','1','是') SFXZZXXQJYJGMC,
DECODE(X.SFPHXYRY,'0','否','1','是') SFPHXYRYMC,
X.SFPHXYRY,
DECODE(X.SFCZXQPTJG,'0','否','1','是') SFCZXQPTJGMC,
X.SFCZXQPTJG,
DECODE(X.SFYLXJG,'0','否','1','是') SFYLXJGMC,
X.SFYLXJG,
DECODE(X.SFFSY,'0','否','1','是') SFFSYMC,
X.XMYEYLB,
X.XMYEYLBMC,
X.YWSSMZSYJXB,
X.FXYXXDLX,
X.FSYXXDMC,
x.JGZDCXLBMC,
X.FXYXXDLXMC,
--是否学前教育 1：是    0:否
CASE WHEN X.XXBXLXM IN ('1','11','111','119') THEN '1' ELSE '0' END AS SFXQJY ,
--是否初等教育
CASE WHEN X.XXBXLXM IN ('2','21','211','218','219','22','221','222','228','229') THEN '1' ELSE '0' END AS SFCDJY ,
--是否中等教育
CASE WHEN X.XXBXLXM IN ('3','31','311','312','319','32','321','329','33','331','332','34','341','342','345','349','35','351','352','36','361','362','363','364','365','366','368','369','37','371') THEN '1' ELSE '0' END AS SFZDJY ,
--是否高等教育
CASE WHEN X.XXBXLXM IN ('4','41','411','412','413','414','415','419','42','421','422','423','424','425','426','429') THEN '1' ELSE '0' END AS SFGDJY ,
--是否特殊教育
CASE WHEN X.XXBXLXM IN ('5','51','511','512','513','514','519') THEN '1' ELSE '0' END AS SFTSJY ,
--是否其他教育
CASE WHEN X.XXBXLXM IN ('9','91','911','92','921','93','931','932','933') THEN '1' ELSE '0' END AS SFQTJY,
JO.ORG_DM,JO.ORG_DM XXDM,JO.ORG_MC,JO.ORG_MC XXMC,JO.ORG_ORDERID,JO.ORG_DJ,
X.LXDH,X.XXDZ,X.ZYDZ,X.XZR,X.XZSJ,X.GXR,X.GXSJ,X.ZSLBM,X.XXLXM,
X.XXZDCXLXDM,X.SDGLJYXZDM,X.SDGLJYXZMC,X.SSZGJYXZDM,X.SSZGJYXZMC,X.XZSJHM,X.XXXZ,X.XXRXNL,X.CZXZ,X.CZRXNL,X.GZXZ,X.GZRXNL,X.TBRYX,X.XXTDCQ,X.TDZH,
X.JSZXSDM,X.HBGD,X.XXJD,X.XXWD,X.SZDJJSXDM,X.SZDMZSXDM,X.SZDDYSXDM,X.ZSBJ,X.ZJXYYDM,X.FZJXYYDM,X.DLSZSSMZXXDM,X.FSGXXXBS,X.FDDBR,X.XYMYM,X.SFZXXBZ,
X.SSZXX_ID,X.SJLYBZM,DECODE(X.XD,'1','幼儿','2','小学','3','初中','4','高中') XDMC,
X.SFXG,DECODE(X.SFXG,'1','是','否') SFXGMC, '' AS XXZGBMC, '' AS XXLXM_MC,
X.XWS,FN_DATE_TOSTRFORMAT(X.GKJSJ,'yyyy-mm-dd') GKJSJ ,FN_DATE_TOSTRFORMAT(X.ZZFJSJ,'yyyy-mm-dd') ZZFJSJ,
DECODE(X.SFGFH,'0','否','1','是') SFGFHMC,X.SFGFH,X.XXDJ,
--查询学校总人数
(select count(a.xsid) from jc_xs a where a.xxid = x.org_id  and a.xszt in (1)) as zrs,
--查询托班班额
nvl((select a1.BE from jc_besz a1 where a1.xxid = x.org_id  and a1.njdm = '1'),0)as tbbe,
--查询托班班数
nvl((select a2.BS from jc_bssz a2 where a2.xxid = x.org_id  and a2.njdm = '1'),0)as tbbs,
--查询小班班额
nvl((select a1.BE from jc_besz a1 where a1.xxid = x.org_id  and a1.njdm = '2'),0)as xbbe,
--查询小班班数
nvl((select a2.BS from jc_bssz a2 where a2.xxid = x.org_id  and a2.njdm = '2'),0) as xbbs,
--查询中班班额
nvl((select a1.BE from jc_besz a1 where a1.xxid = x.org_id  and a1.njdm = '3'),0)as zbbe,
--查询中班班数
nvl((select a2.BS from jc_bssz a2 where a2.xxid = x.org_id  and a2.njdm = '3'),0) as zbbs,
--查询大班班额
nvl((select a1.BE from jc_besz a1 where a1.xxid = x.org_id  and a1.njdm = '4'),0)as dbbe,
--查询大班班数
nvl((select a2.BS from jc_bssz a2 where a2.xxid = x.org_id  and a2.njdm = '4'),0)as dbbs,
--查询学位数
(nvl((select a1.BE from jc_besz a1 where a1.xxid = x.org_id  and a1.njdm = '1'),0)*
nvl((select a2.BS from jc_bssz a2 where a2.xxid = x.org_id  and a2.njdm = '1'),0) +
nvl((select a1.BE from jc_besz a1 where a1.xxid = x.org_id  and a1.njdm = '2'),0)*
nvl((select a2.BS from jc_bssz a2 where a2.xxid = x.org_id  and a2.njdm = '2'),0) +
nvl((select a1.BE from jc_besz a1 where a1.xxid = x.org_id  and a1.njdm = '3'),0)*
nvl((select a2.BS from jc_bssz a2 where a2.xxid = x.org_id  and a2.njdm = '3'),0) +
nvl((select a1.BE from jc_besz a1 where a1.xxid = x.org_id  and a1.njdm = '4'),0)*
nvl((select a2.BS from jc_bssz a2 where a2.xxid = x.org_id  and a2.njdm = '4'),0))as xwzs
FROM JC_XX X
left join jc_dmmx d on d.dm_code='DM_BXLX' and d.dmmx_code=x.xxbxlxm AND D.DMMX_STATE='1'
left join jc_dmmx n on n.dm_code='DM_BXMS' and n.dmmx_code=x.XXBBM AND n.DMMX_STATE='1'
INNER JOIN JC_ORG JO on JO.ORG_ID=X.ORG_ID AND JO.ORG_STATE='1'
/

