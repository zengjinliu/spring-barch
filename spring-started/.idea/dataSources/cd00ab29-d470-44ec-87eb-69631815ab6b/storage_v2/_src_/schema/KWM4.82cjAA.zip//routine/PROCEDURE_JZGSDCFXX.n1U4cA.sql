create procedure procedure_jzgsdcfxx -- 创建存储过程 教职工师德处分信息
  as
  tbsj date;
  begin
  select max(time_bz) into tbsj from gz_sjjh.JS_TB_BIZ_JZGSDCFXX;
  delete from JC_JS_SD_CF b where exists   (select 1 from  gz_sjjh.JS_TB_BIZ_JZGSDCFXX a where a.id=b.jssd_id and a.TIME_BZ> ( select c.updatetime from JC_DATA_TIME c  where c.model_type = 'JC_JS_SD_CF'));
  insert into JC_JS_SD_CF b (jssd_id,JS_ID,CFLB,CFYY,CFFSRQ,CFJL,CFDW,CFRQ,CFCXRQ,CFCXYY,STATUS,XZR,XZSJ)
  select j.id,
      JB.JSJB_ID,
      (select d1.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d1 where d1.zdbs='CFLB' and d1.zdxbs = j.CFLB)CFLB,
      (select d2.ZDXBM  from gz_sjjh.js_tb_cfg_zdxb d2 where d2.zdbs='CFYY' and d2.zdxbs = j.CFYY)CFYY,
      case is_date_ymd(j.Cffsrq) when 1 then  to_date(j.Cffsrq, 'yyyy-mm-dd hh24:mi:ss') else null end,
      j.Cfjlms,
      j.Cfdwmc,
      case is_date_ymd(j.Cfrq) when 1 then  to_date(j.Cfrq, 'yyyy-mm-dd hh24:mi:ss') else null end,
      case is_date_ymd(j.Cfcxrq) when 1 then  to_date(j.Cfcxrq, 'yyyy-mm-dd hh24:mi:ss') else null end,
      j.Cfcxyy,
      '1',
      'SJTB',
      sysdate
  from gz_sjjh.JS_TB_BIZ_JZGSDCFXX j
  join JC_JS_JB JB
  on j.JSID = JB.JSJB_ID
  where  j.SFSC = '0' and j.shzt='2' and j.TIME_BZ>(  select c.updatetime from JC_DATA_TIME c  where c.model_type = 'JC_JS_SD_CF');
  update JC_DATA_TIME set updatetime = tbsj where model_type = 'JC_JS_SD_CF';

   exception when others then
  dbms_output.put_line(sqlcode||'>>>>>>' || sqlerrm);
  commit;
end procedure_jzgsdcfxx;
/

