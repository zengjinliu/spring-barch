create PROCEDURE pro_bdyh_zh_jsjf_byzlshxx_bj is
cursor c_list is select * from v_zs_zh_zlshxx v where nvl(v.shzt,'2')<>'0'
and (tsbj ='异地务工人员随迁子女积分入学' or tsbj='父母有一方为珠户的非我市户籍子女')
--and tsbj ='异地务工人员随迁子女积分入学'and tsbj='父母有一方为珠户的非我市户籍子女'
and not exists(select 1 from jc_org_relat c where c.org_id='a3ddcfe111084005b8841bbc9569da15' and c.org_id_child=v.SQXXID);
xs c_list%rowtype;
v_xqjf number;--学区积分
v_jfmx varchar(1000);--积分明细
v_xqjf1 number;--学区积分
v_xqjf2 number;--学区积分
v_jfmx1 varchar(1000);--积分明细1
v_jfmx2 varchar(1000);--积分明细2

v_fcyf number;--房产月份
v_fcjf number;--房产积分
v_jzzjf1 number;--居住证积分1
v_jzzjf2 number;--居住证积分2
v_jf1 number;--房产积分与居住证积分比较1
v_jf2 number;--房产积分与居住证积分比较2
v_jzzbjjf number;--居住证积分比较最高60

v_rhys1 number;--监护人1入户月数
v_rhjf1 number;--监护人1入户积分
v_rhys2 number;--监护人2入户月数
v_rhjf2 number;--监护人2入户积分
v_rhbjjf1   number;--房产积分与入户比较积分1
v_rhbjjf2   number;--房产积分与入户比较积分2

v_zyjf1 number;--职业积分1
v_zyjf2 number;--职业积分2
v_zyjf number;--最后学区积分使用的职业积分
v_whjf number;--文化积分

v_jbyilljys1 number;--基本医疗保险累计月数1
v_sbljys1 number;--社保累计总月数
v_sbjf1 number;--社保积分

v_jbyilljys2 number;--基本医疗保险累计月数2
v_sbljys2 number;--社保累计总月数2
v_sbjf2 number;--社保积分2
v_sbbjjf number;--社保比较积分最高60
v_sbljys number;--最后学区积分使用的社保累计月数
v_jbyilljys number;--最后学区积分使用的基本医疗保险累计月数


v_jfxmjf number;--证书类别积分
v_jscode number;--计生结果
v_jsjf number;--计生
v_cnt number;--是否已经重算过积分
begin
  open c_list;
  loop fetch c_list into xs; --循环学生路由
      exit when c_list%notfound;
      v_xqjf:=0;v_xqjf1:=0;v_xqjf2:=0;
      v_fcyf:=0;
      v_fcjf:=0;
      v_jzzjf1:=0;v_jzzjf2:=0;
      v_jf1:=0;v_jzzbjjf:=0;v_jf2:=0;
      v_zyjf1:=0;v_zyjf2:=0;v_zyjf:=0;
      v_whjf:=0;
      v_jbyilljys1:=0;
      v_sbljys1:=0;
      v_sbjf1:=0;
      v_jbyilljys2:=0;
      v_sbljys2:=0;
      v_sbjf2:=0;
      v_sbljys:=0;
      v_jfxmjf:=0;
      v_jscode:='';
      v_jsjf:=0;
      v_jfmx:='';
      v_jfmx1:='';
      v_jfmx2:='';
      v_cnt:=0;
      v_sbbjjf:=0;
      v_rhys1:=0;
      v_rhjf1:=0;
      v_rhys2:=0;
      v_rhjf2:=0;
      v_rhbjjf1:=0;
      v_rhbjjf2:=0;
--居住证和房产积分计算
      if(xs.v_fcfzrq!='0' and xs.v_fccode='1')then--审核成功 --剔出必须有居住证的判断条件 and xs.v_hasjzz='1'
         v_fcyf:=round(months_between(to_date(to_char(sysdate,'yyyy')||'-08-31','yyyy-mm-dd'),
                      case when to_date(to_char(sysdate,'yyyy')||'-08-31','yyyy-mm-dd')<to_date(xs.v_fcfzrq,'yyyy-mm-dd')
                           then to_date(to_char(sysdate,'yyyy')||'-08-31','yyyy-mm-dd') else to_date(xs.v_fcfzrq,'yyyy-mm-dd') end));
         v_fcjf:=trunc(v_fcyf*10/12,1);--trunc(v_fcyf*30*10/365,1);
       end if;
       if(xs.v_hasjzz1='1' and xs.v_jt_jzzhljys1>=0 and xs.iszh1='0')then--有居住证号并且居住证月数大于0 监护人1
         v_jzzjf1:=trunc(xs.v_jt_jzzhljys1*10/12,1);--trunc(xs.v_jt_jzzhljys1*30*10/365,1);
       end if;
       if(xs.v_hasjzz2='1' and xs.v_jt_jzzhljys2>=0 and xs.iszh2='0')then--有居住证号并且居住证月数大于0 监护人2
         v_jzzjf2:=trunc(xs.v_jt_jzzhljys2*10/12,1);--trunc(xs.v_jt_jzzhljys2*30*10/365,1);
       end if;
       if(xs.iszh1='1') then --珠户1
         v_rhys1:=round(months_between(to_date(to_char(sysdate,'yyyy')||'-08-31','yyyy-mm-dd'),
                      case when to_date(to_char(sysdate,'yyyy')||'-08-31','yyyy-mm-dd')<to_date(xs.rhsj1,'yyyy-mm-dd')
                           then to_date(to_char(sysdate,'yyyy')||'-08-31','yyyy-mm-dd') else to_date(xs.rhsj1,'yyyy-mm-dd') end));
         v_rhjf1:=trunc(v_rhys1*10/12,1);
       end if;
       if(xs.iszh2='1') then --珠户2
         v_rhys2:=round(months_between(to_date(to_char(sysdate,'yyyy')||'-08-31','yyyy-mm-dd'),
                      case when to_date(to_char(sysdate,'yyyy')||'-08-31','yyyy-mm-dd')<to_date(xs.rhsj2,'yyyy-mm-dd')
                           then to_date(to_char(sysdate,'yyyy')||'-08-31','yyyy-mm-dd') else to_date(xs.rhsj2,'yyyy-mm-dd') end));
         v_rhjf2:=trunc(v_rhys2*10/12,1);
       end if;

       if(v_jzzjf1>0) then
           --比较积分
         v_jf1:=case when v_fcjf>v_jzzjf1 then case when v_fcjf>60 then 60 else v_fcjf end else 0 end;
       elsif(v_rhjf1>0) then
         v_jf1:=case when v_fcjf>v_rhjf1 then case when v_fcjf>60 then 60 else v_fcjf end else 0 end;
       elsif(v_fcjf>0) then
         v_jf1:=case when v_fcjf>60 then 60 else v_fcjf end;
       end if;

       if(v_jzzjf2>0) then
           --比较积分
         v_jf2:=case when v_fcjf>v_jzzjf2 then case when v_fcjf>60 then 60 else v_fcjf end else 0 end;
       elsif(v_rhjf2>0) then
         v_jf2:=case when v_fcjf>v_rhjf2 then case when v_fcjf>60 then 60 else v_fcjf end else 0 end;
       elsif(v_fcjf>0) then
         v_jf2:=case when v_fcjf>60 then 60 else v_fcjf end;
       end if;

       v_jzzjf1:=case when v_jzzjf1>60 then 60 else v_jzzjf1 end;
       v_jzzjf2:=case when v_jzzjf2>60 then 60 else v_jzzjf2 end;
       v_rhjf1:=case when v_rhjf1>60 then 60 else v_rhjf1 end;
       v_rhjf2:=case when v_rhjf2>60 then 60 else v_rhjf2 end;
--参保年限
       --监护人1
       v_jbyilljys1:=xs.v_jbyilljys21+xs.v_jbyilljys11;
       v_sbljys1:=xs.v_jbylljys1+xs.v_shiybxljys1+xs.v_gsbxljys1+xs.v_sybxljys1+v_jbyilljys1;--社保累计总月数
       v_sbjf1:=trunc(v_sbljys1*2/12,1);--trunc(v_sbljys1*2/12,1)
       if(v_sbjf1>0)then
          v_sbjf1:=v_sbjf1+1.7;--社保局只算到当前年份的06月 系统自动添加07/08月的社保分
       end if;
       v_sbjf1:=case when v_sbjf1>60 then 60 else v_sbjf1 end;
       --监护人2
       v_jbyilljys2:=xs.v_jbyilljys22+xs.v_jbyilljys12;
       v_sbljys2:=xs.v_jbylljys2+xs.v_shiybxljys2+xs.v_gsbxljys2+xs.v_sybxljys2+v_jbyilljys2;--社保累计总月数
       v_sbjf2:=trunc(v_sbljys2*2/12,1);--trunc(v_sbljys2*2/12,1);
       if(v_sbjf2>0)then
          v_sbjf2:=v_sbjf2+1.7;--社保局只算到当前年份的06月 系统自动添加07/08月的社保分
       end if;
       v_sbjf2:=case when v_sbjf2>60 then 60 else v_sbjf2 end;

--计生积分
       --1  查无此人
       --2  符合计划生育政策
       --3  有政策外出生子女
       --4  违反计生政策，且未缴清费用
       --5  违反计生政策，但已缴清费用
       if(xs.v_jscode='2')then
          v_jsjf:=30;
       elsif(xs.v_jscode='5') then
          v_jsjf:=15;
       end if;
--合成积分 以及积分明细
       if(v_jf1>0) then
         v_xqjf1:=v_jf1+v_zyjf1+v_whjf+v_sbjf1+v_jfxmjf+v_jsjf;--监护人1积分
       else
         v_xqjf1:=v_jzzjf1+v_rhjf1+v_zyjf1+v_whjf+v_sbjf1+v_jfxmjf+v_jsjf;--监护人1积分
       end if;
       if(v_jf2>0) then
         v_xqjf2:=v_jf2+v_zyjf2+v_whjf+v_sbjf2+v_jfxmjf+v_jsjf;--监护人2积分
       else
         v_xqjf2:=v_jzzjf2+v_rhjf2+v_zyjf2+v_whjf+v_sbjf2+v_jfxmjf+v_jsjf;--监护人2积分
       end if;
       if(v_xqjf1>=v_xqjf2) then
           if(v_jf1>0) then
             v_jfmx1:='监护人1房产年限积分：'||v_jf1;
             v_jfmx:='监护人1房产年限积分：'||v_jf1;
           elsif(v_jzzjf1>0) then
             v_jfmx1:='监护人1居住年限积分：'||v_jzzjf1;
             v_jzzbjjf:=case when v_jzzjf1>60 then 60 else v_jzzjf1 end;
             v_jfmx:='监护人1居住年限积分：'||v_jzzbjjf;
           elsif(v_rhjf1>0)then
             v_jfmx1:='监护人1入户积分：'||v_rhjf1;
             v_rhbjjf1:=v_rhjf1;
             v_jfmx:='监护人1入户积分：'||v_rhjf1;
           end if;
           if(v_jf2>0) then
              v_jfmx2:='监护人2房产年限积分：'||v_jf2;
           elsif(v_jzzjf2>0) then
              v_jfmx2:='监护人2居住年限积分：'||v_jzzjf2;
           elsif(v_rhjf2>0)then
              v_jfmx2:='监护人2入户积分：'||v_rhjf2;
           end if;
           if(v_zyjf1>0) then
             v_zyjf:=v_zyjf1;
             v_jfmx1:=v_jfmx1||' 监护人1职业资格积分：'||v_zyjf1;
             v_jfmx:=v_jfmx||' 监护人1职业资格积分：'||v_zyjf1;
           end if;
           if(v_zyjf2>0) then v_jfmx2:=v_jfmx2||' 监护人2职业资格积分：'||v_zyjf2; end if;
           if(v_whjf>0)then
               v_jfmx1:=v_jfmx1||' 监护人1文化程度积分：'||v_whjf;
               v_jfmx2:=v_jfmx2||' 监护人2文化程度积分：'||v_whjf;
               v_jfmx:=v_jfmx||' 监护人1文化程度积分：'||v_whjf;
           end if;
           if(v_sbjf1>0) then
              v_jfmx1:=v_jfmx1||' 监护人1社保积分：'||v_sbjf1;
              v_jbyilljys:=v_jbyilljys1;
              v_sbljys:=v_sbljys1;
              v_sbbjjf:=case when v_sbjf1>60 then 60 else v_sbjf1 end;
              v_jfmx:=v_jfmx||' 监护人1社保积分：'||v_sbbjjf;
           end if;
           if(v_sbjf2>0) then v_jfmx2:=v_jfmx2||' 监护人2社保积分：'||v_sbjf2; end if;
           if(v_jfxmjf>0)then
               v_jfmx1:=v_jfmx1||' 监护人1证书类别加分：'||v_jfxmjf;
               v_jfmx2:=v_jfmx2||' 监护人2证书类别加分：'||v_jfxmjf;
               v_jfmx:=v_jfmx||' 监护人1证书类别加分：'||v_jfxmjf;
            end if;
           if(v_jsjf>0) then
               v_jfmx1:=v_jfmx1||' 计生加分：'||v_jsjf;
               v_jfmx2:=v_jfmx2||' 计生加分：'||v_jsjf;
               v_jfmx:=v_jfmx||' 计生加分：'||v_jsjf;
           end if;
           v_xqjf:=v_jf1+v_jzzbjjf+v_rhbjjf1+v_zyjf1+v_whjf+v_sbbjjf+v_jfxmjf+v_jsjf;
       elsif(v_xqjf1<v_xqjf2) then
           if(v_jf1>0) then
             v_jfmx1:='监护人1房产年限积分：'||v_jf1;
           elsif(v_jzzjf1>0) then
             v_jfmx1:='监护人1居住年限积分：'||v_jzzjf1;
           elsif(v_rhjf1>0)then
              v_jfmx1:='监护人1入户积分：'||v_rhjf1;
           end if;
           if(v_jf2>0) then
              v_jfmx2:='监护人2房产年限积分：'||v_jf2;
              v_jfmx:='监护人2房产年限积分：'||v_jf2;
           elsif(v_jzzjf2>0) then
              v_jfmx2:='监护人2居住年限积分：'||v_jzzjf2;
              v_jzzbjjf:=case when v_jzzjf2>60 then 60 else v_jzzjf2 end;
              v_jfmx:='监护人2居住年限积分：'||v_jzzbjjf;
           elsif(v_rhjf2>0)then
              v_jfmx2:='监护人2入户积分：'||v_rhjf2;
              v_rhbjjf2:=v_rhjf2;
              v_jfmx:='监护人2入户积分：'||v_rhjf2;
           end if;

           if(v_zyjf2>0) then
             v_zyjf:=v_zyjf2;
             v_jfmx2:=v_jfmx2||' 监护人2职业资格积分：'||v_zyjf2;
             v_jfmx:=v_jfmx||' 监护人2职业资格积分：'||v_zyjf2;
           end if;
           if(v_zyjf1>0) then v_jfmx1:=v_jfmx1||' 监护人1职业资格积分：'||v_zyjf1; end if;
           if(v_whjf>0)then
               v_jfmx1:=v_jfmx1||' 监护人1文化程度积分：'||v_whjf;
               v_jfmx2:=v_jfmx2||' 监护人2文化程度积分：'||v_whjf;
               v_jfmx:=v_jfmx||' 监护人2文化程度积分：'||v_whjf;
           end if;
           if(v_sbjf2>0) then
              v_jfmx2:=v_jfmx2||' 监护人2社保积分：'||v_sbjf2;
              v_jbyilljys:=v_jbyilljys2;
              v_sbljys:=v_sbljys2;
              v_sbbjjf:=case when v_sbjf2>60 then 60 else v_sbjf2 end;
              v_jfmx:=v_jfmx||' 监护人2社保积分：'||v_sbbjjf;
           end if;
           if(v_sbjf1>0) then v_jfmx1:=v_jfmx1||' 监护人1社保积分：'||v_sbjf1; end if;
           if(v_jfxmjf>0)then
               v_jfmx1:=v_jfmx1||' 监护人1证书类别加分：'||v_jfxmjf;
               v_jfmx2:=v_jfmx2||' 监护人2证书类别加分：'||v_jfxmjf;
               v_jfmx:=v_jfmx||' 监护人2证书类别加分：'||v_jfxmjf;
            end if;
           if(v_jsjf>0) then
               v_jfmx1:=v_jfmx1||' 计生加分：'||v_jsjf;
               v_jfmx2:=v_jfmx2||' 计生加分：'||v_jsjf;
               v_jfmx:=v_jfmx||' 计生加分：'||v_jsjf;
           end if;
           v_xqjf:=v_jf2+v_jzzbjjf+v_rhbjjf2+v_zyjf2+v_whjf+v_sbbjjf+v_jfxmjf+v_jsjf;
       end if;
       select count(*) into v_cnt from ZS_JFMX_ZH_NOTUPDATE a where a.xsid=xs.xsid;
       if(v_cnt=0)then
         --insert into zs_jfmx_zh(
         insert into ZS_JFMX_ZH_NOTUPDATE(
         XSID,SFZJH,XQJF,JFMX,ZF_FZRQ,ZF_SHJG,ZF_FCZYS,ZF_FCJF,HASJZZ,JZZLJYS,
           JZZH,JZZJF,BJJF,ZYZGSHJG,ZYZGDJ,ZYJF,WHJF,JBYLLJYS,JBYILLJYS1,JBYILLJYS2,JBYILLJYS,SHIYBXLJYS,
           GSBXLJYS,SYBXLJYS,SBLJYS,SBJF,JFXMJF,JSJF,xzr,js_qk,
           XQJF1,JFMX1,HASJZZ1,JZZLJYS1,JZZH1,JZZJF1,ZYZGSHJG1,ZYZGDJ1,ZYJF1,JBYLLJYS1,JBYILLJYS11,JBYILLJYS21,JBYILLJYS01,
           SHIYBXLJYS1,GSBXLJYS1,SYBXLJYS1,SBLJYS1,SBJF1,
           XQJF2,JFMX2,HASJZZ2,JZZLJYS2,JZZH2,JZZJF2,ZYZGSHJG2,ZYZGDJ2,ZYJF2,JBYLLJYS2,JBYILLJYS12,JBYILLJYS22,JBYILLJYS02,
           SHIYBXLJYS2,GSBXLJYS2,SYBXLJYS2,SBLJYS2,SBJF2,Rhjf1,Rhjf2)
         values(xs.xsid,xs.sfzjh,v_xqjf,v_jfmx,to_date(xs.v_fcfzrq,'yyyy-mm-dd'),xs.v_fccode,v_fcyf,v_fcjf,xs.v_hasjzz,xs.v_jt_jzzhljys,
           xs.v_jzzh,v_jzzbjjf,v_jf1,xs.v_zyzgcode,xs.v_zyzglevel,v_zyjf,v_whjf,
           xs.v_jbylljys,xs.v_jbyilljys1,xs.v_jbyilljys2,v_jbyilljys,xs.v_shiybxljys,
           xs.v_gsbxljys,xs.v_sybxljys,v_sbljys,v_sbbjjf,v_jfxmjf,v_jsjf,'SYS',xs.v_jscode,
           v_xqjf1,v_jfmx1,xs.v_hasjzz1,xs.v_jt_jzzhljys1,xs.v_jzzh1,v_jzzjf1,xs.v_zyzgcode,xs.v_zyzglevel,v_zyjf1,xs.v_jbylljys1,
           xs.v_jbyilljys11,xs.v_jbyilljys21,v_jbyilljys1,xs.v_shiybxljys1,xs.v_gsbxljys1,xs.v_sybxljys1,v_sbljys1,v_sbjf1,
           v_xqjf2,v_jfmx2,xs.v_hasjzz2,xs.v_jt_jzzhljys2,xs.v_jzzh2,v_jzzjf2,xs.v_zyzgcode2,xs.v_zyzglevel2,v_zyjf2,xs.v_jbylljys2,
           xs.v_jbyilljys12,xs.v_jbyilljys22,v_jbyilljys2,xs.v_shiybxljys2,xs.v_gsbxljys2,xs.v_sybxljys2,v_sbljys2,v_sbjf2,v_rhjf1,v_rhjf2
           );
       else
         --update zs_jfmx_zh a set
         update ZS_JFMX_ZH_NOTUPDATE a set
         (SFZJH,XQJF,JFMX,ZF_FZRQ,ZF_SHJG,ZF_FCZYS,ZF_FCJF,HASJZZ,JZZLJYS,
         JZZH,JZZJF,BJJF,ZYZGSHJG,ZYZGDJ,ZYJF,WHJF,JBYLLJYS,JBYILLJYS1,JBYILLJYS2,JBYILLJYS,SHIYBXLJYS,
         GSBXLJYS,SYBXLJYS,SBLJYS,SBJF,JFXMJF,JSJF,xgr,xgsj,js_qk,
         XQJF1,JFMX1,HASJZZ1,JZZLJYS1,JZZH1,JZZJF1,ZYZGSHJG1,ZYZGDJ1,ZYJF1,JBYLLJYS1,JBYILLJYS11,JBYILLJYS21,JBYILLJYS01,
         SHIYBXLJYS1,GSBXLJYS1,SYBXLJYS1,SBLJYS1,SBJF1,
         XQJF2,JFMX2,HASJZZ2,JZZLJYS2,JZZH2,JZZJF2,ZYZGSHJG2,ZYZGDJ2,ZYJF2,JBYLLJYS2,JBYILLJYS12,JBYILLJYS22,JBYILLJYS02,
         SHIYBXLJYS2,GSBXLJYS2,SYBXLJYS2,SBLJYS2,SBJF2,Rhjf1,Rhjf2)=
         (select xs.sfzjh,v_xqjf,v_jfmx,to_date(xs.v_fcfzrq,'yyyy-mm-dd'),xs.v_fccode,v_fcyf,v_fcjf,xs.v_hasjzz,xs.v_jt_jzzhljys,
         xs.v_jzzh,v_jzzbjjf,v_jf1,xs.v_zyzgcode,xs.v_zyzglevel,v_zyjf,v_whjf,xs.v_jbylljys,xs.v_jbyilljys1,xs.v_jbyilljys2,v_jbyilljys,xs.v_shiybxljys,
         xs.v_gsbxljys,xs.v_sybxljys,v_sbljys,v_sbbjjf,v_jfxmjf,v_jsjf,'SYS',sysdate,xs.v_jscode,
         v_xqjf1,v_jfmx1,xs.v_hasjzz1,xs.v_jt_jzzhljys1,xs.v_jzzh1,v_jzzjf1,xs.v_zyzgcode,xs.v_zyzglevel,v_zyjf1,xs.v_jbylljys1,
         xs.v_jbyilljys11,xs.v_jbyilljys21,v_jbyilljys1,xs.v_shiybxljys1,xs.v_gsbxljys1,xs.v_sybxljys1,v_sbljys1,v_sbjf1,
         v_xqjf2,v_jfmx2,xs.v_hasjzz2,xs.v_jt_jzzhljys2,xs.v_jzzh2,v_jzzjf2,xs.v_zyzgcode2,xs.v_zyzglevel2,v_zyjf2,xs.v_jbylljys2,
         xs.v_jbyilljys12,xs.v_jbyilljys22,v_jbyilljys2,xs.v_shiybxljys2,xs.v_gsbxljys2,xs.v_sybxljys2,v_sbljys2,v_sbjf2,v_rhjf1,v_rhjf2
         from dual)
         where a.xsid=xs.xsid;
       end if;
       --update zs_xsxx a set a.xqjf=v_xqjf,a.jfmx=v_jfmx where a.xsid=xs.xsid;
       commit;
    end loop;
  --EXCEPTION
  -- WHEN OTHERS THEN
  --  ROLLBACK;
end pro_bdyh_zh_jsjf_byzlshxx_bj;
/

