create view V_JC_JS_ZS_QTJN as
SELECT t1.jszs_id,t1.js_id,t1.xzr,t1.xzsj,t1.gxr,t1.gxsj,t1.status,t1."QTJNMC",t1."QTJNCD",t3.dmmx_mc dmmx_ZWCD_mc
FROM JC_JS_ZS_QTJN T1
LEFT JOIN JC_DMMX T3 ON T1.QTJNCD = T3.DMMX_CODE AND T3.DM_CODE = 'DM_ZWCD'
/

