create view V_JC_JS_KH as
SELECT t1.jskh_id,t1.js_id,t1.xzr,t1.xzsj,t1.gxr,t1.gxsj,t1.status,t1."KHND",t1."KHJG",t1."KHDWMC",t2.dmmx_mc dmmx_KHJG_mc FROM JC_JS_KH T1
LEFT JOIN JC_DMMX T2 ON T1.KHJG = T2.DMMX_CODE AND T2.DM_CODE = 'DM_KHJG'
/

