create view V_ZJCJ as
select
a.xsid XSID,a.xm XM,a.XB,a.xbm,a.HJLXM,a.CQR,a.JT_SBDNH1 as SBDNH,a.JT_CBR,a.SFZJLXMC as SFZJMC,a.HJLXMC as HJMC,a.FCLBMC AS FCLBMC,a.JT_SFZJLXMC1 AS SFZJMC1,a.JT_SFZJLXMC2 AS SFZJMC2,
a.TSBJ as TSBJ,a.EXT34 as EXT34,
case when a.HJLXM in ('01','02','07') then '深圳户籍'
when a.HJLXM in ('05') then '台湾'
when a.HJLXM in ('04') then '港澳'
else '非深户户籍' end AS HJLXMC,
a.sfzjlxm SFZJLXM,
a.sfzjh SFZJH,
a.PWD,
a.LSH,
a.org_id ORGID,
a.org_id ORG_ID,
org.org_mc ORGMC,
a.APP_ID APP_ID,
app.app_mc APP_MC,
a.JT_XM1,
a.JT_XM2,
a.JT_SFZJH1,
a.JT_SFZJH2,
a.JT_LXDH1,
a.JT_LXDH2,
a.SFZJLXM sfzjlx,
a.CJLXMC,
a.QGXJH,
'0' sfz_shzt,
'0' jzz_shzt,
'0' sb_shzt,
'0' fc_shzt,
'0' zl_shzt,
'0' js_shzt,
'1' AS BLR,
'1' AS BLRZP,
'1' AS QZXX,
case when a.HJLXM in ('01','02','07') then '1'
when a.HJLXM in ('05') then '3'
when a.HJLXM in ('04') then '4'
else '2' end AS HJLB,
'1' AS JHR1JYLB,
'1' AS JHR2JYLB,
'1' AS YHLB,
'1' AS JDXX,
'1' AS ISDQ,
'1' AS ISGUER,
'1' AS QTXX,
case when a.HJLXM in ('01','02','07') then '1'
when a.HJLXM in ('05') then '3'
when a.HJLXM in ('04') then '4'
else '2' end AS SFZ,
case when a.FCLB in (01,22,29,21,52) then '1'
when a.FCLB in (02,26,27,28,31,20,54) then '2'
when a.FCLB in (03,24,30,53) then '3'
when a.FCLB in (08,09,15,16,17) then '4'
when a.FCLB in (04,05,06,10,11,12,13,14) then '5'
when a.FCLB in (33) then '10'
when a.FCLB in (34) then '11'
else '6' end AS ZFLB,
case when a.js_qk='独生子女' then '1'
else '2' end AS JSLB,
case when a.jt_sfzjlx1='1' then '1'
else '2' end AS jt_sfzjlx1,
case when a.SFDQ='1' then '2'
else '1' end AS jt_sfzjlx2,
case when a.JT_SBDNH1 is not null then '1'
else '2' end AS JT_SBDNH1,
case when a.JT_SBDNH2 is not null then '1'
else '2' end AS JT_SBDNH2,
case when a.JT_ISJZZH1='' then '3'
when a.JT_ISJZZH1='1' then '1'
else '2' end AS JT_ISJZZH1,
case when a.JT_ISJZZH2='' then '3'
when a.JT_ISJZZH2='1' then '1'
else '2' end AS JT_ISJZZH2,
case when a.BY_SZDM like'4401%' then '1' else '0' end AS BY_SZDM,
--补充证件数据（比如户口地址之类的）
a.HKBHZ,a.HKSSPCS,a.HKXXDZ,a.HZGX,
a.FCDZ,a.FCZH,a.CQR_SFZJH,a.DJBARQ,a.JT_YLBXYS1,a.JT_YILBXYS1,a.FZRQ,
--顺德
case when a.TSBJ in('本镇户籍生','高层次人才子女','政策性借读生','普通借读生') then '1' else '0' end SDZJ,--顺德公共证件
case when a.TSBJ in('高层次人才子女') then '1' else '0' end SDZSSQ, --顺德 政审申请表
case when a.TSBJ in('政策性借读生') then '1' else '0' end SDJHRSFZJ,--顺德 身份证件
case when a.TSBJ in('政策性借读生') then '1' else '0' end SDJZZ--顺德 居住证
,
--孝感
case when  a.TSBJ in('居民子女') then 1
when a.TSBJ in('随迁子女') then 2
when a.TSBJ in('政策优待人员子女') and YHDXM in('符合优待政策的军人') then 3
when a.TSBJ in('政策优待人员子女') and YHDXM in('招商引资') then 4
when a.TSBJ in('政策优待人员子女') and YHDXM in('人才引进') then 5
else 6 end XGTSGJ
from v_zs_xsxx a
left join jc_org org on org.org_id=a.org_id
left join jc_app app on app.app_id=a.app_id
where a.SHZT>'0'
/

