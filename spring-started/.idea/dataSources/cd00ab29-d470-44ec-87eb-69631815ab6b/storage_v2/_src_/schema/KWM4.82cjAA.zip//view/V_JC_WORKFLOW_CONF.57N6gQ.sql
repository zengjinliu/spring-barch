create view V_JC_WORKFLOW_CONF as
select j1."UUID",j1."WORKFLOWNAME",j1."WORKFLOWCODE",j1."NODENAME",j1."NODECODE",j1."NEXTNODE",j1."XZR",j1."XZSJ",j1."GXR",j1."GXSJ",j1."STATE",j2.nodecode "NEXTNODECODE" from jc_workflow_conf j1
LEFT JOIN jc_workflow_conf j2 ON j1.nextnode = j2.uuid
/

