create view V_JC_JS_KY_ZZ_CJ as
SELECT zs.jsky_id as zsid,t1.jsky_id,t1.js_id,t1.xzr,t1.xzsj,t1.gxr,t1.gxsj,t1.status,t1."ZZLB",t1."BRJS",t1."ZZMC",t1."XKLY",to_char(t1."CBRQ",'YYYY-MM-DD')as CBRQ ,t1."CBH",t1."ZZS",t1."BRZS",t1."CBSMC",t2.dmmx_mc dmmx_BRJS_mc,t3.dmmx_mc dmmx_ZZLB_mc FROM JC_JS_KY_ZZ_CJ T1
LEFT JOIN jc_js_ky_zz zs ON T1.JSKY_ID = zs.jsky_id
LEFT JOIN JC_DMMX T2 ON T1.BRJS = T2.DMMX_CODE AND T2.DM_CODE = 'DM_BRJS'
LEFT JOIN JC_DMMX T3 ON T1.ZZLB = T3.DMMX_CODE AND T3.DM_CODE = 'DW_JSZZLB'
/

