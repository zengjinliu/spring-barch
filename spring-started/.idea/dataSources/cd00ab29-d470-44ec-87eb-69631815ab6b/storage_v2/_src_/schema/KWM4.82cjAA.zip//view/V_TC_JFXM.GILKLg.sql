create view V_TC_JFXM as
select A.JFID,A.JFXMMC,A.DW_CODE,A.XSWS,A.JSGS,A.ORGID ORG_ID,APPID,
case when (exists(select 1 from TC_CSXM_JFXM B where A.JFID=B.JFID) or exists(select 1 from TC_JFXM_PGBZ C where A.JFID=C.JFID)
  or exists(select 1 from Tc_Zbfz D where A.JFID=D.JFID)) then '1' else '0' end isuse
from TC_JFXM A
/

