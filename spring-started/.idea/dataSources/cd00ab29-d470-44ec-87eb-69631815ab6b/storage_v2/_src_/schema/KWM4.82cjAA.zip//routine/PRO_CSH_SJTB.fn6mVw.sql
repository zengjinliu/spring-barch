create procedure PRO_CSH_SJTB
is 
v_tbsj date:=sysdate;
cursor xss is 
select a.* from csh_user a where a.tbsj>(select tbsj from csh_tbsj);
xs xss%rowtype ;
v_count number;
v_xx_count number;
v_xxid varchar2(32);
v_userid_count number;
v_userid varchar2(200);
begin
  open xss;
    loop
      fetch xss into xs;
      exit when xss%notfound;     
      v_count:=0;
      v_xx_count:=0;
      v_xxid:=0;
      v_userid_count:=0;
      if(xs.loginid='0') then 
        v_userid:='000';
      else
        v_userid:=xs.loginid;                                
      end if;
      select count(*) into v_xx_count from ns_tc_org a left join jc_org b on a.org_dm=b.org_dm where b.org_dm=xs.ou;
      if(v_xx_count=1) then 
          select b.org_id into v_xxid from ns_tc_org a left join jc_org b on a.org_dm=b.org_dm where b.org_dm=xs.ou;
          --老师
          if(xs.usertype in ('0000','0001')) then          
             select count(*) into v_count from jc_user a where a.jk_uuid=xs.uid_;
                if(v_count>0) then 
                    --更新帐号
                    update jc_user a set a.u_userid=v_userid,a.u_username=xs.cn,a.org_id=v_xxid 
                    where a.jk_uuid=xs.uid_;
                    commit;
                else
                   select count(*) into v_userid_count from jc_user a where a.u_userid=v_userid;
                   if(v_userid_count=0) then                
                     --新增帐号
                     insert into jc_user(u_id,u_userid,u_pwd,u_state,xzr,xzsj,u_username,org_id,jk_uuid)
                     values(fn_uuid,v_userid,fn_md5('kiway123'),'1','kiway',fn_sysdate,xs.cn,v_xxid,xs.uid_);                                   
                     commit;
                   end if;
                 end if;
          end if;      
          commit;
      end if;
    end loop;
    --更新同步时间   
    update csh_tbsj a set a.tbsj=v_tbsj;
    commit;
  close xss;
     EXCEPTION
      when others then
        rollback;
  end PRO_CSH_SJTB;
/

