create view V_TREE_TEMP as
select t."ORG_ID",t."ORG_DM",t."ORG_MC",'' ORG_JC,t."ORG_ORDERID",t."ORG_STATE",t."DJ_LEVEL",t."DJ_MC" ,
r.org_id as r_org_id ,r.org_id_child
from v_jc_org t left join jc_org_relat r on r.org_id=t.ORG_ID or r.org_id_child = t.ORG_ID
--select t.* ,r.org_id ,r.org_id_child from v_org t left join jc_org_relat r on r.org_id<>t.ORG_ID and r.org_id_child = t.ORG_ID
/

