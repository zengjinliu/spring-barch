create view V_JC_ORG_NJ as
select b.org_id,b.org_mc,nvl(a.orgid,'0') ishave,b.org_dm,b.org_orderid,
a.jyjd,c.dmmx_mc jyjd_n,a.xjnjdm,a.xz,a.xx_org_id,a.orgid,
a.xx_org_id xxorg_id,e.org_dm xxorg_dm,e.org_mc xxorg_mc,e.ORG_ORDERID xxorg_orderid,
d.dmmx_mc xjnjdm_n
from jc_org b
left join jc_org_nj a on b.org_id=a.orgid
left join jc_org e on e.ORG_ID=a.xx_org_id and e.org_state='1'
left join jc_dmmx c on c.dm_code='DM_BXCC' and a.jyjd=c.dmmx_code and c.dmmx_state='1'
left join jc_dmmx d on d.dm_code='DM_NJDM' and a.xjnjdm=d.dmmx_code and d.dmmx_state='1'
where b.org_state='1' and b.org_dj=(select nvl(z.con_value,'100') from jc_const z where z.con_key='JC_NJDJDM')
/

