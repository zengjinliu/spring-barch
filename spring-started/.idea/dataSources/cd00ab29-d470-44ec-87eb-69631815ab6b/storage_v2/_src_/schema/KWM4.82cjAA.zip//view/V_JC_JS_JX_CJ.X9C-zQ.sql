create view V_JC_JS_JX_CJ as
SELECT zs.jsjx_id as zsid,t1.op_id,t1.jsjx_id,t1.js_id,t1.xzr,t1.xzsj,t1.gxr,t1.gxsj,t1.status,t1."JXND",t1."JXXQ",t1."RJXD",t1."RKZK",t1."QTRKZK",t1."RJKC",t1."MZKS",t1."MZQTGZZHKS",t1."JRGZ",t1."JRGZMC",t2.dmmx_mc dmmx_JRGZ_mc,t3.dmmx_mc dmmx_JXXQ_mc
,t4.dmmx_mc dmmx_RJXD_mc,t5.dmmx_mc dmmx_RKZK_mc FROM JC_JS_JX_CJ T1
LEFT JOIN jc_js_jx zs ON T1.JSJX_ID = zs.jsjx_id
LEFT JOIN JC_DMMX T2 ON T1.JRGZ = T2.DMMX_CODE AND T2.DM_CODE = 'DM_JSJRGZ'
LEFT JOIN JC_DMMX T3 ON T1.JXXQ = T3.DMMX_CODE AND T3.DM_CODE = 'DM_XQ'
LEFT JOIN JC_DMMX T4 ON T1.RJXD = T4.DMMX_CODE AND T4.DM_CODE = 'DM_XD'
LEFT JOIN JC_DMMX T5 ON T1.RKZK = T5.DMMX_CODE AND T5.DM_CODE = 'DM_RKZK'
/

