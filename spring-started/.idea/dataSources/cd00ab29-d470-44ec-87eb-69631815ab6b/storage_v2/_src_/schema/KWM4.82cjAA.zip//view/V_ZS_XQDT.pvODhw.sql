create view V_ZS_XQDT as
select xx.XQT_XH as xh,dt.ORG_ID,xx.APP_ID,dt.MAPDATA,dt.XZR,dt.XZSJ,dt.GXR,dt.GXSJ,dt.POINTX,dt.POINTY,
REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(org.org_mc, '深圳市' ,''), '龙岗区' ,''), '罗湖区' ,''), '光明新区' ,''), '坪山新区' ,'') as MC
,xx.LXDH as DH,xx.XXDZ as DZ,xx.ZYDZ as WZ,xx.ZSDDS as XQ
from zs_xqdt dt
left join jc_org org on org.org_id=dt.org_id
left join v_zs_xxxx xx on xx.ORG_ID=dt.org_id
/

