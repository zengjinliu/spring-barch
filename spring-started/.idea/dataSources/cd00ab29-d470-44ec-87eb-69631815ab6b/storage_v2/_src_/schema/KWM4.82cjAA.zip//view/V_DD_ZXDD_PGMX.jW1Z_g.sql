create view V_DD_ZXDD_PGMX as
SELECT
DPM.MXID,DPM.DZS_ID,DPM.SDJCMB_ORG_ID,DPM.DZP_ID,DPM.S_LEVEL,DPM.S_FZ,DPM.CZWT,DPM.PGR,DPM.PGSJ,DPM.CL_ID,DPM.ORG_ID,DPM.APP_ID,DPM.GXR,DPM.GXSJ,
DP.XH,DP.EXPRESSION,dmmx.dmmx_mc as typemc,dp.type,DP.ZBFZ,DP.CONTENT,DP.PARENTID,DP.ROOTID,DP.PLEVEL,dp.pfxz,DP.STATUS,DP.PID
FROM DD_POINT DP
left JOIN DD_ZXDD_PGMX DPM ON DP.PID = DPM.PID --OR DP.PARENTID = DPM.PID OR DP.ROOTID = DPM.PID
left join jc_dmmx dmmx on dmmx.dm_code='DM_GCDLBM' and DP.type=dmmx.dmmx_code and dmmx.dmmx_state='1'
left join JC_DMTAB dmt on dmt.dm_code='DM_GCDLBM' and  dmt.dm_state='1'
/

