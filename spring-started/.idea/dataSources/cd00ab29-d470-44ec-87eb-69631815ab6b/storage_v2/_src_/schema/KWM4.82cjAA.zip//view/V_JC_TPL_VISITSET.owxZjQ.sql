create view V_JC_TPL_VISITSET as
select jtv.SET_ID AS SET_ID,jtv.ORG_ID AS ORG_ID,jtv.TPL_ID AS TPL_ID,jtv.PRO_ID AS PRO_ID,
jt.TPL AS TPL,jt.TPL_TYPE AS TPL_TYPE,jt.TPL_SYLB AS TPL_SYLB,jtv.XZR AS XZR,jtv.XZSJ AS XZSJ,
jtv.GXR AS GXR,jtv.GXSJ AS GXSJ,t2.DJ_LEVEL AS DJ_LEVEL,jt.TPL_MC,t1.ORG_MC,jp.PRO_MC from jc_tpl_visitset jtv
left join jc_tpl jt on jtv.TPL_ID = jt.TPL_ID
left join jc_org t1 on jtv.ORG_ID = t1.ORG_ID
left join jc_org_dj t2 on t1.ORG_DJ = t2.DJ_DM
left join jc_product jp on jtv.pro_id = jp.pro_id
where jt.TPL_YXZT = '1'
/

