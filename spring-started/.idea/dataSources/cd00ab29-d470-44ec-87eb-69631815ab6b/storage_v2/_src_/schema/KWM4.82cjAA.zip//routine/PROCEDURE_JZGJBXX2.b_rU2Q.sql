create procedure procedure_jzgjbxx2 -- 创建存储过程  教职工基本信息
  as
   tbsj date;
  begin
  select max(time_bz) into tbsj from gz_sjjh.JS_TB_BIZ_JZGJBXX;
    update JC_JS_JB b set
  (JS_ID,xm,XBM,SFZJH,org_id,MZM,GJDQM,CSRQ,SFZJLXM,TJNY,JZGLB,SFZB,YRXS,QDHT,SFSF,SFTJPX,SFTJZS,XXJS,SFMFSF,
  SJJC,JCQSNY,JCJSNY,SFTJJS,SFSSJS,SFJNZS,QYGZSC,SFXJGG,SFXLJS,RYZT,XYJG,JKZKM,JZGLY,CSDM,JG,GH,ZZMMM,GZNY,HYZKM,ZGXLYX,SFXQ,STATUS,gxr,gxsj)
       = (select
      j.id,
       j.xm,
      (select d1.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d1 where d1.zdbs='XB' and d1.zdxbs = j.xb) XB,
       j.sfzjh,
--       j.XXJGID,
       CASE WHEN xx.org_id is null THEN  'JS_'||t.xxjgbsm ELSE xx.org_id END,
       (select d2.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d2 where d2.zdbs='MZ' and d2.zdxbs = j.mz) MZ,
       (select d3.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d3 where d3.zdbs='GJDQ' and d3.zdxbs = j.gjdq) GJDQ,
       case is_date(j.CSRQ) when 1 then  to_date(j.CSRQ , 'yyyy-mm-dd hh24:mi:ss') else to_date('1900/01/01','yyyy/mm/dd') end,
       (select d4.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d4 where d4.zdbs='SFZJLX' and d4.zdxbs = j.sfzjlx) SFZJLX,
       j.cstjqsny,
       (select d5.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d5 where d5.zdbs='JZGLB' and d5.zdxbs = j.Jzglb) JZGLB,
       (select d6.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d6 where d6.zdbs='SFZB' and d6.zdxbs = j.sfzb) SFZB,
       (select d7.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d7 where d7.zdbs='YRXS' and d7.zdxbs = j.YRXS) YRXS,
       (select d8.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d8 where d8.zdbs='QDHTQK' and d8.zdxbs = j.QDHTQK) QDHTQK,
       (select d9.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d9 where d9.zdbs='SFSFLZYBY' and d9.zdxbs = j.SFSFLZYBY) SFSFLZYBY,
--       (select d10.zdxbm  from js_tb_cfg_zdxb d10 where d10.zdbs='SFXQJYZYBY' and d10.zdxbs = j.SFXQJYZYBY) SFXQJYZYBY,
--       (select d11.zdxbm  from js_tb_cfg_zdxb d11 where d11.zdbs='SFQRZTSYJZYBY' and d11.zdxbs = j.SFQRZTSYJZYBY) SFQRZTSYJZYBY,
       (select d12.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d12 where d12.zdbs='SFSGTJZYPYPX' and d12.zdxbs = j.SFSGTJZYPYPX) SFSGTJZYPYPX,
       (select d13.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d13 where d13.zdbs='SFYTSJYCYZS' and d13.zdxbs = j.SFYTSJYCYZS) SFYTSJYCYZS,
       (select d14.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d14 where d14.zdbs='XXJSYYNL' and d14.zdxbs = j.XXJSYYNL) XXJSYYNL,
       (select d15.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d15 where d15.zdbs='SFSYMFSFS' and d15.zdxbs = j.SFSYMFSFS) SFSYMFSFS,
       (select d16.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d16 where d16.zdbs='SFSTGJS' and d16.zdxbs = j.SFSTGJS) SFSTGJS,
       j.CJJCFWXMQSNY,
       j.CJJCFWXMJSNY,
       (select d17.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d17 where d17.zdbs='SFSTJJS' and d17.zdxbs = j.SFSTJJS) SFSTJJS,
       (select d18.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d18 where d18.zdbs='SFSS' and d18.zdxbs = j.SFSS) SFSS,
       (select d29.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d29 where d29.zdbs='SFJBZYJNDJZS' and d29.zdxbs = j.SFJBZYJNDJZS) SFJBZYJNDJZS,
       (select d19.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d19 where d19.zdbs='QYGZSJSC' and d19.zdxbs = j.QYGZSJSC) QYGZSJSC,
       (select d20.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d20 where d20.zdbs='SFXJJYSGGJS' and d20.zdxbs = j.SFXJJYSGGJS) SFXJJYSGGJS,
       (select d21.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d21 where d21.zdbs='SFXLJKJYJS' and d21.zdxbs = j.SFXLJKJYJS) SFXLJKJYJS,
       (select d22.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d22 where d22.zdbs='ZGQK' and d22.zdxbs = j.ZGQK) ZGQK,
       (select d23.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d23 where d23.zdbs='XYJG' and d23.zdxbs = j.XYJG) XYJG,
       (select d24.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d24 where d24.zdbs='JKZK' and d24.zdxbs = j.JKZK) JKZK,
       (select d25.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d25 where d25.zdbs='JZGLY' and d25.zdxbs = j.JZGLY) JZGLY,
       j.CSD,
       j.JG,
       j.jzgh,
       (select d28.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d28 where d28.zdbs='ZZMM' and d28.zdxbs = j.ZZMM) ZZMM,
       j.cjgzny,
       (select d27.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d27 where d27.zdbs='HYZK' and d27.zdxbs = j.HYZK) HYZK,
       J.HDZGXLDYXHJG,
       (select d26.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d26 where d26.zdbs='SFSGXQJYZYPYPX' and d26.zdxbs = j.SFSGXQJYZYPYPX) SFSGXQJYZYPYPX,
       case when j.sfsc = '1' then 0 else 1 end,
       'SJTB',
       sysdate
   from  gz_sjjh.JS_TB_BIZ_JZGJBXX j
   join gz_sjjh.js_tb_mst_xxjgdm t
   on t.uuid = j.xxjgid
   left join jc_org xx
   on  xx.org_dm =  t.xxjgbsm
   where j.id=b.JSJB_ID and j.TIME_BZ> ( select c.updatetime from JC_DATA_TIME c where c.model_type = 'JC_JS_JB'))
   where exists (select 1 from  gz_sjjh.JS_TB_BIZ_JZGJBXX j where j.id=b.JSJB_ID and j.TIME_BZ> ( select c.updatetime from JC_DATA_TIME c where c.model_type = 'JC_JS_JB'));
  insert into JC_JS_JB b (JSJB_ID,JS_ID,pro_id,xm,XBM,SFZJH,org_id,MZM,GJDQM,CSRQ,SFZJLXM,TJNY,JZGLB,SFZB,YRXS,QDHT,SFSF,SFTJPX,SFTJZS,XXJS,SFMFSF,SJJC,JCQSNY,JCJSNY,SFTJJS,SFSSJS,SFJNZS,QYGZSC,SFXJGG,SFXLJS,RYZT,XYJG,JKZKM,JZGLY,CSDM,JG,GH,ZZMMM,GZNY,HYZKM,ZGXLYX,SFXQ,STATUS,xzr,xzsj)
select j.id,j.id,
       '7DFC6FE55F4B3D2EE05502505694B75A' pro_id,
       j.xm,
      (select d1.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d1 where d1.zdbs='XB' and d1.zdxbs = j.xb) XB,
       j.sfzjh,
--       j.XXJGID,
       CASE WHEN xx.org_id is null THEN  'JS_'||t.xxjgbsm ELSE xx.org_id END,
       (select d2.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d2 where d2.zdbs='MZ' and d2.zdxbs = j.mz) MZ,
       (select d3.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d3 where d3.zdbs='GJDQ' and d3.zdxbs = j.gjdq) GJDQ,
       case is_date(j.CSRQ) when 1 then  to_date(j.CSRQ , 'yyyy-mm-dd hh24:mi:ss') else to_date('1900/01/01','yyyy/mm/dd') end,
       (select d4.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d4 where d4.zdbs='SFZJLX' and d4.zdxbs = j.sfzjlx) SFZJLX,
       j.cstjqsny,
       (select d5.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d5 where d5.zdbs='JZGLB' and d5.zdxbs = j.Jzglb) JZGLB,
       (select d6.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d6 where d6.zdbs='SFZB' and d6.zdxbs = j.sfzb) SFZB,
       (select d7.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d7 where d7.zdbs='YRXS' and d7.zdxbs = j.YRXS) YRXS,
       (select d8.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d8 where d8.zdbs='QDHTQK' and d8.zdxbs = j.QDHTQK) QDHTQK,
       (select d9.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d9 where d9.zdbs='SFSFLZYBY' and d9.zdxbs = j.SFSFLZYBY) SFSFLZYBY,
--       (select d10.zdxbm  from js_tb_cfg_zdxb d10 where d10.zdbs='SFXQJYZYBY' and d10.zdxbs = j.SFXQJYZYBY) SFXQJYZYBY,
--       (select d11.zdxbm  from js_tb_cfg_zdxb d11 where d11.zdbs='SFQRZTSYJZYBY' and d11.zdxbs = j.SFQRZTSYJZYBY) SFQRZTSYJZYBY,
       (select d12.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d12 where d12.zdbs='SFSGTJZYPYPX' and d12.zdxbs = j.SFSGTJZYPYPX) SFSGTJZYPYPX,
       (select d13.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d13 where d13.zdbs='SFYTSJYCYZS' and d13.zdxbs = j.SFYTSJYCYZS) SFYTSJYCYZS,
       (select d14.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d14 where d14.zdbs='XXJSYYNL' and d14.zdxbs = j.XXJSYYNL) XXJSYYNL,
       (select d15.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d15 where d15.zdbs='SFSYMFSFS' and d15.zdxbs = j.SFSYMFSFS) SFSYMFSFS,
       (select d16.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d16 where d16.zdbs='SFSTGJS' and d16.zdxbs = j.SFSTGJS) SFSTGJS,
       j.CJJCFWXMQSNY,
       j.CJJCFWXMJSNY,
       (select d17.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d17 where d17.zdbs='SFSTJJS' and d17.zdxbs = j.SFSTJJS) SFSTJJS,
       (select d18.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d18 where d18.zdbs='SFSS' and d18.zdxbs = j.SFSS) SFSS,
       (select d29.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d29 where d29.zdbs='SFJBZYJNDJZS' and d29.zdxbs = j.SFJBZYJNDJZS) SFJBZYJNDJZS,
       (select d19.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d19 where d19.zdbs='QYGZSJSC' and d19.zdxbs = j.QYGZSJSC) QYGZSJSC,
       (select d20.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d20 where d20.zdbs='SFXJJYSGGJS' and d20.zdxbs = j.SFXJJYSGGJS) SFXJJYSGGJS,
       (select d21.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d21 where d21.zdbs='SFXLJKJYJS' and d21.zdxbs = j.SFXLJKJYJS) SFXLJKJYJS,
       (select d22.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d22 where d22.zdbs='ZGQK' and d22.zdxbs = j.ZGQK) ZGQK,
       (select d23.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d23 where d23.zdbs='XYJG' and d23.zdxbs = j.XYJG) XYJG,
       (select d24.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d24 where d24.zdbs='JKZK' and d24.zdxbs = j.JKZK) JKZK,
       (select d25.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d25 where d25.zdbs='JZGLY' and d25.zdxbs = j.JZGLY) JZGLY,
       j.CSD,
       j.JG,
       j.jzgh,
       (select d28.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d28 where d28.zdbs='ZZMM' and d28.zdxbs = j.ZZMM) ZZMM,
       j.cjgzny,
       (select d27.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d27 where d27.zdbs='HYZK' and d27.zdxbs = j.HYZK) HYZK,
       J.HDZGXLDYXHJG,
       (select d26.zdxbm  from gz_sjjh.js_tb_cfg_zdxb d26 where d26.zdbs='SFSGXQJYZYPYPX' and d26.zdxbs = j.SFSGXQJYZYPYPX) SFSGXQJYZYPYPX,
       '1',
       'SJTB',
       sysdate
--       xx.org_mc,
--       j.id
  from gz_sjjh.JS_TB_BIZ_JZGJBXX j
  join gz_sjjh.js_tb_mst_xxjgdm t
    on t.uuid = j.xxjgid
   left join jc_org xx
   on  xx.org_dm =  t.xxjgbsm
  where j.sfsc ='0' and j.dazt='1' and j.cczt='1' and j.shzt='2' and j.TIME_BZ>(  select c.updatetime from JC_DATA_TIME c  where c.model_type = 'JC_JS_JB')
  AND not exists (select 1 from JC_JS_JB js where js.js_id = j.id);
  update JC_DATA_TIME set updatetime = tbsj where model_type = 'JC_JS_JB';

   exception when others then
  dbms_output.put_line(sqlcode||'>>>>>>' || sqlerrm);
  commit;
end procedure_jzgjbxx2;
/

