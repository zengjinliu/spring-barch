create view V_YGST_DDMX as
SELECT dd.spid ,sp.mc,sp.bm,dl.scdlmc,sp.dw,sp.cd,sp.gg,sp.pj,sp.bz ,dd.ddid,dd.ddmxid ,dd.sl FROM YGST_DDMX DD
    left join ygst_sp sp on dd.spid = sp.spid
    left join ygst_scdl dl on dl.scdlid = sp.dlid
/

