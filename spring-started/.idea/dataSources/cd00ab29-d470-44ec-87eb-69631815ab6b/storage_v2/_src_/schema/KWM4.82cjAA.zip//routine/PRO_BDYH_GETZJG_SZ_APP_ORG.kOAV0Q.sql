create PROCEDURE PRO_BDYH_GETZJG_SZ_APP_ORG(p_appid in varchar2,p_orgid in varchar2) IS
  cursor c_list is select * from v_smbd_bmshjg v where v.ZJG in ('0','2') and shzt='2' and exists(select 1 from jc_org_relat c where c.org_id=p_orgid and c.org_id_child=v.sqxxid1)AND v.APP_ID =p_appid AND exists(select 1 from smbd_shjg b where b.xsid=v.xsid);
  xs c_list%rowtype;
  v_xsid varchar(32);
BEGIN
  open c_list;
  loop fetch c_list into xs;
    exit when c_list%notfound;
      v_xsid := xs.xsid;
      pro_bdyh_getzjg_sz_byxsid_in(v_xsid,'sys');
  end loop;
  close c_list;
end PRO_BDYH_GETZJG_SZ_APP_ORG;
/

