create view V_YGST_SHDJSDMX as
select sh.xxgysid,sh.gysid,sp.dlid as scdlid,mx.spid,to_char(jg.jg) as spjg,to_char(mx.sl) as spsl,
to_char(mx.xsyl) xsyl, to_char(mx.jssl) jssl, to_char(mx.jdsl) jdsl,
 to_char((mx.xsyl+mx.jssl+mx.jdsl)*jg.jg) as hj,jg.org_id,jg.ny,to_char(sh.shrq,'yyyy-MM-dd') shrq,
   sh.shdid
    from ygst_shd sh
    left join ygst_shdmx mx on sh.shdid= mx.shdid
    left join ygst_sp sp on sp.spid= mx.spid
    left join ygst_sp_jg jg on sp.spid =jg.spid
/

