create view V_ZS_DXQ1 as
select a.dxq_id,a.dxq_mc,a.org_id,b.dxq_mxid,c.org_mc xxmc,d.org_mc,a.xzsj,e.GMB,
(select f.org_id from jc_org_relat d
   left join jc_org f on f.org_id=d.org_id where b.ORG_ID=d.org_id_child and f.org_dj='60' and rownum=1) JDORG_ID,
   (select f.org_dm from jc_org_relat d
   left join jc_org f on f.org_id=d.org_id where b.ORG_ID=d.org_id_child and f.org_dj='60' and rownum=1) JDORG_DM
from zs_dxq a
left join zs_dxq_mx b on a.dxq_id=b.dxq_id
left join jc_org c on b.ORG_ID=c.org_id and c.org_state='1'
inner join jc_org d on a.org_id=d.org_id and d.org_state='1'
left join zs_xxxx e on e.org_id=b.ORG_ID
where a.dxq_yxzt='1'
/

