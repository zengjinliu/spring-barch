create view V_YGST_JSDMX as
select jo.jsdmxid,jo.jsdid,jo.spid,jo.spsl,jo.spjg,jo.hj,jo.zhhj,a.mc,b.scxlmc,c.scdlmc,
to_char(jo.xsyl) xsyl,to_char(jo.jssl) jssl, to_char(jo.jdsl) jdsl ,
to_char(jo.xsyl *jo.spjg) xsylhj,to_char(jo.jssl *jo.spjg) jsslhj,to_char(jo.jdsl *jo.spjg) jdslhj
from ygst_jsdmx jo left join ygst_sp a on jo.spid = a.spid
left join ygst_scxl b on a.xlid=b.scxlid
left join ygst_scdl c on a.dlid=c.scdlid
/

