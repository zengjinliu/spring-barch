create PROCEDURE PRO_DD_JC_XX_XD IS
V_ISHAVE NUMBER;
------根据学校表里的办学类型补充学段
------规则：办学类型为“幼儿园”的学段为2（幼儿园），其他的均为1（中小学）
BEGIN
      --需要同步的数据（办学类型不为空的学校）
      SELECT COUNT(A.ORG_ID) INTO V_ISHAVE
      FROM JC_XX X
      INNER JOIN  JC_ORG A ON A.ORG_ID=X.ORG_ID
      INNER JOIN JC_APP_ORG B ON B.ORG_ID=A.ORG_ID
      WHERE A.ORG_DJ='80' AND A.ORG_STATE='1'
      AND X.XXBXLXM IS NOT NULL
      AND X.XD IS NULL
      AND EXISTS(SELECT 1 FROM JC_APP C WHERE C.APP_ID=B.APP_ID AND C.APP_YXZT='1' AND C.PRO_ID='1cd2916578124b39b7a280cfcd3e5966');
       --查询机构是否存在
       IF(V_ISHAVE>0)THEN--修改
             UPDATE JC_XX X SET XD='2'    ----------幼儿园
             WHERE EXISTS (
             SELECT 1 FROM JC_ORG A
             INNER JOIN JC_APP_ORG B ON B.ORG_ID=A.ORG_ID
             WHERE A.ORG_ID=X.ORG_ID
             AND A.ORG_DJ='80' AND A.ORG_STATE='1'
             AND X.XXBXLXM ='111'
             AND X.XD IS NULL
             AND EXISTS(SELECT 1 FROM JC_APP C WHERE C.APP_ID=B.APP_ID AND C.APP_YXZT='1' AND C.PRO_ID='1cd2916578124b39b7a280cfcd3e5966')
             );


             UPDATE JC_XX X SET XD='1'      -----------中小学
             WHERE EXISTS (
             SELECT 1 FROM JC_ORG A
             INNER JOIN JC_APP_ORG B ON B.ORG_ID=A.ORG_ID
             WHERE A.ORG_ID=X.ORG_ID
             AND A.ORG_DJ='80' AND A.ORG_STATE='1'
             AND X.XXBXLXM !='111'
             AND X.XD IS NULL
             AND EXISTS(SELECT 1 FROM JC_APP C WHERE C.APP_ID=B.APP_ID AND C.APP_YXZT='1' AND C.PRO_ID='1cd2916578124b39b7a280cfcd3e5966')
             );
        END IF;
        commit;
   --END LOOP;
END PRO_DD_JC_XX_XD;
/

