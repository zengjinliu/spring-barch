create view V_LPJS_JSPFB as
select
jb."JSJB_ID",jb."JS_ID",jb."TJNY",jb."BZXX",jb."JZGLY",jb."JZGLB",jb."SFZB",jb."YRXS",jb."QDHT",jb."SFSF",jb."SFXQ",jb."SFTJZY",jb."SFTJPX",jb."SFTJZS",jb."XXJS",jb."SFMFSF",jb."SJJC",jb."JCQSNY",jb."JCJSNY",jb."SFTJJS",jb."SFSSJS",jb."SFJNZS",jb."QYGZSC",jb."SFXJGG",jb."SFXLJS",jb."RYZT",jb."XYJG",jb."STATUS",jb."XZR",jb."GXR",jb."XZSJ",jb."GXSJ",jb."CSDM",jb."JG",jb."MZM",jb."GJDQM",jb."SFZJLXM",jb."SFZJH",jb."HYZKM",jb."GATQWM",jb."ZZMMM",jb."JKZKM",jb."XYZJM",jb."XXM",jb."ZP",jb."SFZJYXQ",jb."SFDSZN",jb."YZBM",jb."TXDZ",jb."DH",jb."YDDH",jb."CZDH",jb."DZXX",jb."WLDZ",jb."JSTXH",jb."CSD",jb."GZDW",jb."USER_ID",jb."ORG_ID",jb."BGRZ",jb."GH",jb."XM",jb."YWXM",jb."XMPY",jb."CYM",jb."XBM",jb."CSRQ",jb."SJLY",jb."PRO_ID",jb."GZNY",jb."ZGXL",jb."ZGXLYX",jb."ZGXWCC",jb."ZGXWMC",jb."ZGXWYX",jb."LXNY", NVL(VL.PJPF,0) AS PF
from
 JC_JS_JB JB
LEFT JOIN (select trunc(avg(to_number(l.pj)),1) AS PJPF,L.USER_ID from v_lpjs_pyjl l where l.PYZT in ('1','2') group by l.USER_ID) VL ON VL.USER_ID=JB.USER_ID where JB.Status = '1'
/

