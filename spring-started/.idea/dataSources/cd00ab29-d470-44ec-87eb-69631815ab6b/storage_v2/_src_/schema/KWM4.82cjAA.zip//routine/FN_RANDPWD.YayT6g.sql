create FUNCTION FN_RANDPWD
  return varchar2
  is
  zm varchar2(24);
  sz varchar2(10);
  zm_xh1 int;
  zm_xh2 int;
  zm_xh3 int;
  zm1 varchar2(1);
  zm2 varchar2(1);
  zm3 varchar2(1);
  begin 
  zm:='abcdefghjkmnpqrstuvwxyz';
  sz:='1234567890';
  
  select floor(dbms_random.value(1,23)+1) into zm_xh1 from dual;
  select substr(zm,zm_xh1,1) into zm1 from dual;
  
  select floor(dbms_random.value(1,10)+1) into zm_xh2 from dual;
  select substr(sz,zm_xh2,1) into zm2 from dual;
  
  select floor(dbms_random.value(1,10)+1) into zm_xh3 from dual;
  select substr(sz,zm_xh3,1) into zm3 from dual;
  
  return zm1||zm2||zm2||zm2||zm3||zm3||zm3||zm3;
  end;
/

