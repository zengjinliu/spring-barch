create PROCEDURE PRO_SMBD_TJ_BY_APP_AND_ORG(p_appid in varchar2,p_quorgid in varchar2) IS

  --部门游标
  cursor c_bmlist(quorgid String) is select * from smbd_bmsz a where a.orgid=quorgid and a.status = '1' order by a.xh;
  bm c_bmlist%rowtype;
  v_tbsj_date date; --smbd_tbsj 表中记录的 最大的审核时间
  v_max_date date;  --smbd_shjg 表中当前的 最大的审核时间
  v_interval int;   --当前时间与上次同步时间 的间隔
  v_tbsj_exist int;
  v_exist int;
  v_bmtj varchar2(1000);
  v_bmmc varchar2(32); -- 部门名称
  v_bmid varchar2(32);
  v_bmdm varchar2(32);
  v_xyss number;
  v_sdss number;
  v_yss  number;
  v_dss  number;
  v_ycl  number;
  v_dcl  number;
  v_wsh  number;
  v_shtg number;
  v_shbtg number;
  v_xyshsql varchar2(1000);
  v_sdsssql varchar2(1000);
  v_ysssql varchar2(1000);
  v_dsssql varchar2(1000);
  v_yclsql varchar2(1000);
  v_dclsql varchar2(1000);
  v_wshsql varchar2(1000);
  v_shtgsql varchar2(1000);
  v_shbtgsql varchar2(1000);

begin
    select count(*) into v_tbsj_exist from SMBD_TBSJ where APP_ID = p_appid AND ORG_ID = p_quorgid;
    if (v_tbsj_exist < 1) then
      insert into SMBD_TBSJ  (ID,TBSJ,ORG_ID,APP_ID)  values ((select max(id) from SMBD_TBSJ)+1,(to_date('1970-01-01 00:00:00','yyyy-MM-dd HH24:mi:ss')),p_quorgid,p_appid);
      commit ;
    end if;
    select TBSJ into v_tbsj_date from SMBD_TBSJ where APP_ID = p_appid AND ORG_ID = p_quorgid;
    select ROUND(TO_NUMBER(sysdate - v_tbsj_date) * 24 * 60*60) into v_interval from dual;
  IF (v_interval >300) THEN -- 超过5分钟才执行更新
    select max(a.shsj) into v_max_date from smbd_shjg a left join zs_xsxx b on b.xsid=a.xsid left join smbd_bmsz c on c.bmid=a.bmid where b.app_id=p_appid and c.orgid=p_quorgid;
    if (v_max_date > v_tbsj_date) then
      open c_bmlist(p_quorgid);
      loop fetch c_bmlist into bm;
      exit when c_bmlist%notfound;
        if(bm.tj is not null)then
          v_bmtj:=''' and '||bm.tj;
          else
          v_bmtj:='''';
        end if;
        v_bmmc := bm.BMMC;
        v_bmid := bm.BMID;
        v_bmdm := bm.BMDM;
        --需要送审
        v_xyshsql := 'select count(*) cnt from v_smbd_bmshjg jo where jo.SHZT = ''2'' and jo.APP_ID='''||p_appid||'' || v_bmtj;
        execute immediate v_xyshsql into v_xyss;
        --手动送审
        v_sdsssql := 'select count(*) cnt from SMBD_SJ  where APP_ID='''||p_appid|| ''' and BMID = '''||v_bmid||'''';
        execute immediate v_sdsssql into v_sdss;
        -- 已送审
        v_ysssql := 'select count(*) cnt from SMBD_SJ  where SSZT = ''Y''  and APP_ID='''||p_appid|| ''' and BMID = '''||v_bmid||'''' ;
        execute immediate v_ysssql into v_yss;
        -- 待送审
        v_dsssql := 'select count(*) cnt from SMBD_SJ  where SSZT = ''N''  and APP_ID='''||p_appid|| ''' and BMID = '''||v_bmid||'''' ;
        execute immediate v_dsssql into v_dss;
         -- 已处理
        v_yclsql := 'select count(*) cnt from SMBD_SJ  where JGCLZT = ''Y''  and APP_ID='''||p_appid|| ''' and BMID = '''||v_bmid||'''' ;
        execute immediate v_yclsql into v_ycl;
        -- 待待处理
        v_dclsql := 'select count(*) cnt from SMBD_SJ  where JGCLZT = ''N''  and APP_ID='''||p_appid|| ''' and BMID = '''||v_bmid||'''' ;
        execute immediate v_dclsql into v_dcl;
        --未审核
        v_wshsql := 'select count(*)  from v_smbd_bmshjg JO left join smbd_shjg e on e.xsid=jo.xsid and e.bmdm= '''||v_bmdm||''' WHERE JO.SHZT = ''2''  and nvl(e.SHJG,''0'') =''0'' AND APP_ID='''||p_appid||'' || v_bmtj;
        execute immediate v_wshsql into v_wsh;
         --审核通过
        v_shtgsql := 'select count(*)  from v_smbd_bmshjg JO left join smbd_shjg e on e.xsid=jo.xsid and e.bmdm= '''||v_bmdm||''' WHERE JO.SHZT = ''2'' and nvl(e.SHJG,''0'') =''1'' AND APP_ID='''||p_appid||'' || v_bmtj;
        execute immediate v_shtgsql into v_shtg;
         --审核不通过
        v_shbtgsql := 'select count(*)  from v_smbd_bmshjg JO left join smbd_shjg e on e.xsid=jo.xsid and e.bmdm= '''||v_bmdm||''' WHERE JO.SHZT = ''2'' and nvl(e.SHJG,''0'') =''2'' AND APP_ID='''||p_appid||'' || v_bmtj;
        execute immediate v_shbtgsql into v_shbtg;

        select count(*) into v_exist from SMBD_TJ WHERE APP_ID=p_appid and BMID = v_bmid;
        if ( v_exist > 0) then -- 存在则更新
          update SMBD_TJ set XYSS = v_xyss,SDSS=v_sdss,YSS = v_yss,DSS = v_dss,YCL = v_ycl,DCL = v_dcl,WSH=v_wsh,SHTG=v_shtg,SHBTG=v_shbtg
          where APP_ID=p_appid and BMID = v_bmid;
        else
          insert into SMBD_TJ values (fn_uuid(),p_appid,v_bmid,v_bmmc,v_xyss,v_sdss,v_yss,v_dss,v_ycl,v_dcl,v_wsh,v_shtg,v_shbtg,p_quorgid);
        end if ;
        commit ;
      end loop;
      close c_bmlist;
    update SMBD_TBSJ set TBSJ = v_max_date where APP_ID = p_appid and ORG_ID = p_quorgid;
    commit ;
    end if;
  end if;
end;
/

