create view V_JC_JS_RC_CJ as
SELECT zs.jsrc_id as zsid,t1.jsrc_id,t1.js_id,t1.xzr,t1.xzsj,t1.gxr,t1.gxsj,t1.status,t1.rcxmmc,t1.rxnf
 FROM JC_JS_RC_CJ T1
 LEFT JOIN jc_js_rc zs ON T1.JSRC_ID = zs.jsrc_id
/

