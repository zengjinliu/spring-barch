create view V_DXQ_ZY_TJ as
select XSID,zy,xxmc from  ZS_XSXX JO unpivot (xxmc for zy in (SQXXID1,SQXXID2,SQXXID3,SQXXID4))
/

