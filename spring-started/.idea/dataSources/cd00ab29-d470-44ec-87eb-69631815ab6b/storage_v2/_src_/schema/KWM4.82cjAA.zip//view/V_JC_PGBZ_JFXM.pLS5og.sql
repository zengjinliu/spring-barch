create view V_JC_PGBZ_JFXM as
select jpj."SJNID",jpj."JID",jpj."BZID",jp.bzmc,jj.jname,jj.app_id,jj.org_id from
jc_pgbz_jfxm jpj
LEFT JOIN jc_pgbz jp on jpj.bzid = jp.bzid
LEFT JOIN jc_jfxm jj on jpj.jid = jj.jid
/

